#!/data/data/com.termux/files/usr/bin/sh
set -u

PREFIX_DIR="${PREFIX:-/data/data/com.termux/files/usr}"
HOME_DIR="${HOME:-/data/data/com.termux/files/home}"
BACKEND_DIR="${ORGANIZEON_BACKEND_DIR:-$HOME_DIR/organizeon/backend}"
SERVICE_DIR="${SVDIR:-$PREFIX_DIR/var/service}"
SERVICE="$SERVICE_DIR/organizeon-backend"
USERS="$BACKEND_DIR/data/users.json"
EMERGENCY="$BACKEND_DIR/data/users-emergency.json"
PORT="$(sed -n 's/^PORT=//p' "$BACKEND_DIR/.env" 2>/dev/null | tail -n 1)"
PORT="${PORT:-5000}"
API_PREFIX="$(sed -n 's/^API_PREFIX=//p' "$BACKEND_DIR/.env" 2>/dev/null | tail -n 1)"
API_PREFIX="${API_PREFIX:-/827e7h3heuw823eh}"
HEALTH_URL="http://127.0.0.1:$PORT$API_PREFIX/health"

message() { printf '%s\n' "$*"; }
fail() { message "ERRO: $*" >&2; exit 1; }
valid_users() {
  node -e 'const fs=require("fs");const p=process.argv[1];const x=JSON.parse(fs.readFileSync(p,"utf8"));if(x?.version!==1||!x.users||typeof x.users!=="object")process.exit(1)' "$1" >/dev/null 2>&1
}
ensure_files() {
  [ -f "$BACKEND_DIR/package.json" ] || fail "package.json ausente em $BACKEND_DIR"
  [ -f "$BACKEND_DIR/src/server.mjs" ] || fail "src/server.mjs ausente em $BACKEND_DIR"
  [ -d "$SERVICE" ] || fail "serviço runit ausente em $SERVICE"
  if ! valid_users "$EMERGENCY"; then
    node "$BACKEND_DIR/scripts/create-emergency-users.mjs" "$EMERGENCY" || fail "não foi possível criar users-emergency.json"
  fi
}
status() {
  ensure_files
  if sv status "$SERVICE"; then
    curl -fsS --max-time 4 "$HEALTH_URL" >/dev/null 2>&1 \
      && message "OK: processo e API estão online." \
      || fail "o supervisor está ativo, mas a API não respondeu ao health check"
  else
    fail "o processo não está online"
  fi
}
wait_health() {
  attempt=0
  while [ "$attempt" -lt 20 ]; do
    curl -fsS --max-time 2 "$HEALTH_URL" >/dev/null 2>&1 && {
      message "OK: OrganizeOn iniciou e respondeu ao health check."
      return 0
    }
    attempt=$((attempt + 1)); sleep 1
  done
  tail -n 40 "$BACKEND_DIR/server.log" 2>/dev/null >&2
  fail "o processo morreu ou não respondeu em 20 segundos"
}
start() {
  ensure_files
  if [ "${1:-}" = "emergency" ]; then
    printf '%s\n' "$EMERGENCY" > "$BACKEND_DIR/data/accounts-file.active"
    message "AVISO: iniciando com users-emergency.json"
  elif valid_users "$USERS"; then
    printf '%s\n' "$USERS" > "$BACKEND_DIR/data/accounts-file.active"
  else
    printf '%s\n' "$EMERGENCY" > "$BACKEND_DIR/data/accounts-file.active"
    message "AVISO: users.json ausente/corrompido; modo de emergência ativado."
  fi
  sv up "$SERVICE" || fail "runit recusou a inicialização"
  wait_health
}

case "${1:-}" in
  -e) start emergency ;;
  -r) ensure_files; sv restart "$SERVICE" || fail "reinício falhou"; wait_health ;;
  -s) status ;;
  "") start normal ;;
  *) fail "uso: $0 [-e|-r|-s]" ;;
esac
