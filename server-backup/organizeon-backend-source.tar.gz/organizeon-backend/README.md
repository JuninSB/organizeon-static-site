# Backend autenticado do proxy

Servidor HTTP + Wisp protegido por login. A sessão dura 14 dias. A raiz do
domínio e caminhos desconhecidos retornam 404; apenas o prefixo configurado
expõe autenticação, health check e WebSocket.

## Configuração

```bash
cd backend
npm install
npm run hash-password -- 'SUA-SENHA-FORTE'
```

Copie `.env.example` para um arquivo de ambiente seguro e substitua:

- `AUTH_USERNAME`;
- `AUTH_PASSWORD_HASH` pelo valor gerado;
- `SESSION_SECRET` por pelo menos 32 caracteres aleatórios;
- `ALLOWED_ORIGINS` pelas origens exatas do frontend.

O Node não carrega `.env` automaticamente. Exporte as variáveis pelo serviço
que iniciar o backend (systemd, Docker, painel de hospedagem ou shell).

## Executar

```bash
npm start
```

Rotas padrão:

- `POST /827e7h3heuw823eh/auth/login`
- `GET /827e7h3heuw823eh/auth/session`
- `POST /827e7h3heuw823eh/auth/logout`
- `GET /827e7h3heuw823eh/health`
- `WS /827e7h3heuw823eh/wisp/<token>/`
- `WS /827e7h3heuw823eh/connect/<token>/`
- `GET /827e7h3heuw823eh/admin/status`
- `POST /827e7h3heuw823eh/admin/monitoring`
- `GET|POST /827e7h3heuw823eh/admin/users`
- `PATCH|DELETE /827e7h3heuw823eh/admin/users/<username>`
- `WS /827e7h3heuw823eh/terminal/<token>/`

Todo o restante, inclusive `/`, responde 404.

## Download do cliente

O domínio principal expõe somente:

```text
GET https://organizeon.com.br/d1
```

Esse endereço baixa somente `index.html`. Os demais arquivos ficam hospedados
no repositório estático do GitHub. A raiz e qualquer outro caminho em
`organizeon.com.br` continuam retornando 404. Login e Wisp permanecem exclusivos
em `api.organizeon.com.br`.

## Cloudflare Tunnel

O arquivo `cloudflared-config.example.yml` encaminha
`api.organizeon.com.br` para `127.0.0.1:5000`. O Cloudflare Tunnel suporta
WebSocket, portanto não é necessário Playit para o Wisp.

O erro Cloudflare 1033 significa que nenhuma instância válida de `cloudflared`
está conectada ao túnel. Inicie o conector com a configuração/credencial do
túnel correto.

## Segurança

- token HMAC com expiração de 14 dias;
- cookie `HttpOnly`, `Secure` e `SameSite=None`;
- token também retornado ao cliente para compatibilidade quando cookies de
  terceiros são bloqueados;
- contas persistentes com função, permissões e versão de token;
- alterações de permissões invalidam imediatamente os tokens anteriores;
- monitoramento de CPU, RAM e requisições permanece inativo até um
  administrador ativá-lo;
- terminal remoto separado e restrito à permissão `admin.terminal`;
- limitação de tentativas de login;
- origem do frontend validada em HTTP e WebSocket;
- hostname da API restrito a `api.organizeon.com.br`;
- Wisp limitado às portas 80 e 443;
- redes locais e endereços de loopback bloqueados.

O prefixo aleatório não é tratado como segredo. A segurança depende da senha,
do token assinado, das restrições do Wisp e das regras da Cloudflare.
