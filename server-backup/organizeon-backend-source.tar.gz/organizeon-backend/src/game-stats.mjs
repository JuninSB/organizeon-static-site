import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";

const GAME_ID_PATTERN = /^[a-z0-9][a-z0-9-]{0,63}$/;
const EVENTS = new Set(["download", "play"]);
const RETENTION_DAYS = 30;

export async function createGameStats({ filePath, now = () => Date.now() }) {
  let state = await readState(filePath);
  let writeQueue = Promise.resolve();
  const recentEvents = new Map();

  return Object.freeze({
    snapshot,
    async record(gameId, event, clientKey = "unknown") {
      if (!GAME_ID_PATTERN.test(String(gameId || ""))) {
        return { accepted: false, reason: "invalid_game" };
      }
      if (!EVENTS.has(event)) {
        return { accepted: false, reason: "invalid_event" };
      }

      const timestamp = now();
      const rateKey = `${clientKey}\0${gameId}\0${event}`;
      const lastEvent = recentEvents.get(rateKey) || 0;
      const minimumInterval = event === "download" ? 30_000 : 5_000;
      if (timestamp - lastEvent < minimumInterval) {
        return { accepted: false, reason: "rate_limited" };
      }
      recentEvents.set(rateKey, timestamp);
      pruneRateLimits(recentEvents, timestamp);

      const day = dayKey(timestamp);
      const game = state.games[gameId] || {
        downloads: 0,
        plays: 0,
        dailyPlays: {},
      };
      if (event === "download") game.downloads += 1;
      if (event === "play") {
        game.plays += 1;
        game.dailyPlays[day] = (game.dailyPlays[day] || 0) + 1;
      }
      pruneDailyPlays(game.dailyPlays, timestamp);
      state.games[gameId] = game;
      state.updatedAt = new Date(timestamp).toISOString();
      writeQueue = writeQueue.then(() => persist(filePath, state));
      await writeQueue;
      return { accepted: true, game: publicGameStats(game, timestamp) };
    },
  });

  function snapshot() {
    const timestamp = now();
    const games = Object.fromEntries(
      Object.entries(state.games).map(([gameId, game]) => [
        gameId,
        publicGameStats(game, timestamp),
      ]),
    );
    const trending = Object.entries(games)
      .filter(([, game]) => game.plays7d > 0)
      .sort((left, right) =>
        right[1].plays7d - left[1].plays7d ||
        right[1].plays - left[1].plays ||
        left[0].localeCompare(right[0])
      )
      .slice(0, 12)
      .map(([gameId]) => gameId);
    return { updatedAt: state.updatedAt, games, trending };
  }
}

async function readState(filePath) {
  try {
    const parsed = JSON.parse(await readFile(filePath, "utf8"));
    if (parsed?.version === 1 && parsed.games && typeof parsed.games === "object") {
      return parsed;
    }
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
  return { version: 1, updatedAt: null, games: {} };
}

async function persist(filePath, state) {
  await mkdir(dirname(filePath), { recursive: true });
  const temporary = `${filePath}.tmp`;
  await writeFile(temporary, `${JSON.stringify(state, null, 2)}\n`, {
    mode: 0o600,
  });
  await rename(temporary, filePath);
}

function publicGameStats(game, timestamp) {
  const activeDays = new Set();
  for (let offset = 0; offset < 7; offset += 1) {
    activeDays.add(dayKey(timestamp - offset * 86_400_000));
  }
  const plays7d = Object.entries(game.dailyPlays || {})
    .filter(([day]) => activeDays.has(day))
    .reduce((total, [, count]) => total + Number(count || 0), 0);
  return {
    downloads: Number(game.downloads || 0),
    plays: Number(game.plays || 0),
    plays7d,
  };
}

function pruneDailyPlays(dailyPlays, timestamp) {
  const oldest = dayKey(timestamp - (RETENTION_DAYS - 1) * 86_400_000);
  for (const day of Object.keys(dailyPlays)) {
    if (day < oldest) delete dailyPlays[day];
  }
}

function pruneRateLimits(recentEvents, timestamp) {
  if (recentEvents.size < 10_000) return;
  for (const [key, lastEvent] of recentEvents) {
    if (timestamp - lastEvent > 60_000) recentEvents.delete(key);
  }
}

function dayKey(timestamp) {
  return new Date(timestamp).toISOString().slice(0, 10);
}
