import { createReadStream, createWriteStream } from "node:fs";
import { mkdir, readFile, rename, stat, unlink, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { pipeline } from "node:stream/promises";
import { Transform } from "node:stream";

export const CLOUD_BACKUP_LIMIT_BYTES = 500 * 1024 * 1024;

export function createCloudBackupStore({ directory }) {
  const settingsDirectory = join(directory, "settings");
  const dataDirectory = join(directory, "data");

  async function init() {
    await mkdir(settingsDirectory, { recursive: true, mode: 0o700 });
    await mkdir(dataDirectory, { recursive: true, mode: 0o700 });
  }

  function safeUser(username) {
    if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username)) {
      throw backupError(400, "invalid_account");
    }
    return username;
  }

  const settingsPath = (username) => join(settingsDirectory, `${safeUser(username)}.json`);
  const dataPath = (username) => join(dataDirectory, `${safeUser(username)}.json`);

  async function status(account) {
    const settings = await readSettings(account.username);
    const info = await stat(dataPath(account.username)).catch(() => null);
    return {
      enabled: settings.enabled === true,
      size: info?.size || 0,
      limit: CLOUD_BACKUP_LIMIT_BYTES,
      updatedAt: settings.updatedAt || null,
    };
  }

  async function setEnabled(account, enabled) {
    const value = {
      enabled: enabled === true,
      updatedAt: new Date().toISOString(),
    };
    await writeAtomic(settingsPath(account.username), `${JSON.stringify(value)}\n`);
    return status(account);
  }

  async function save(account, request) {
    const settings = await readSettings(account.username);
    if (settings.enabled !== true) throw backupError(409, "cloud_backup_disabled");
    const declared = Number(request.headers["content-length"]);
    if (!Number.isInteger(declared) || declared < 2) throw backupError(411, "content_length_required");
    if (declared > CLOUD_BACKUP_LIMIT_BYTES) throw backupError(413, "backup_limit_exceeded");
    const destination = dataPath(account.username);
    const temporary = `${destination}.tmp`;
    let received = 0;
    const limiter = new Transform({
      transform(chunk, encoding, callback) {
        received += chunk.length;
        callback(received > CLOUD_BACKUP_LIMIT_BYTES
          ? backupError(413, "backup_limit_exceeded")
          : null, chunk);
      },
    });
    try {
      await pipeline(request, limiter, createWriteStream(temporary, { mode: 0o600 }));
      if (received !== declared) throw backupError(400, "content_length_mismatch");
      JSON.parse(await readFile(temporary, "utf8"));
      await rename(temporary, destination);
      await setEnabled(account, true);
      return status(account);
    } catch (error) {
      await unlink(temporary).catch(() => {});
      throw error;
    }
  }

  async function open(account) {
    const settings = await readSettings(account.username);
    if (settings.enabled !== true) throw backupError(409, "cloud_backup_disabled");
    const path = dataPath(account.username);
    const info = await stat(path).catch(() => null);
    return info ? { path, size: info.size, stream: () => createReadStream(path) } : null;
  }

  async function clear(account) {
    await unlink(dataPath(account.username)).catch(() => {});
    return status(account);
  }

  async function readSettings(username) {
    try { return JSON.parse(await readFile(settingsPath(username), "utf8")); }
    catch { return { enabled: false, updatedAt: null }; }
  }

  async function writeAtomic(path, content) {
    const temporary = `${path}.tmp`;
    await writeFile(temporary, content, { mode: 0o600 });
    await rename(temporary, path);
  }

  return Object.freeze({ init, status, setEnabled, save, open, clear });
}

function backupError(statusCode, code) {
  return Object.assign(new Error(code), { statusCode, code });
}
