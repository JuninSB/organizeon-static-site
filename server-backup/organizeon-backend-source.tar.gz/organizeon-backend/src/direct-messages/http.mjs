import { createHash } from "node:crypto";
import { DM_UPLOAD_BODY_LIMIT } from "./media-policy.mjs";
import { dmError } from "./store.mjs";
const integer = (value, optional = true) => {
  if (value === null || value === undefined || value === "") {
    if (optional) return undefined;
    throw dmError(400, "dm_invalid_cursor");
  }
  const n = Number(value);
  if (!Number.isSafeInteger(n) || n < 0)
    throw dmError(400, "dm_invalid_cursor");
  return n;
};
export function createDirectMessagesHandler({
  store,
  grantGoldBadge,
  claimGoldBadge,
  rerollBanner,
  authenticate,
  originAllowed,
  readJson,
  sendJson,
}) {
  return async function handle(request, response, url, base) {
    try {
      const actor = authenticate(request, url);
      if (!actor) return sendJson(response, 401, { error: "unauthorized" });
      if (!["GET", "POST", "PATCH", "DELETE"].includes(request.method))
        return sendJson(response, 405, { error: "method_not_allowed" });
      if (request.method !== "GET" && !originAllowed(request))
        return sendJson(response, 403, { error: "origin_not_allowed" });
      const path = url.pathname
        .slice(base.length)
        .split("/")
        .filter(Boolean)
        .map((v) => decodeURIComponent(v));
      if (path.some((v) => v.includes("/") || v.includes("\0")))
        throw dmError(400, "invalid_request");
      const username = actor.username,
        method = request.method;
      const body = async (max) => {
        const data = await readJson(request, max);
        if (!data || typeof data !== "object" || Array.isArray(data))
          throw dmError(400, "invalid_request");
        return data;
      };
      let value;
      if (path.length === 1 && path[0] === "inbox" && method === "GET")
        value = store.getInbox(
          username,
          url.searchParams.has("after")
            ? integer(url.searchParams.get("after"), false)
            : null,
          url.searchParams.get("active") !== "0",
        );
      else if (path.length === 1 && path[0] === "requests" && method === "POST")
        value = store.createRequest(username, (await body()).username);
      else if (
        path.length === 1 &&
        path[0] === "settings" &&
        method === "PATCH"
      )
        value = { settings: store.updateSettings(username, await body()) };
      else if (path.length === 3 && path[0] === "awards" && path[1] === "gold-badge" && path[2] === "reroll" && method === "POST") {
        if(!rerollBanner)throw dmError(404,"not_found");
        value={profile:await rerollBanner(actor)};
      }
      else if (path.length === 3 && path[0] === "awards" && path[1] === "gold-badge" && path[2] === "claim" && method === "POST") {
        if(!claimGoldBadge)throw dmError(404,"not_found");
        value=await claimGoldBadge(actor);
      }
      else if (path.length === 3 && path[0] === "people" && path[2] === "gold-badge" && method === "POST") {
        if(actor.role!=="owner"||!grantGoldBadge)throw dmError(403,"forbidden");
        value={profile:await grantGoldBadge(actor,path[1])};
      }
      else if (path.length === 2 && path[0] === "people" && method === "GET")
        value = { person: store.getPeer(username, path[1]) };
      else if (
        path.length === 3 &&
        path[0] === "people" &&
        path[2] === "block" &&
        method === "POST"
      )
        value = store.block(username, path[1], (await body()).blocked);
      else if (
        path.length === 2 &&
        path[0] === "conversations" &&
        method === "PATCH"
      )
        value = store.updateConversation(username, path[1], await body());
      else if (path.length === 3 && path[0] === "conversations") {
        const id = path[1],
          action = path[2];
        if (action === "reset" && method === "POST")
          value=store.resetConversation(username,id,await body());
        else if (action === "request" && method === "POST")
          value = store.respond(username, id, (await body()).action);
        else if (action === "messages" && method === "GET")
          value = store.getMessages(username, id, {
            before: integer(url.searchParams.get("before")),
            after: integer(url.searchParams.get("after")),
            search: (url.searchParams.get("search") || "").slice(0, 200),
            filter: url.searchParams.get("filter") || "all",
            limit: integer(url.searchParams.get("limit")) || 40,
          });
        else if (action === "messages" && method === "POST")
          value = { message: store.send(username, id, await body()) };
        else if (action === "read" && method === "POST")
          value = store.read(username, id, (await body()).seq);
        else if (action === "typing" && method === "POST") {
          const data = await body();
          if (typeof data.active !== "boolean")
            throw dmError(400, "invalid_request");
          value = store.setTyping(username, id, data.active);
        } else if (action === "attachments" && method === "POST")
          value = {
            attachment: store.upload(
              username,
              id,
              await body(DM_UPLOAD_BODY_LIMIT),
            ),
          };
      } else if (path.length === 2 && path[0] === "messages") {
        if (method === "GET") value={message:store.getMessage(username,path[1])};
      else if (method === "PATCH")
          value = {
            message: store.edit(username, path[1], (await body()).content),
          };
        else if (method === "DELETE") value = store.remove(username, path[1]);
      } else if (
        path.length === 3 &&
        path[0] === "messages" &&
        path[2] === "actions" &&
        method === "POST"
      )
        value = store.messageAction(username, path[1], await body());
      else if (path.length === 2 && path[0] === "attachments") {
        if (method === "GET")
          value = { attachment: store.download(username, path[1]) };
        else if (method === "DELETE")
          value = store.discardAttachment(username, path[1]);
      } else if (
        path.length === 2 &&
        path[0] === "notifications" &&
        path[1] === "claim" &&
        method === "POST"
      )
        value = store.claim(username, integer((await body()).seq, false));
      else if(path.length===2&&path[0]==='notifications'&&path[1]==='unread-summary'&&method==='POST')value=store.claimUnreadSummary(username);
      // Existing clients keep full responses; compact clients reuse authenticated snapshots.
      if (value && method === "GET" && url.searchParams.get("compact") === "1") {
        const digest = data => createHash("sha256").update(JSON.stringify(data)).digest("base64url");
        if (path.length === 1 && path[0] === "inbox") {
          const { events, cursor, ...snapshot } = value;
          const version = digest(snapshot);
          value = url.searchParams.get("version") === version
            ? { unchanged: true, version, cursor, events }
            : { ...value, version };
        } else if (path.length === 3 && path[0] === "conversations" && path[2] === "messages") {
          const conversationVersion = digest(value.conversation);
          value = { ...value, conversation: url.searchParams.get("conversationVersion") === conversationVersion ? null : value.conversation, conversationVersion };
        }
      }
      if (value === undefined)
        return sendJson(response, 404, { error: "not_found" });
      return sendJson(response, 200, value);
    } catch (error) {
      if(error.retryAfter)response.setHeader("Retry-After",String(error.retryAfter));
      return sendJson(response, error.statusCode || 500, {
        ...(error.retryAt ? {retryAt:error.retryAt} : {}),
        error:
          error.code ||
          (error.statusCode === 413
            ? "request_too_large"
            : "dm_operation_failed"),
      });
    }
  };
}
