import { DatabaseSync } from "node:sqlite";
import { randomUUID } from "node:crypto";
import { mkdirSync, chmodSync } from "node:fs";
import { dirname } from "node:path";

export const DM_FILE_LIMIT = 8 * 1024 * 1024;
export const DM_MEDIA_QUOTA = 256 * 1024 * 1024;
export const REACTIONS = [
  "👍",
  "❤️",
  "😂",
  "🎉",
  "🔥",
  "👀",
  "👎",
  "😢",
  "✅",
  "🇧🇷",
  "💀",
  "🙂",
];
export function dmError(status, code) {
  return Object.assign(new Error(code), { statusCode: status, code });
}
const defaults = {
  autoAccept: false,
  notifications: true,
  sound: false,
  previews: true,
  desktop: false,
  quickReaction: "👍",
  showSendStatus: false,
  longPressMs: 200,
};
const peerDefault = (username) => ({
  username,
  role: "user",
  available: false,
  profile: {
    displayName: "Conta indisponível",
    nameColor: "#FAFAFA",
    bio: "",
    avatarShape: "circle",
    avatar: null,
  },
});

export function createDirectMessagesStore({
  filePath,
  resolveAccount,
  now = Date.now,
}) {
  if (filePath !== ":memory:") {
    mkdirSync(dirname(filePath), { recursive: true, mode: 0o700 });
  }
  const db = new DatabaseSync(filePath);
  if (filePath !== ":memory:") chmodSync(filePath, 0o600);
  db.exec(`PRAGMA foreign_keys=ON; PRAGMA busy_timeout=1500; PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;
 CREATE TABLE IF NOT EXISTS dm_conversations(id TEXT PRIMARY KEY,pair_key TEXT UNIQUE NOT NULL,initiator TEXT NOT NULL,status TEXT NOT NULL,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS dm_members(conversation_id TEXT REFERENCES dm_conversations(id),username TEXT NOT NULL,read_seq INTEGER NOT NULL DEFAULT 0,muted INTEGER NOT NULL DEFAULT 0,archived INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(conversation_id,username));
 CREATE INDEX IF NOT EXISTS dm_members_user ON dm_members(username,conversation_id);
 CREATE TABLE IF NOT EXISTS dm_messages(seq INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT UNIQUE NOT NULL,conversation_id TEXT NOT NULL REFERENCES dm_conversations(id),sender TEXT NOT NULL,content TEXT NOT NULL,reply_id TEXT,forwarded_from TEXT,nonce TEXT NOT NULL,created_at INTEGER NOT NULL,edited_at INTEGER,deleted INTEGER NOT NULL DEFAULT 0,pinned INTEGER NOT NULL DEFAULT 0,UNIQUE(sender,nonce));
 CREATE INDEX IF NOT EXISTS dm_messages_conversation ON dm_messages(conversation_id,seq);
 CREATE TABLE IF NOT EXISTS dm_reactions(message_id TEXT REFERENCES dm_messages(id),username TEXT NOT NULL,emoji TEXT NOT NULL,PRIMARY KEY(message_id,username,emoji));
 CREATE TABLE IF NOT EXISTS dm_bookmarks(message_id TEXT REFERENCES dm_messages(id),username TEXT NOT NULL,PRIMARY KEY(message_id,username));
 CREATE TABLE IF NOT EXISTS dm_settings(username TEXT PRIMARY KEY,value TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS dm_blocks(username TEXT NOT NULL,target TEXT NOT NULL,PRIMARY KEY(username,target));
 CREATE TABLE IF NOT EXISTS dm_events(seq INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT NOT NULL,kind TEXT NOT NULL,conversation_id TEXT NOT NULL,message_id TEXT,created_at INTEGER NOT NULL,claimed INTEGER NOT NULL DEFAULT 0);
 CREATE INDEX IF NOT EXISTS dm_events_user ON dm_events(username,seq);
 CREATE TABLE IF NOT EXISTS dm_blobs(id TEXT PRIMARY KEY,owner TEXT NOT NULL,name TEXT NOT NULL,mime TEXT NOT NULL,size INTEGER NOT NULL,data BLOB NOT NULL);
 CREATE TABLE IF NOT EXISTS dm_attachments(id TEXT PRIMARY KEY,conversation_id TEXT NOT NULL REFERENCES dm_conversations(id),blob_id TEXT NOT NULL REFERENCES dm_blobs(id),uploader TEXT NOT NULL,message_id TEXT REFERENCES dm_messages(id),created_at INTEGER NOT NULL);
 CREATE INDEX IF NOT EXISTS dm_attachment_message ON dm_attachments(message_id);
 `);
  const memberColumns = new Set(db.prepare("PRAGMA table_info(dm_members)").all().map(column => column.name));
  for (const column of ["favorite", "pinned"]) {
    if (!memberColumns.has(column)) db.exec(`ALTER TABLE dm_members ADD COLUMN ${column} INTEGER NOT NULL DEFAULT 0`);
  }
  const rates = new Map(),
    presence = new Map(),
    typing = new Map();
  const one = (sql, ...args) => db.prepare(sql).get(...args);
  const all = (sql, ...args) => db.prepare(sql).all(...args);
  const run = (sql, ...args) => db.prepare(sql).run(...args);
  const transaction = (fn) => {
    db.exec("BEGIN IMMEDIATE");
    try {
      const value = fn();
      db.exec("COMMIT");
      return value;
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
  };
  const account = (username) => {
    const value = resolveAccount(username);
    return value && !value.disabled ? value : null;
  };
  function peer(username) {
    const value = account(username);
    if (!value) return peerDefault(username);
    return {
      username: value.username,
      role: value.role,
      profile: value.profile || {
        ...peerDefault(username).profile,
        displayName: username,
      },
      available: true,
      online: (presence.get(username) || 0) > now() - 45000,
    };
  }
  function settings(username) {
    const row = one("SELECT value FROM dm_settings WHERE username=?", username);
    return { ...defaults, ...(row ? JSON.parse(row.value) : {}) };
  }
  function requireActor(username) {
    if (typeof username !== "string" || !account(username))
      throw dmError(401, "unauthorized");
  }
  function rate(username, action, limit, window) {
    const key = username + ":" + action,
      time = now();
    let entry = rates.get(key);
    if (!entry || entry.until <= time) {
      entry = { count: 0, until: time + window };
      rates.set(key, entry);
    }
    if (++entry.count > limit) throw dmError(429, "dm_rate_limited");
    if (rates.size > 5000)
      for (const [key, value] of rates)
        if (value.until <= time) rates.delete(key);
  }
  function member(username, id, accepted = false) {
    const row = one(
      "SELECT c.*,m.read_seq,m.muted,m.archived,m.favorite,m.pinned FROM dm_conversations c JOIN dm_members m ON m.conversation_id=c.id WHERE c.id=? AND m.username=?",
      id,
      username,
    );
    if (!row) throw dmError(404, "dm_conversation_not_found");
    if (accepted && row.status !== "accepted")
      throw dmError(409, "dm_request_pending");
    return row;
  }
  const other = (username, id) =>
    one(
      "SELECT username FROM dm_members WHERE conversation_id=? AND username<>?",
      id,
      username,
    )?.username;
  const blocked = (a, b) =>
    !!one(
      "SELECT 1 FROM dm_blocks WHERE (username=? AND target=?) OR (username=? AND target=?)",
      a,
      b,
      b,
      a,
    );
  function canSend(username, conversation) {
    const recipient = other(username, conversation.id);
    return (
      conversation.status === "accepted" &&
      !!account(recipient) &&
      !blocked(username, recipient)
    );
  }
  function emit(username, kind, conversationId, messageId = null) {
    run(
      "INSERT INTO dm_events(username,kind,conversation_id,message_id,created_at) VALUES(?,?,?,?,?)",
      username,
      kind,
      conversationId,
      messageId,
      now(),
    );
  }
  function emitBoth(id, kind, messageId = null) {
    for (const item of all(
      "SELECT username FROM dm_members WHERE conversation_id=?",
      id,
    ))
      emit(item.username, kind, id, messageId);
  }
  function attachments(id) {
    return all(
      "SELECT a.id,b.name,b.mime,b.size FROM dm_attachments a JOIN dm_blobs b ON b.id=a.blob_id WHERE a.message_id=?",
      id,
    ).map((row) => ({ ...row }));
  }
  function message(username, row) {
    if (!row) return null;
    const parent = row.reply_id
      ? one(
          "SELECT id,sender,content,deleted FROM dm_messages WHERE id=? AND conversation_id=?",
          row.reply_id,
          row.conversation_id,
        )
      : null;
    return {
      id: row.id,
      clientNonce: row.sender === username ? row.nonce : undefined,
      seq: Number(row.seq),
      conversationId: row.conversation_id,
      sender: { username: row.sender },
      content: row.deleted ? "" : row.content,
      createdAt: new Date(row.created_at).toISOString(),
      editedAt: row.edited_at ? new Date(row.edited_at).toISOString() : null,
      deleted: !!row.deleted,
      pinned: !!row.pinned,
      bookmarked: !!one(
        "SELECT 1 FROM dm_bookmarks WHERE message_id=? AND username=?",
        row.id,
        username,
      ),
      reply: parent
        ? {
            id: parent.id,
            username: parent.sender,
            content: parent.deleted
              ? "Mensagem apagada"
              : parent.content.slice(0, 160),
          }
        : null,
      forwarded: !!row.forwarded_from,
      attachments: row.deleted ? [] : attachments(row.id),
      reactions: row.deleted
        ? []
        : all(
            "SELECT emoji,COUNT(*) AS count,MAX(username=?) AS mine FROM dm_reactions WHERE message_id=? GROUP BY emoji",
            username,
            row.id,
          ).map((r) => ({
            emoji: r.emoji,
            count: Number(r.count),
            mine: !!r.mine,
          })),
    };
  }
  function conversation(username, row) {
    const who = other(username, row.id);
    const last = one(
      "SELECT * FROM dm_messages WHERE conversation_id=? ORDER BY seq DESC LIMIT 1",
      row.id,
    );
    return {
      id: row.id,
      status: row.status,
      direction: row.initiator === username ? "outgoing" : "incoming",
      peer: peer(who),
      createdAt: new Date(row.created_at).toISOString(),
      updatedAt: new Date(row.updated_at).toISOString(),
      muted: !!row.muted,
      archived: !!row.archived,
      favorite: !!row.favorite,
      pinned: !!row.pinned,
      blockedByMe: !!one(
        "SELECT 1 FROM dm_blocks WHERE username=? AND target=?",
        username,
        who,
      ),
      canSend: canSend(username, row),
      unread: Number(
        one(
          "SELECT COUNT(*) AS n FROM dm_messages WHERE conversation_id=? AND sender<>? AND seq>? AND deleted=0",
          row.id,
          username,
          row.read_seq,
        ).n,
      ),
      peerReadSeq: Number(
        one(
          "SELECT read_seq FROM dm_members WHERE conversation_id=? AND username=?",
          row.id,
          who,
        )?.read_seq || 0,
      ),
      lastMessage: message(username, last),
    };
  }
  function messageRow(username, id) {
    const row = one("SELECT * FROM dm_messages WHERE id=?", id);
    if (!row) throw dmError(404, "dm_message_not_found");
    member(username, row.conversation_id, true);
    return row;
  }
  function requireSend(username, id) {
    const c = member(username, id, true);
    if (!canSend(username, c)) throw dmError(403, "dm_sending_unavailable");
    return c;
  }
  function getInbox(username, after = null, active = true) {
    requireActor(username);
    if (active) presence.set(username, now());
    const rows = all(
      "SELECT c.*,m.read_seq,m.muted,m.archived,m.favorite,m.pinned FROM dm_members m JOIN dm_conversations c ON c.id=m.conversation_id WHERE m.username=? AND c.status IN ('accepted','pending') ORDER BY m.pinned DESC,m.favorite DESC,c.updated_at DESC LIMIT 200",
      username,
    ).map((row) => conversation(username, row));
    const max = Number(
      one(
        "SELECT COALESCE(MAX(seq),0) AS seq FROM dm_events WHERE username=?",
        username,
      ).seq,
    );
    const events =
      after === null
        ? []
        : all(
            "SELECT * FROM dm_events WHERE username=? AND seq>? ORDER BY seq LIMIT 100",
            username,
            after,
          ).map((row) => ({
            seq: Number(row.seq),
            kind: row.kind,
            conversationId: row.conversation_id,
            messageId: row.message_id,
            claimed: !!row.claimed,
          }));
    return {
      me: peer(username),
      goldBadgeNotificationPending:!!account(username)?.goldBadgeNotificationPending,
      conversations: rows.filter((c) => c.status === "accepted"),
      requests: rows.filter((c) => c.status === "pending"),
      settings: settings(username),
      events,
      cursor:
        after === null
          ? max
          : (events.at(-1)?.seq ?? Math.max(Number(after), max)),
    };
  }
  function createRequest(username, target) {
    requireActor(username);
    if (typeof target !== "string") throw dmError(400, "dm_invalid_user");
    target = target.replace(/^@/, "").trim();
    if (target === username) throw dmError(400, "dm_self_request");
    if (!account(target)) throw dmError(404, "dm_user_not_found");
    if (blocked(username, target)) throw dmError(403, "dm_sending_unavailable");
    return transaction(() => {
      const pair = [username, target].sort().join("\n");
      let c = one("SELECT * FROM dm_conversations WHERE pair_key=?", pair);
      if (
        c?.status === "accepted" ||
        (c?.status === "pending" && c.initiator === username)
      ) {
        run("UPDATE dm_members SET archived=0 WHERE conversation_id=? AND username=?", c.id, username);
        return conversation(username, member(username, c.id));
      }
      if (c?.status === "pending" && c.initiator !== username) {
        run(
          "UPDATE dm_conversations SET status='accepted',updated_at=? WHERE id=?",
          now(),
          c.id,
        );
        emitBoth(c.id, "accepted");
        return conversation(username, member(username, c.id));
      }
      if (c && now() - c.updated_at < 86400000)
        throw dmError(429, "dm_request_cooldown");
      if (
        Number(
          one(
            "SELECT COUNT(*) AS n FROM dm_events WHERE username=? AND kind='request_sent' AND created_at>?",
            username,
            now() - 86400000,
          ).n,
        ) >= 20
      )
        throw dmError(429, "dm_rate_limited");
      const status = settings(target).autoAccept ? "accepted" : "pending";
      if (c) {
        run(
          "UPDATE dm_conversations SET initiator=?,status=?,updated_at=? WHERE id=?",
          username,
          status,
          now(),
          c.id,
        );
      } else {
        c = { id: randomUUID() };
        run(
          "INSERT INTO dm_conversations VALUES(?,?,?,?,?,?)",
          c.id,
          pair,
          username,
          status,
          now(),
          now(),
        );
        for (const u of [username, target])
          run(
            "INSERT INTO dm_members(conversation_id,username) VALUES(?,?)",
            c.id,
            u,
          );
      }
      emit(username, "request_sent", c.id);
      emit(target, status === "accepted" ? "accepted" : "request", c.id);
      return conversation(username, member(username, c.id));
    });
  }
  function respond(username, id, action) {
    return transaction(() => {
      const c = member(username, id);
      if (!["accept", "decline", "cancel"].includes(action))
        throw dmError(400, "dm_invalid_action");
      if (c.status !== "pending") throw dmError(409, "dm_request_processed");
      if (
        action === "cancel"
          ? c.initiator !== username
          : c.initiator === username
      )
        throw dmError(403, "forbidden");
      if (action === "accept" && blocked(username, other(username, id)))
        throw dmError(403, "dm_sending_unavailable");
      run(
        "UPDATE dm_conversations SET status=?,updated_at=? WHERE id=?",
        action === "accept"
          ? "accepted"
          : action === "decline"
            ? "declined"
            : "cancelled",
        now(),
        id,
      );
      emitBoth(id, action === "accept" ? "accepted" : "request_closed");
      return { ok: true };
    });
  }
  function getMessages(
    username,
    id,
    { before, after, search = "", filter = "all", limit = 40 } = {},
  ) {
    const c = member(username, id, true);
    let sql = "SELECT m.* FROM dm_messages m WHERE m.conversation_id=?";
    const args = [id];
    if (before) {
      sql += " AND m.seq<?";
      args.push(before);
    }
    if (after) {
      sql += " AND m.seq>?";
      args.push(after);
    }
    if (search) {
      sql += " AND m.deleted=0 AND m.content LIKE ? ESCAPE '\\'";
      args.push("%" + search.replace(/[\\%_]/g, "\\$&") + "%");
    }
    if (filter === "pinned") sql += " AND m.pinned=1 AND m.deleted=0";
    else if (filter === "bookmarks") {
      sql +=
        " AND m.deleted=0 AND EXISTS(SELECT 1 FROM dm_bookmarks b WHERE b.message_id=m.id AND b.username=?)";
      args.push(username);
    } else if (filter === "links")
      sql +=
        " AND m.deleted=0 AND (m.content LIKE '%https://%' OR m.content LIKE '%http://%')";
    else if (filter === "media")
      sql +=
        " AND m.deleted=0 AND EXISTS(SELECT 1 FROM dm_attachments a JOIN dm_blobs b ON b.id=a.blob_id WHERE a.message_id=m.id AND (b.mime LIKE 'image/%' OR b.mime LIKE 'video/%' OR b.mime LIKE 'audio/%'))";
    else if (filter === "files")
      sql +=
        " AND m.deleted=0 AND EXISTS(SELECT 1 FROM dm_attachments a WHERE a.message_id=m.id)";
    else if (filter !== "all") throw dmError(400, "dm_invalid_filter");
    sql += " ORDER BY m.seq DESC LIMIT ?";
    args.push(Math.min(50, Math.max(1, limit)));
    const rows = all(sql, ...args).reverse();
    const who = other(username, id);
    return {
      messages: rows.map((row) => message(username, row)),
      hasMore: rows.length === Math.min(50, Math.max(1, limit)),
      conversation: conversation(username, c),
      typing: (typing.get(id + ":" + who) || 0) > now() - 6000,
    };
  }
  function send(
    username,
    id,
    {
      content = "",
      replyId = null,
      attachmentIds = [],
      nonce,
      forwardId = null,
    },
  ) {
    requireSend(username, id);
    if (
      typeof content !== "string" ||
      content.length > 4000 ||
      typeof nonce !== "string" ||
      !/^[a-zA-Z0-9-]{16,80}$/.test(nonce) ||
      !Array.isArray(attachmentIds) ||
      attachmentIds.length > 4
    )
      throw dmError(400, "dm_invalid_message");
    const duplicate = one(
      "SELECT * FROM dm_messages WHERE sender=? AND nonce=?",
      username,
      nonce,
    );
    if (duplicate) {
      if (duplicate.conversation_id !== id)
        throw dmError(409, "dm_nonce_conflict");
      return message(username, duplicate);
    }
    rate(username, "send", 30, 10000);
    return transaction(() => {
      let forward = null;
      if (forwardId) {
        forward = messageRow(username, forwardId);
        if (forward.deleted) throw dmError(404, "dm_message_not_found");
        if (attachmentIds.length || content || replyId)
          throw dmError(400, "dm_invalid_message");
        content = forward.content;
      }
      if (replyId) {
        const reply = messageRow(username, replyId);
        if (reply.conversation_id !== id || reply.deleted)
          throw dmError(400, "dm_invalid_reply");
      }
      const owned = attachmentIds.map((a) => {
        if (typeof a !== "string") throw dmError(400, "dm_invalid_attachment");
        const row = one(
          "SELECT * FROM dm_attachments WHERE id=? AND conversation_id=? AND uploader=? AND message_id IS NULL",
          a,
          id,
          username,
        );
        if (!row) throw dmError(400, "dm_invalid_attachment");
        return row;
      });
      if (new Set(attachmentIds).size !== attachmentIds.length)
        throw dmError(400, "dm_invalid_attachment");
      const forwardedAttachments = forward
        ? all("SELECT * FROM dm_attachments WHERE message_id=?", forward.id)
        : [];
      if (!content.trim() && !owned.length && !forwardedAttachments.length)
        throw dmError(400, "dm_empty_message");
      const mid = randomUUID();
      run(
        "INSERT INTO dm_messages(id,conversation_id,sender,content,reply_id,forwarded_from,nonce,created_at) VALUES(?,?,?,?,?,?,?,?)",
        mid,
        id,
        username,
        content.trim(),
        replyId,
        forward?.sender || null,
        nonce,
        now(),
      );
      for (const a of owned)
        run("UPDATE dm_attachments SET message_id=? WHERE id=?", mid, a.id);
      for (const a of forwardedAttachments)
        run(
          "INSERT INTO dm_attachments VALUES(?,?,?,?,?,?)",
          randomUUID(),
          id,
          a.blob_id,
          username,
          mid,
          now(),
        );
      run("UPDATE dm_conversations SET updated_at=? WHERE id=?", now(), id);
      run("UPDATE dm_members SET archived=0 WHERE conversation_id=?", id);
      const row = one("SELECT * FROM dm_messages WHERE id=?", mid);
      run(
        "UPDATE dm_members SET read_seq=? WHERE conversation_id=? AND username=?",
        row.seq,
        id,
        username,
      );
      typing.delete(id + ":" + username);
      emitBoth(id, "message", mid);
      return message(username, row);
    });
  }
  function edit(username, id, content) {
    const row = messageRow(username, id);
    if (row.sender !== username) throw dmError(403, "forbidden");
    if (
      row.deleted ||
      typeof content !== "string" ||
      content.length > 4000 ||
      (!content.trim() && !attachments(id).length)
    )
      throw dmError(400, "dm_invalid_message");
    run(
      "UPDATE dm_messages SET content=?,edited_at=? WHERE id=?",
      content.trim(),
      now(),
      id,
    );
    emitBoth(row.conversation_id, "edited", id);
    return message(username, one("SELECT * FROM dm_messages WHERE id=?", id));
  }
  function remove(username, id) {
    const row = messageRow(username, id);
    if (row.sender !== username) throw dmError(403, "forbidden");
    return transaction(() => {
      run(
        "UPDATE dm_messages SET deleted=1,content='',pinned=0 WHERE id=?",
        id,
      );
      run("DELETE FROM dm_reactions WHERE message_id=?", id);
      run("DELETE FROM dm_bookmarks WHERE message_id=?", id);
      run("DELETE FROM dm_attachments WHERE message_id=?", id);
      run(
        "DELETE FROM dm_blobs WHERE NOT EXISTS(SELECT 1 FROM dm_attachments a WHERE a.blob_id=dm_blobs.id)",
      );
      emitBoth(row.conversation_id, "deleted", id);
      return { ok: true };
    });
  }
  function messageAction(username, id, { action, value }) {
    const row = messageRow(username, id);
    if (row.deleted) throw dmError(404, "dm_message_not_found");
    if (action === "reaction") {
      requireSend(username, row.conversation_id);
      if (!REACTIONS.includes(value)) throw dmError(400, "dm_invalid_reaction");
      if (
        one(
          "SELECT 1 FROM dm_reactions WHERE message_id=? AND username=? AND emoji=?",
          id,
          username,
          value,
        )
      )
        run(
          "DELETE FROM dm_reactions WHERE message_id=? AND username=? AND emoji=?",
          id,
          username,
          value,
        );
      else run("INSERT INTO dm_reactions VALUES(?,?,?)", id, username, value);
    } else if (action === "pin") {
      requireSend(username, row.conversation_id);
      run("UPDATE dm_messages SET pinned=? WHERE id=?", row.pinned ? 0 : 1, id);
    } else if (action === "bookmark") {
      if (
        one(
          "SELECT 1 FROM dm_bookmarks WHERE message_id=? AND username=?",
          id,
          username,
        )
      )
        run(
          "DELETE FROM dm_bookmarks WHERE message_id=? AND username=?",
          id,
          username,
        );
      else run("INSERT INTO dm_bookmarks VALUES(?,?)", id, username);
    } else if (action === "unread") {
      run(
        "UPDATE dm_members SET read_seq=MIN(read_seq,?) WHERE conversation_id=? AND username=?",
        Math.max(0, Number(row.seq) - 1),
        row.conversation_id,
        username,
      );
    } else throw dmError(400, "dm_invalid_action");
    emitBoth(row.conversation_id, "changed", id);
    return { ok: true };
  }
  function read(username, id, seq) {
    const current = member(username, id, true);
    const maximum = Number(
      one(
        "SELECT COALESCE(MAX(seq),0) AS seq FROM dm_messages WHERE conversation_id=?",
        id,
      ).seq,
    );
    if (seq === undefined) seq = maximum;
    if (!Number.isSafeInteger(seq) || seq < 0 || seq > maximum)
      throw dmError(400, "dm_invalid_cursor");
    if (seq <= current.read_seq) return { ok: true };
    run(
      "UPDATE dm_members SET read_seq=MAX(read_seq,?) WHERE conversation_id=? AND username=?",
      seq,
      id,
      username,
    );
    emit(other(username, id), "read", id);
    return { ok: true };
  }
  function updateConversation(username, id, patch) {
    member(username, id, true);
    if (
      !patch ||
      typeof patch !== "object" ||
      Array.isArray(patch) ||
      Object.keys(patch).some((k) => !["muted", "archived", "favorite", "pinned"].includes(k)) ||
      Object.values(patch).some((v) => typeof v !== "boolean")
    )
      throw dmError(400, "dm_invalid_settings");
    for (const key of ["muted", "archived", "favorite", "pinned"])
      if (key in patch)
        run(
          `UPDATE dm_members SET ${key}=? WHERE conversation_id=? AND username=?`,
          patch[key] ? 1 : 0,
          id,
          username,
        );
    return { ok: true };
  }
  function updateSettings(username, patch) {
    requireActor(username);
    if (
      !patch ||
      typeof patch !== "object" ||
      Array.isArray(patch) ||
      Object.keys(patch).some((k) => !(k in defaults)) ||
      Object.entries(patch).some(([k, v]) =>
        k === "quickReaction" ? !REACTIONS.includes(v) : k === "longPressMs" ? !Number.isInteger(v) || v < 100 || v > 2000 : typeof v !== "boolean",
      )
    )
      throw dmError(400, "dm_invalid_settings");
    const value = { ...settings(username), ...patch };
    run(
      "INSERT INTO dm_settings VALUES(?,?) ON CONFLICT(username) DO UPDATE SET value=excluded.value",
      username,
      JSON.stringify(value),
    );
    return value;
  }
  function block(username, target, value) {
    requireActor(username);
    if (!account(target) || target === username || typeof value !== "boolean")
      throw dmError(400, "dm_invalid_user");
    if (value)
      run("INSERT OR IGNORE INTO dm_blocks VALUES(?,?)", username, target);
    else
      run(
        "DELETE FROM dm_blocks WHERE username=? AND target=?",
        username,
        target,
      );
    const c = one(
      "SELECT id FROM dm_conversations WHERE pair_key=?",
      [username, target].sort().join("\n"),
    );
    if (c) emitBoth(c.id, "changed");
    return { ok: true };
  }
  function upload(username, id, { name, mime, data }) {
    requireSend(username, id);
    rate(username, "upload", 12, 60000);
    if (
      typeof name !== "string" ||
      !name.trim() ||
      name.length > 160 ||
      typeof mime !== "string" ||
      typeof data !== "string" ||
      data.length > Math.ceil(DM_FILE_LIMIT / 3) * 4 ||
      !/^[A-Za-z0-9+/]+={0,2}$/.test(data)
    )
      throw dmError(400, "dm_invalid_attachment");
    const bytes = Buffer.from(data, "base64");
    if (
      !bytes.length ||
      bytes.length > DM_FILE_LIMIT ||
      bytes.toString("base64") !== data
    )
      throw dmError(413, "dm_file_too_large");
    mime = mime.toLowerCase().split(";")[0];
    const imageOk =
      (mime === "image/png" &&
        bytes.subarray(0, 8).toString("hex") === "89504e470d0a1a0a") ||
      (mime === "image/jpeg" && bytes[0] === 255 && bytes[1] === 216) ||
      (mime === "image/gif" &&
        ["GIF87a", "GIF89a"].includes(bytes.subarray(0, 6).toString())) ||
      (mime === "image/webp" &&
        bytes.toString("ascii", 0, 4) === "RIFF" &&
        bytes.toString("ascii", 8, 12) === "WEBP");
    const mediaOk =
      (["video/mp4", "audio/mp4"].includes(mime) &&
        bytes.toString("ascii", 4, 8) === "ftyp") ||
      (["video/webm", "audio/webm"].includes(mime) &&
        bytes.subarray(0, 4).toString("hex") === "1a45dfa3") ||
      (mime === "audio/ogg" && bytes.toString("ascii", 0, 4) === "OggS") ||
      (mime === "audio/mpeg" &&
        (bytes.toString("ascii", 0, 3) === "ID3" || bytes[0] === 255));
    if (!imageOk && !mediaOk) mime = "application/octet-stream";
    return transaction(() => {
      const used = Number(
        one(
          "SELECT COALESCE(SUM(size),0) AS n FROM dm_blobs WHERE owner=?",
          username,
        ).n,
      );
      const total = Number(
        one("SELECT COALESCE(SUM(size),0) AS n FROM dm_blobs").n,
      );
      if (total + bytes.length > 1024 * 1024 * 1024)
        throw dmError(413, "dm_storage_full");
      if (used + bytes.length > DM_MEDIA_QUOTA)
        throw dmError(413, "dm_media_quota");
      const blob = randomUUID(),
        aid = randomUUID();
      name = name.replace(/[\x00-\x1f\x7f/\\]/g, "_");
      run(
        "INSERT INTO dm_blobs VALUES(?,?,?,?,?,?)",
        blob,
        username,
        name,
        mime,
        bytes.length,
        bytes,
      );
      run(
        "INSERT INTO dm_attachments VALUES(?,?,?,?,NULL,?)",
        aid,
        id,
        blob,
        username,
        now(),
      );
      return { id: aid, name, mime, size: bytes.length };
    });
  }
  function download(username, id) {
    const row = one(
      "SELECT a.*,b.name,b.mime,b.size,b.data FROM dm_attachments a JOIN dm_blobs b ON b.id=a.blob_id WHERE a.id=?",
      id,
    );
    if (!row) throw dmError(404, "dm_attachment_not_found");
    member(username, row.conversation_id, true);
    if (row.message_id) {
      const m = one(
        "SELECT deleted FROM dm_messages WHERE id=?",
        row.message_id,
      );
      if (!m || m.deleted) throw dmError(404, "dm_attachment_not_found");
    } else if (row.uploader !== username)
      throw dmError(404, "dm_attachment_not_found");
    return {
      id,
      name: row.name,
      mime: row.mime,
      size: Number(row.size),
      data: Buffer.from(row.data).toString("base64"),
    };
  }
  function claim(username, seq) {
    const e = one(
      "SELECT * FROM dm_events WHERE username=? AND seq=?",
      username,
      seq,
    );
    if (!e || e.claimed || !["message", "request"].includes(e.kind))
      return { claimed: false };
    const c = member(username, e.conversation_id);
    if (e.kind === "request" && c.status !== "pending")
      return { claimed: false };
    if (e.message_id) {
      const m = one(
        "SELECT seq,deleted FROM dm_messages WHERE id=?",
        e.message_id,
      );
      if (!m || m.deleted || m.seq <= c.read_seq) return { claimed: false };
    }
    const prefs = settings(username);
    if (
      !prefs.notifications ||
      c.muted ||
      (e.kind === "message" &&
        one("SELECT sender FROM dm_messages WHERE id=?", e.message_id)
          ?.sender === username)
    )
      return { claimed: false };
    const changed = run(
      "UPDATE dm_events SET claimed=1 WHERE seq=? AND username=? AND claimed=0",
      seq,
      username,
    );
    return {
      claimed: changed.changes === 1,
      conversation: conversation(username, c),
      message: e.message_id
        ? message(
            username,
            one("SELECT * FROM dm_messages WHERE id=?", e.message_id),
          )
        : null,
      kind: e.kind,
    };
  }
  function setTyping(username, id, active) {
    requireSend(username, id);
    if (active) typing.set(id + ":" + username, now());
    else typing.delete(id + ":" + username);
    return { ok: true };
  }
  function discardAttachment(username, id) {
    const row = one(
      "SELECT * FROM dm_attachments WHERE id=? AND uploader=? AND message_id IS NULL",
      id,
      username,
    );
    if (!row) throw dmError(404, "dm_attachment_not_found");
    run("DELETE FROM dm_attachments WHERE id=?", id);
    run(
      "DELETE FROM dm_blobs WHERE NOT EXISTS(SELECT 1 FROM dm_attachments a WHERE a.blob_id=dm_blobs.id)",
    );
    return { ok: true };
  }
  return {
    getMessage(username,id) {return message(username,messageRow(username,id));},
    getInbox,
    createRequest,
    respond,
    getMessages,
    send,
    edit,
    remove,
    messageAction,
    read,
    updateConversation,
    updateSettings,
    block,
    upload,
    download,
    claim,
    setTyping,
    discardAttachment,
    getPeer(username, target) {
      requireActor(username);
      if (!account(target)) throw dmError(404, "dm_user_not_found");
      return peer(target);
    },
    close() {
      db.close();
    },
  };
}
