export const MB = 1024 * 1024;
export const DM_FILE_LIMIT = 50 * MB;
export const DM_UPLOAD_BODY_LIMIT = Math.ceil(DM_FILE_LIMIT / 3) * 4 + 16 * 1024;
const DAY = 86400000;
// UTC calendar months, clamped to the final day of the destination month.
function monthsAfter(timestamp, months) {
  const date = new Date(timestamp), day = date.getUTCDate();
  date.setUTCDate(1);date.setUTCMonth(date.getUTCMonth() + months);
  const last = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth() + 1, 0)).getUTCDate();
  date.setUTCDate(Math.min(day, last));return date.getTime();
}
export function mediaExpiresAt(size, createdAt) {
  if (size < 8 * MB) return null;
  if (size <= 16 * MB) return monthsAfter(createdAt, 6);
  if (size <= 28 * MB) return monthsAfter(createdAt, 3);
  if (size <= 40 * MB) return createdAt + 15 * DAY;
  return createdAt + 7 * DAY;
}
