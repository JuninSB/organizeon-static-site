import {readFile,stat,realpath} from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import {resolve,sep,extname} from 'node:path';
const prefix='/d1/live/';
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.wasm':'application/wasm','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.gif':'image/gif','.ico':'image/x-icon','.woff2':'font/woff2','.woff':'font/woff','.txt':'text/plain; charset=utf-8','.mp3':'audio/mpeg','.mp4':'video/mp4'};
export function createLiveClientHandler({root}){
 let cached;
 return async function(request,response){
  const url=new URL(request.url,'http://live.invalid');
  if(url.pathname!=='/d1/live'&&!url.pathname.startsWith(prefix))return false;
  if(!['GET','HEAD'].includes(request.method)){response.writeHead(405,{Allow:'GET, HEAD'});response.end();return true;}
  if(url.pathname==='/d1/live'){response.writeHead(302,{Location:prefix+url.search,'Cache-Control':'no-store'});response.end();return true;}
  try{
   const info=await stat(resolve(root,'live-files.json'));
   if(!cached||cached.modified!==info.mtimeMs){const data=JSON.parse(await readFile(resolve(root,'live-files.json'),'utf8'));cached={modified:info.mtimeMs,files:new Set(data.files),base:await realpath(root)};}
   let path=decodeURIComponent(url.pathname.slice(prefix.length));
   if(!path)path='index.html';
   if(path.split('/').some(part=>part==='..'||part.startsWith('.'))||path.includes('\\')||path.includes('\0')){response.writeHead(404);response.end();return true;}
   if(!cached.files.has(path)){
    if(!extname(path)&&String(request.headers.accept||'').includes('text/html'))path='index.html';
    else{response.writeHead(404);response.end();return true;}
   }
   const full=await realpath(resolve(root,path));if(!full.startsWith(cached.base+sep))throw Error('Invalid live path');
   const file=await stat(full);if(!file.isFile())throw Error('Not a file');
   const etag='"'+file.size+'-'+Math.trunc(file.mtimeMs)+'"';
   const headers={'Content-Type':types[extname(path)]||'application/octet-stream','Cache-Control':path.endsWith('.html')?'no-cache':'public, max-age=0, must-revalidate','X-Content-Type-Options':'nosniff','Service-Worker-Allowed':prefix,ETag:etag};
   if(request.headers['if-none-match']===etag){response.writeHead(304,headers);response.end();return true;}
   response.writeHead(200,{...headers,'Content-Length':file.size});
   if(request.method==='HEAD')response.end();else createReadStream(full).on('error',()=>response.destroy()).pipe(response);
  }catch{response.writeHead(503,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store'});response.end('Cliente web temporariamente indisponível.');}
  return true;
 };
}
