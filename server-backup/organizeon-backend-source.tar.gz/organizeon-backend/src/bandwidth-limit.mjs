import {
  NodeTCPSocket,
  NodeUDPSocket,
} from "../node_modules/@mercuryworkshop/wisp-js/src/server/net.mjs";

export class SharedBandwidthLimiter {
  constructor({
    bitsPerSecond,
    burstBytes = 512 * 1024,
    now = () => performance.now(),
    sleep = (milliseconds) =>
      new Promise((resolve) => setTimeout(resolve, milliseconds)),
  }) {
    this.bytesPerSecond = bitsPerSecond / 8;
    this.burstBytes = burstBytes;
    this.tokens = burstBytes;
    this.lastRefillAt = now();
    this.now = now;
    this.sleep = sleep;
    this.queue = Promise.resolve();
  }

  consume(bytes) {
    const operation = this.queue.then(() => this.consumeQueued(bytes));
    this.queue = operation.catch(() => {});
    return operation;
  }

  async consumeQueued(bytes) {
    this.refill();
    if (bytes <= this.tokens) {
      this.tokens -= bytes;
      return;
    }
    const missingBytes = bytes - this.tokens;
    this.tokens = 0;
    await this.sleep((missingBytes / this.bytesPerSecond) * 1000);
    this.lastRefillAt = this.now();
  }

  refill() {
    const now = this.now();
    const elapsedSeconds = Math.max(0, now - this.lastRefillAt) / 1000;
    this.tokens = Math.min(
      this.burstBytes,
      this.tokens + elapsedSeconds * this.bytesPerSecond,
    );
    this.lastRefillAt = now;
  }
}

export function isLimitedHostname(
  hostname,
  limitedHostnames = ["googlevideo.com"],
) {
  const normalizedHostname = String(hostname || "")
    .toLowerCase()
    .replace(/\.$/, "");
  return limitedHostnames.some((limitedHostname) => {
    const normalizedLimitedHostname = String(limitedHostname)
      .toLowerCase()
      .replace(/^\*\./, "")
      .replace(/\.$/, "");
    return (
      normalizedHostname === normalizedLimitedHostname ||
      normalizedHostname.endsWith(`.${normalizedLimitedHostname}`)
    );
  });
}

export function createLimitedSocketOptions(
  limiter,
  { limitedHostnames = ["googlevideo.com"] } = {},
) {
  return {
    TCPSocket: class LimitedTCPSocket extends NodeTCPSocket {
      async recv() {
        const data = await super.recv();
        if (data === null || data === undefined) return data;
        if (!isLimitedHostname(this.hostname, limitedHostnames)) return data;
        this.socket?.pause();
        await limiter.consume(data.byteLength);
        this.socket?.resume();
        return data;
      }
    },
    UDPSocket: class LimitedUDPSocket extends NodeUDPSocket {
      async recv() {
        const data = await super.recv();
        if (data === null || data === undefined) return data;
        if (!isLimitedHostname(this.hostname, limitedHostnames)) return data;
        await limiter.consume(data.byteLength);
        return data;
      }
    },
  };
}
