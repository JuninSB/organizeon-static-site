/** Tracks authenticated sockets without retaining tokens or account secrets. */
export function createSessionConnections() {
  const connections = new Map();
  return {
    track(username, socket) {
      let sockets = connections.get(username);
      if (!sockets) connections.set(username, sockets = new Set());
      if (sockets.has(socket)) return;
      sockets.add(socket);
      socket.once('close', () => {
        sockets.delete(socket);
        if (!sockets.size && connections.get(username) === sockets) connections.delete(username);
      });
    },
    revoke(username) {
      const sockets = connections.get(username);
      if (!sockets) return 0;
      connections.delete(username);
      const count = sockets.size;
      for (const socket of [...sockets]) socket.destroy();
      return count;
    },
  };
}
