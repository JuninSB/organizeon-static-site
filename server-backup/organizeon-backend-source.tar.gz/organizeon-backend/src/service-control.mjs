import { spawn } from "node:child_process";
import { join } from "node:path";

const VALID_ACTIONS = new Set(["start", "stop", "restart"]);

export function createServiceControl({
  definitions,
  runner = runServiceCommand,
  statusReader = readServiceStatus,
}) {
  const services = new Map(definitions.map((definition) => [definition.id, {
    ...definition,
    actions: [...definition.actions],
  }]));

  return Object.freeze({
    list(account) {
      return [...services.values()]
        .filter((service) => account.permissions.includes(service.permission))
        .map(publicService);
    },

    async listWithStatus(account) {
      const visible = [...services.values()]
        .filter((service) => account.permissions.includes(service.permission));
      return Promise.all(visible.map(async (service) => ({
        ...publicService(service),
        status: await statusReader(service.serviceName),
      })));
    },

    async execute(account, id, action) {
      const service = services.get(id);
      if (!service) throw serviceError(404, "service_not_found");
      if (!account.permissions.includes(service.permission)) {
        throw serviceError(403, "forbidden");
      }
      if (!VALID_ACTIONS.has(action) || !service.actions.includes(action)) {
        throw serviceError(400, "action_not_allowed");
      }
      await runner(service.serviceName, action);
      return { service: publicService(service), action };
    },
  });
}

function publicService(service) {
  return {
    id: service.id,
    label: service.label,
    actions: [...service.actions],
  };
}

function runServiceCommand(serviceName, action) {
  const serviceDirectory = process.env.SVDIR || join(
    process.env.PREFIX || "/data/data/com.termux/files/usr",
    "var/service",
  );
  const target = join(serviceDirectory, serviceName);
  if (action === "restart") {
    const timer = setTimeout(() => {
      const child = spawn("sv", ["restart", target], {
        detached: true,
        stdio: "ignore",
      });
      child.unref();
    }, 400);
    timer.unref();
    return Promise.resolve();
  }
  return new Promise((resolve, reject) => {
    const child = spawn("sv", [action, target], { stdio: "ignore" });
    child.once("error", reject);
    child.once("exit", (code) => {
      if (code === 0) resolve();
      else reject(serviceError(502, "service_command_failed"));
    });
  });
}

function readServiceStatus(serviceName) {
  return new Promise((resolve) => {
    const serviceDirectory = process.env.SVDIR || join(
      process.env.PREFIX || "/data/data/com.termux/files/usr",
      "var/service",
    );
    const child = spawn("sv", ["status", join(serviceDirectory, serviceName)], {
      stdio: ["ignore", "pipe", "pipe"],
    });
    let output = "";
    let settled = false;
    const finish = (status) => {
      if (settled) return;
      settled = true;
      resolve({
        state: "unknown",
        label: "Indisponível",
        detail: "O gerenciador não informou o estado.",
        pid: null,
        uptimeSeconds: null,
        ...status,
      });
    };
    child.stdout.on("data", (chunk) => { output += chunk; });
    child.stderr.on("data", (chunk) => { output += chunk; });
    child.once("error", () => finish({}));
    child.once("exit", () => {
      const detail = output.trim().replace(/\s+/g, " ").slice(0, 240);
      const pid = Number(detail.match(/\(pid\s+(\d+)\)/i)?.[1]) || null;
      const uptimeSeconds = Number(
        detail.match(/(?:\(pid\s+\d+\)\s+|:\s+)(\d+)s(?:,|;|$)/i)?.[1],
      );
      if (/^run:/i.test(detail)) {
        const paused = /paused/i.test(detail);
        return finish({
          state: paused ? "paused" : "running",
          label: paused ? "Pausado" : "Online",
          detail,
          pid,
          uptimeSeconds: Number.isFinite(uptimeSeconds) ? uptimeSeconds : null,
        });
      }
      if (/^down:/i.test(detail)) {
        return finish({
          state: "stopped",
          label: "Desligado",
          detail,
          uptimeSeconds: Number.isFinite(uptimeSeconds) ? uptimeSeconds : null,
        });
      }
      return finish({ detail: detail || undefined });
    });
  });
}

function serviceError(statusCode, code) {
  return Object.assign(new Error(code), { statusCode, code });
}
