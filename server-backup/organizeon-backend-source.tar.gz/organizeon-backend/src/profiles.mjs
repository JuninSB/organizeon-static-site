import { createHash } from "node:crypto";
const SHAPES = new Set(['circle','square','rounded']);
export function publicProfile(account) {
 const p=account.profile||{};
 const goldBadge=!!account.goldBadge?.awardedBy;
 return {bannerImage:p.bannerImage||null,bannerFit:p.bannerFit==='fill'?'fill':'cover',bannerColor:goldBadge&&/^#[0-9a-f]{6}$/i.test(p.bannerColor||'')?p.bannerColor:null,displayName:p.displayName||account.username,nameColor:p.nameColor||'#FAFAFA',bio:p.bio||'',avatarShape:SHAPES.has(p.avatarShape)?p.avatarShape:'circle',avatar:p.avatar||null,goldBadge,bannerSeed:/^[a-f0-9]{32}$/.test(account.profileBanner?.seed||'')?account.profileBanner.seed:createHash('sha256').update(account.username).digest('hex').slice(0,32),bannerRerollAvailableAt:account.role==='owner'?null:account.profileBanner?.nextRerollAt||null,bannerRerollUnlimited:account.role==='owner',showGoldBadge:goldBadge&&p.showGoldBadge!==false,bannerStyle:p.bannerImage?'image':goldBadge&&['lava','slime','bubbles','gradient','magma','stars','rainbow'].includes(p.bannerStyle||'lava')?(p.bannerStyle||'lava'):'solid'};
}
function invalid(){return Object.assign(new Error('invalid_profile'),{statusCode:400,code:'invalid_profile'});}
export function validateProfile(input,account) {
 if(!input||typeof input!=='object'||Array.isArray(input))throw invalid();
 const allowed=['bannerImage','bannerFit','bannerColor','displayName','nameColor','bio','avatarShape','avatar','showGoldBadge','bannerStyle'];
 if(Object.keys(input).some(k=>!allowed.includes(k)))throw invalid();
 const p={...publicProfile(account),...input};
 if(!['cover','fill'].includes(p.bannerFit))throw invalid();
 validateBannerImage(p.bannerImage);
 if(p.bannerColor!==null&&(!/^#[0-9a-f]{6}$/i.test(p.bannerColor)||!account.goldBadge?.awardedBy))throw invalid();
 if(p.bannerImage && input.bannerStyle===undefined)p.bannerStyle='image';
 if(p.bannerStyle==='image'&&!p.bannerImage){if(input.bannerStyle==='image')throw invalid();p.bannerStyle='solid';}
 if(typeof p.showGoldBadge!=='boolean'||!['solid','image','lava','slime','bubbles','gradient','magma','stars','rainbow'].includes(p.bannerStyle))throw invalid();
 if(((input.bannerStyle&&!['solid','image'].includes(input.bannerStyle))||input.showGoldBadge===true)&&!account.goldBadge?.awardedBy)throw invalid();
 if(p.bannerStyle!=='image')p.bannerImage=null;
 if(typeof p.displayName!=='string'||!p.displayName.trim()||p.displayName.trim().length>40||/[\x00-\x1f\x7f]/.test(p.displayName))throw invalid();
 if(typeof p.bio!=='string'||p.bio.length>280||/[\x00-\x08\x0b-\x1f\x7f]/.test(p.bio))throw invalid();
 if(!/^#[0-9a-f]{6}$/i.test(p.nameColor)||!SHAPES.has(p.avatarShape))throw invalid();
 if(p.avatar!==null){
  if(typeof p.avatar!=='string'||p.avatar.length>132000)throw invalid();
  const match=p.avatar.match(/^data:image\/(jpeg|png);base64,([A-Za-z0-9+/]+={0,2})$/);if(!match)throw invalid();
  const bytes=Buffer.from(match[2],'base64');if(bytes.length>96*1024||bytes.toString('base64')!==match[2])throw invalid();
  let width=0,height=0;
  if(match[1]==='png'){
   if(bytes.length<45||bytes.subarray(0,8).toString('hex')!=='89504e470d0a1a0a'||bytes.toString('ascii',12,16)!=='IHDR')throw invalid();width=bytes.readUInt32BE(16);height=bytes.readUInt32BE(20);
   if(bytes.subarray(-12).toString('hex')!=='0000000049454e44ae426082')throw invalid();
  }else{
   if(bytes[0]!==255||bytes[1]!==216||bytes.at(-2)!==255||bytes.at(-1)!==217)throw invalid();
   for(let i=2;i+8<bytes.length;){if(bytes[i++]!==255)throw invalid();while(bytes[i]===255)i++;const marker=bytes[i++];if(marker===218||marker===217)break;if(marker===1||marker>=208&&marker<=215)continue;const length=bytes.readUInt16BE(i);if(length<2||i+length>bytes.length)throw invalid();if([192,193,194].includes(marker)){height=bytes.readUInt16BE(i+3);width=bytes.readUInt16BE(i+5);break;}i+=length;}
  }
  if(width<16||width>512||height!==width)throw invalid();
 }
 return {bannerImage:p.bannerImage,bannerFit:p.bannerFit,bannerColor:p.bannerColor,displayName:p.displayName.trim(),nameColor:p.nameColor,bio:p.bio.trim(),avatarShape:p.avatarShape,avatar:p.avatar,showGoldBadge:p.showGoldBadge,bannerStyle:p.bannerStyle};
}

function validateBannerImage(value){
 if(value===null)return;
 if(typeof value!=='string'||value.length>132000)throw invalid();
 const match=value.match(/^data:image\/jpeg;base64,([A-Za-z0-9+/]+={0,2})$/);
 if(!match)throw invalid();
 const bytes=Buffer.from(match[1],'base64');
 if(bytes.length<16||bytes.length>96*1024||bytes.toString('base64')!==match[1]||bytes[0]!==255||bytes[1]!==216||bytes.at(-2)!==255||bytes.at(-1)!==217)throw invalid();
 let width=0,height=0;
 for(let i=2;i+8<bytes.length;){
  if(bytes[i++]!==255)throw invalid();
  while(bytes[i]===255)i++;
  const marker=bytes[i++];
  if(marker===218||marker===217)break;
  if(marker===1||marker>=208&&marker<=215)continue;
  const length=bytes.readUInt16BE(i);
  if(length<2||i+length>bytes.length)throw invalid();
  if([192,193,194].includes(marker)){if(length<8)throw invalid();height=bytes.readUInt16BE(i+3);width=bytes.readUInt16BE(i+5);break;}
  i+=length;
 }
 if(width!==768||height!==256)throw invalid();
}
