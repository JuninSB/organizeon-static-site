const SHAPES = new Set(['circle','square','rounded']);
export function publicProfile(account) {
 const p=account.profile||{};
 return {displayName:p.displayName||account.username,nameColor:p.nameColor||'#FAFAFA',bio:p.bio||'',avatarShape:SHAPES.has(p.avatarShape)?p.avatarShape:'circle',avatar:p.avatar||null};
}
function invalid(){return Object.assign(new Error('invalid_profile'),{statusCode:400,code:'invalid_profile'});}
export function validateProfile(input,account) {
 if(!input||typeof input!=='object'||Array.isArray(input))throw invalid();
 const allowed=['displayName','nameColor','bio','avatarShape','avatar'];
 if(Object.keys(input).some(k=>!allowed.includes(k)))throw invalid();
 const p={...publicProfile(account),...input};
 if(typeof p.displayName!=='string'||!p.displayName.trim()||p.displayName.trim().length>40||/[\x00-\x1f\x7f]/.test(p.displayName))throw invalid();
 if(typeof p.bio!=='string'||p.bio.length>280||/[\x00-\x08\x0b-\x1f\x7f]/.test(p.bio))throw invalid();
 if(!/^#[0-9a-f]{6}$/i.test(p.nameColor)||!SHAPES.has(p.avatarShape))throw invalid();
 if(p.avatar!==null){
  if(typeof p.avatar!=='string'||p.avatar.length>132000)throw invalid();
  const match=p.avatar.match(/^data:image\/(jpeg|png);base64,([A-Za-z0-9+/]+={0,2})$/);if(!match)throw invalid();
  const bytes=Buffer.from(match[2],'base64');if(bytes.length>96*1024||bytes.toString('base64')!==match[2])throw invalid();
  let width=0,height=0;
  if(match[1]==='png'){
   if(bytes.length<45||bytes.subarray(0,8).toString('hex')!=='89504e470d0a1a0a'||bytes.toString('ascii',12,16)!=='IHDR')throw invalid();width=bytes.readUInt32BE(16);height=bytes.readUInt32BE(20);
   if(bytes.subarray(-12).toString('hex')!=='0000000049454e44ae426082')throw invalid();
  }else{
   if(bytes[0]!==255||bytes[1]!==216||bytes.at(-2)!==255||bytes.at(-1)!==217)throw invalid();
   for(let i=2;i+8<bytes.length;){if(bytes[i++]!==255)throw invalid();while(bytes[i]===255)i++;const marker=bytes[i++];if(marker===218||marker===217)break;if(marker===1||marker>=208&&marker<=215)continue;const length=bytes.readUInt16BE(i);if(length<2||i+length>bytes.length)throw invalid();if([192,193,194].includes(marker)){height=bytes.readUInt16BE(i+3);width=bytes.readUInt16BE(i+5);break;}i+=length;}
  }
  if(width<16||width>512||height!==width)throw invalid();
 }
 return {...p,displayName:p.displayName.trim(),bio:p.bio.trim()};
}
