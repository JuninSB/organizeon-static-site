import {
  createHmac,
  randomBytes,
  scryptSync,
  timingSafeEqual,
} from "node:crypto";

export const SESSION_TTL_SECONDS = 14 * 24 * 60 * 60;
export const COOKIE_NAME = "organizeon_session";

function encodeJson(value) {
  return Buffer.from(JSON.stringify(value)).toString("base64url");
}

function sign(value, secret) {
  return createHmac("sha256", secret).update(value).digest("base64url");
}

export function createSessionToken(account, secret, now = Date.now()) {
  const normalized =
    typeof account === "string"
      ? {
          username: account,
          role: "user",
          permissions: [],
          tokenVersion: 0,
        }
      : account;
  const issuedAt = Math.floor(now / 1000);
  const payload = encodeJson({
    sub: normalized.username,
    role: normalized.role,
    permissions: normalized.permissions,
    ver: normalized.tokenVersion,
    iat: issuedAt,
    exp: issuedAt + SESSION_TTL_SECONDS,
    jti: randomBytes(16).toString("base64url"),
  });
  return `${payload}.${sign(payload, secret)}`;
}

export function hashPassword(password) {
  if (typeof password !== "string" || password.length < 8) {
    throw new TypeError("Password must contain at least 8 characters");
  }
  const salt = randomBytes(16);
  const cost = 16384;
  const blockSize = 8;
  const parallelization = 1;
  const hash = scryptSync(password, salt, 32, {
    N: cost,
    r: blockSize,
    p: parallelization,
  });
  return [
    "scrypt",
    cost,
    blockSize,
    parallelization,
    salt.toString("base64url"),
    hash.toString("base64url"),
  ].join("$");
}

export function verifySessionToken(token, secret, now = Date.now()) {
  if (typeof token !== "string") return null;
  const [payload, signature, extra] = token.split(".");
  if (!payload || !signature || extra) return null;

  const expected = Buffer.from(sign(payload, secret));
  const received = Buffer.from(signature);
  if (
    expected.length !== received.length ||
    !timingSafeEqual(expected, received)
  ) {
    return null;
  }

  try {
    const claims = JSON.parse(
      Buffer.from(payload, "base64url").toString("utf8"),
    );
    const currentTime = Math.floor(now / 1000);
    if (
      typeof claims.sub !== "string" ||
      typeof claims.role !== "string" ||
      !Array.isArray(claims.permissions) ||
      !claims.permissions.every(
        (permission) => typeof permission === "string",
      ) ||
      !Number.isInteger(claims.ver) ||
      typeof claims.exp !== "number" ||
      typeof claims.iat !== "number" ||
      claims.exp <= currentTime ||
      claims.iat > currentTime + 60
    ) {
      return null;
    }
    return claims;
  } catch {
    return null;
  }
}

export function verifyPassword(password, encodedHash) {
  if (typeof password !== "string" || typeof encodedHash !== "string") {
    return false;
  }

  const [algorithm, n, r, p, saltValue, hashValue, extra] =
    encodedHash.split("$");
  if (
    algorithm !== "scrypt" ||
    extra ||
    !n ||
    !r ||
    !p ||
    !saltValue ||
    !hashValue
  ) {
    return false;
  }

  try {
    const expected = Buffer.from(hashValue, "base64url");
    const actual = scryptSync(
      password,
      Buffer.from(saltValue, "base64url"),
      expected.length,
      {
        N: Number(n),
        r: Number(r),
        p: Number(p),
      },
    );
    return (
      actual.length === expected.length && timingSafeEqual(actual, expected)
    );
  } catch {
    return false;
  }
}

export function parseCookies(header = "") {
  const cookies = new Map();
  for (const part of header.split(";")) {
    const separator = part.indexOf("=");
    if (separator === -1) continue;
    const name = part.slice(0, separator).trim();
    const value = part.slice(separator + 1).trim();
    if (name) cookies.set(name, decodeURIComponent(value));
  }
  return cookies;
}

export function readToken(request, requestUrl) {
  const authorization = request.headers.authorization;
  if (authorization?.startsWith("Bearer ")) {
    return authorization.slice("Bearer ".length).trim();
  }

  const cookieToken = parseCookies(request.headers.cookie).get(COOKIE_NAME);
  if (cookieToken) return cookieToken;

  return requestUrl.searchParams.get("access_token");
}

export function sessionCookie(token, apiPrefix, secure) {
  const attributes = [
    `${COOKIE_NAME}=${encodeURIComponent(token)}`,
    `Path=${apiPrefix}/`,
    `Max-Age=${SESSION_TTL_SECONDS}`,
    "HttpOnly",
    secure ? "Secure" : "",
    "SameSite=None",
  ].filter(Boolean);
  return attributes.join("; ");
}

export function clearSessionCookie(apiPrefix, secure) {
  const attributes = [
    `${COOKIE_NAME}=`,
    `Path=${apiPrefix}/`,
    "Max-Age=0",
    "HttpOnly",
    secure ? "Secure" : "",
    "SameSite=None",
  ].filter(Boolean);
  return attributes.join("; ");
}
