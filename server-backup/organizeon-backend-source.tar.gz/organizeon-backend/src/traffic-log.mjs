import { randomUUID } from "node:crypto";
import {
  appendFile,
  mkdir,
  readFile,
  rename,
  writeFile,
} from "node:fs/promises";
import { dirname } from "node:path";

export async function createTrafficLog({
  filePath,
  maxEntries = 800,
  maxFileBytes = 5 * 1024 * 1024,
} = {}) {
  const loaded = await loadEntries(filePath, maxEntries);
  let entries = loaded.entries;
  let fileBytes = loaded.fileBytes;
  let persistQueue = Promise.resolve();
  const subscribers = new Set();

  return Object.freeze({
    list(limit = 300) {
      return entries.slice(-Math.max(1, Math.min(limit, maxEntries)));
    },

    subscribe(listener) {
      subscribers.add(listener);
      listener(
        JSON.stringify({
          type: "snapshot",
          entries: entries.slice(-300),
        }),
      );
      return () => subscribers.delete(listener);
    },

    record(event) {
      const entry = sanitizeEntry(event);
      entries.push(entry);
      if (entries.length > maxEntries) {
        entries = entries.slice(-maxEntries);
      }
      const message = JSON.stringify({ type: "entry", entry });
      for (const listener of subscribers) listener(message);
      persist(entry);
      return entry;
    },
  });

  function persist(entry) {
    if (!filePath) return;
    const line = `${JSON.stringify(entry)}\n`;
    persistQueue = persistQueue
      .then(async () => {
        await mkdir(dirname(filePath), { recursive: true });
        if (fileBytes + Buffer.byteLength(line) > maxFileBytes) {
          const contents = `${entries.map(JSON.stringify).join("\n")}\n`;
          const temporaryFile = `${filePath}.tmp`;
          await writeFile(temporaryFile, contents, { mode: 0o600 });
          await rename(temporaryFile, filePath);
          fileBytes = Buffer.byteLength(contents);
          return;
        }
        await appendFile(filePath, line, { mode: 0o600 });
        fileBytes += Buffer.byteLength(line);
      })
      .catch((error) => {
        console.error("Could not write traffic log:", error);
      });
  }
}

async function loadEntries(filePath, maxEntries) {
  if (!filePath) return { entries: [], fileBytes: 0 };
  try {
    const contents = await readFile(filePath, "utf8");
    const entries = contents
      .trim()
      .split("\n")
      .slice(-maxEntries)
      .map((line) => JSON.parse(line))
      .map(resanitizeLoadedEntry)
      .filter(Boolean);
    return { entries, fileBytes: Buffer.byteLength(contents) };
  } catch (error) {
    if (error.code !== "ENOENT") {
      console.error("Could not read traffic log:", error);
    }
    return { entries: [], fileBytes: 0 };
  }
}

function resanitizeLoadedEntry(entry) {
  if (!entry || typeof entry !== "object") return null;
  const sanitized = sanitizeEntry(entry);
  return Object.freeze({
    ...sanitized,
    id:
      typeof entry.id === "string" &&
      /^[a-f0-9-]{36}$/i.test(entry.id)
        ? entry.id
        : sanitized.id,
    at:
      typeof entry.at === "string" &&
      Number.isFinite(Date.parse(entry.at))
        ? entry.at
        : sanitized.at,
  });
}

function sanitizeEntry(event) {
  const allowed = [
    "direction",
    "channel",
    "method",
    "path",
    "host",
    "statusCode",
    "durationMs",
    "bytes",
    "clientIp",
    "message",
  ];
  const entry = {
    id: randomUUID(),
    at: new Date().toISOString(),
  };
  for (const key of allowed) {
    const value = event[key];
    if (typeof value === "string") {
      entry[key] = sanitizeString(key, value);
    } else if (
      typeof value === "number" ||
      typeof value === "boolean"
    ) {
      entry[key] = value;
    }
  }
  return Object.freeze(entry);
}

function sanitizeString(key, value) {
  let sanitized = value
    .replace(/<token>/gi, "[REDACTED]")
    .replace(
      /\b(Bearer|Basic)\s+[^\s,;]+/gi,
      "$1 [REDACTED]",
    )
    .replace(
      /\b(token|password|passwd|secret|session|cookie|authorization|api[-_]?key)=([^&\s]+)/gi,
      "$1=[REDACTED]",
    )
    .replace(
      /\beyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{8,}(?:\.[A-Za-z0-9_-]{8,})?\b/g,
      "[REDACTED]",
    )
    .replace(
      /(?<![A-Za-z0-9_+/=-])[A-Za-z0-9_+/=-]{32,}(?![A-Za-z0-9_+/=-])/g,
      "[REDACTED]",
    );
  if (key === "clientIp") {
    sanitized = maskAddress(sanitized);
  }
  if (sanitized.length > 96) {
    sanitized = `${sanitized.slice(0, 72)}…xxxxx`;
  }
  return sanitized;
}

function maskAddress(value) {
  const ipv4 = /^(\d{1,3})\.(\d{1,3})\.\d{1,3}\.\d{1,3}$/.exec(
    value,
  );
  if (ipv4) return `${ipv4[1]}.${ipv4[2]}.xxxxx`;
  if (value.includes(":")) {
    return `${value.split(":").slice(0, 2).join(":")}:xxxxx`;
  }
  return value.length > 8 ? `${value.slice(0, 6)}…xxxxx` : value;
}
