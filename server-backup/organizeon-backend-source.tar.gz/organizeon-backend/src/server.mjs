import http from "node:http";
import { spawn } from "node:child_process";
import { randomBytes } from "node:crypto";
import { createReadStream, createWriteStream } from "node:fs";
import { mkdir, readFile, readdir, stat, unlink, writeFile } from "node:fs/promises";
import { Transform } from "node:stream";
import { pipeline } from "node:stream/promises";
import { fileURLToPath } from "node:url";
import { server as wisp, logging } from "@mercuryworkshop/wisp-js/server";
import { WebSocket, WebSocketServer } from "ws";
import {
  createAccountStore,
} from "./accounts.mjs";
import { createMonitoring } from "./monitoring.mjs";
import { createTrafficLog } from "./traffic-log.mjs";
import { createGameStats } from "./game-stats.mjs";
import { createGameSession, GAME_SESSION_TTL_SECONDS } from "./game-auth.mjs";
import { createServiceControl } from "./service-control.mjs";
import { createCloudBackupStore } from "./cloud-backup.mjs";
import { createPanelFileStore } from "../panel-files.mjs";
import {
  createLimitedSocketOptions,
  SharedBandwidthLimiter,
} from "./bandwidth-limit.mjs";
import {
  clearSessionCookie,
  createSessionToken,
  readToken,
  sessionCookie,
  verifySessionToken,
} from "./auth.mjs";

const env = process.env;
const host = env.HOST || "127.0.0.1";
const port = Number(env.PORT || 5000);
const publicPort = Number(env.PUBLIC_PORT || 443);
const publicDomain = (
  env.PUBLIC_DOMAIN || "api.organizeon.com.br"
).toLowerCase();
const apiPrefix = normalizePrefix(env.API_PREFIX || "/827e7h3heuw823eh");
const username = env.AUTH_USERNAME || "";
const passwordHash = env.AUTH_PASSWORD_HASH || "";
const ownerUsername = env.OWNER_USERNAME || "organizeon";
const ownerPasswordHash = env.OWNER_PASSWORD_HASH || "";
const sessionSecret = env.SESSION_SECRET || "";
const gameSessionSecret = env.GAME_SESSION_SECRET || "";
const suroiPublicUrl = env.SUROI_PUBLIC_URL ||
  "https://organizeon.com.br/ieudhe88eejje/suroi/";
const survivalPublicUrl = env.SURVIVAL_PUBLIC_URL ||
  "https://organizeon.com.br/ieudhe88eejje/organizeon-survival/";
const survivalOrigin = new URL(
  env.SURVIVAL_ORIGIN || "http://127.0.0.1:8020",
);
const survivalPathPrefix = normalizePrefix(
  env.SURVIVAL_PATH || "/ieudhe88eejje/organizeon-survival",
);
const cookieSecure = env.COOKIE_SECURE !== "false";
const trustCloudflare = env.TRUST_CLOUDFLARE !== "false";
const downloadHost = (
  env.DOWNLOAD_HOST || "organizeon.com.br"
).toLowerCase();
const clientIndex = fileURLToPath(
  new URL("../downloads/index.html", import.meta.url),
);
const chimeraArchive = fileURLToPath(
  new URL("../downloads/chimera.zip", import.meta.url),
);
const chimeraInstallerArchive = fileURLToPath(
  new URL("../downloads/chimera-installer.zip", import.meta.url),
);
const mediaUploadDirectory = env.MEDIA_UPLOAD_DIR || fileURLToPath(
  new URL("../data/media-uploads", import.meta.url),
);
const mediaMetadataDirectory = `${mediaUploadDirectory}/.metadata`;
const panelFileStore = createPanelFileStore({
  dataDirectory: fileURLToPath(new URL("../data/panel-files", import.meta.url)),
});
const mediaUploadTtlSeconds = Number(env.MEDIA_UPLOAD_TTL_SECONDS || 2700);
const mediaUploadTtlMs = mediaUploadTtlSeconds * 1000;
const mediaPublicBaseUrl = (
  env.MEDIA_PUBLIC_BASE_URL ||
  `https://${publicDomain}${apiPrefix}/media/files`
).replace(/\/+$/, "");
const accountsFile =
  env.ACCOUNTS_FILE ||
  fileURLToPath(new URL("../data/users.json", import.meta.url));
const cloudBackupStore = createCloudBackupStore({
  directory: env.CLOUD_BACKUP_DIR ||
    fileURLToPath(new URL("../data/cloud-backups", import.meta.url)),
});
const monitoringSnapshotFile =
  env.MONITORING_SNAPSHOT_FILE ||
  fileURLToPath(
    new URL("../data/monitoring-snapshot.json", import.meta.url),
  );
const trafficLogFile =
  env.TRAFFIC_LOG_FILE ||
  fileURLToPath(new URL("../data/server-traffic.jsonl", import.meta.url));
const gameStatsFile =
  env.GAME_STATS_FILE ||
  fileURLToPath(new URL("../data/game-stats.json", import.meta.url));
const wispDefaultBandwidthMbps = Number(
  env.WISP_DEFAULT_BANDWIDTH_MBPS || 6,
);
const wispDefaultBandwidthBitsPerSecond =
  wispDefaultBandwidthMbps * 1_000_000;
const allowedHosts = new Set(
  (
    env.ALLOWED_HOSTS ||
    "api.organizeon.com.br,localhost,127.0.0.1"
  )
    .split(",")
    .map((hostname) => hostname.trim().toLowerCase())
    .filter(Boolean),
);
const allowedOrigins = new Set(
  (
    env.ALLOWED_ORIGINS ||
    "http://localhost:8080,http://127.0.0.1:8080"
  )
    .split(",")
    .map((origin) => origin.trim())
    .filter(Boolean),
);
const mediaTypes = Object.freeze({
  "image/png": Object.freeze({ extension: "png", limit: 2 * 1024 * 1024 }),
  "image/jpeg": Object.freeze({ extension: "jpg", limit: 2 * 1024 * 1024 }),
  "image/gif": Object.freeze({ extension: "gif", limit: 2 * 1024 * 1024 }),
  "image/webp": Object.freeze({ extension: "webp", limit: 2 * 1024 * 1024 }),
  "video/mp4": Object.freeze({ extension: "mp4", limit: 90 * 1024 * 1024 }),
  "video/webm": Object.freeze({ extension: "webm", limit: 90 * 1024 * 1024 }),
  "video/x-msvideo": Object.freeze({ extension: "avi", limit: 90 * 1024 * 1024 }),
  "video/avi": Object.freeze({ extension: "avi", limit: 90 * 1024 * 1024 }),
  "text/plain": Object.freeze({ extension: "txt", limit: 20 * 1024 * 1024 }),
});
const mediaTypesByExtension = Object.freeze(
  Object.fromEntries(
    Object.entries(mediaTypes).map(([contentType, rule]) => [
      rule.extension,
      contentType,
    ]),
  ),
);

validateConfiguration();
await mkdir(mediaUploadDirectory, { recursive: true });
await mkdir(mediaMetadataDirectory, { recursive: true });
await panelFileStore.init();
await cloudBackupStore.init();
await cleanupExpiredMedia();
const mediaCleanupTimer = setInterval(cleanupExpiredMedia, 60_000);
mediaCleanupTimer.unref();
const accounts = await createAccountStore({
  filePath: accountsFile,
  initialAdminUsername: username,
  initialAdminPasswordHash: passwordHash,
  initialOwnerUsername: ownerUsername,
  initialOwnerPasswordHash: ownerPasswordHash,
});
const serviceControl = createServiceControl({
  definitions: [
    {
      id: "api",
      label: "API OrganizeOn",
      serviceName: env.API_SERVICE_NAME || "organizeon-backend",
      permission: "services.api.restart",
      actions: ["restart"],
    },
    {
      id: "relay",
      label: "Relay Eaglercraft",
      serviceName: env.RELAY_SERVICE_NAME || "organizeon-eagler-relay",
      permission: "services.relay.manage",
      actions: ["start", "stop", "restart"],
    },
    {
      id: "tunnel",
      label: "Cloudflare Tunnel",
      serviceName: env.CLOUDFLARED_SERVICE_NAME || "organizeon-cloudflared",
      permission: "services.servers.manage",
      actions: ["restart"],
    },
    {
      id: "suroi",
      label: "Servidor Suroi",
      serviceName: env.SUROI_SERVICE_NAME || "organizeon-suroi",
      permission: "services.servers.manage",
      actions: ["start", "stop", "restart"],
    },
    {
      id: "survival",
      label: "OrganizeOn Survival",
      serviceName: env.SURVIVAL_SERVICE_NAME || "organizeon-survival",
      permission: "services.servers.manage",
      actions: ["start", "stop", "restart"],
    },
  ],
});
const trafficLog = await createTrafficLog({
  filePath: trafficLogFile,
});
const gameStats = await createGameStats({ filePath: gameStatsFile });
const monitoring = createMonitoring({
  snapshotFile: monitoringSnapshotFile,
  service: {
    publicDomain,
    publicPort,
    bindHost: host,
    internalPort: port,
    apiPrefix,
    wispDefaultBandwidthMbps,
    routes: [
      {
        id: "main",
        label: "OrganizeOn",
        url: "https://organizeon.com.br/",
        purpose: "Raiz protegida (404 intencional)",
        used: true,
        expectedStatuses: [404],
      },
      {
        id: "download",
        label: "Download do cliente",
        url: "https://organizeon.com.br/d1",
        purpose: "index.html portátil",
        used: true,
        expectedStatuses: [200],
      },
      {
        id: "api",
        label: "API principal",
        url: `https://${publicDomain}${apiPrefix}/health`,
        purpose: "Login, dashboard e WISP",
        used: true,
        expectedStatuses: [200],
      },
    ],
  },
});

logging.set_level(logging.WARN);
wisp.options.port_whitelist = [80, 443];
wisp.options.hostname_blacklist = [
  /^localhost$/i,
  /\.localhost$/i,
  /^0(?:\.|$)/,
  /^10(?:\.|$)/,
  /^127(?:\.|$)/,
  /^169\.254(?:\.|$)/,
  /^172\.(?:1[6-9]|2\d|3[01])(?:\.|$)/,
  /^192\.168(?:\.|$)/,
  /^::1$/,
  /^fc/i,
  /^fd/i,
  /^fe8/i,
  /^fe9/i,
  /^fea/i,
  /^feb/i,
];

const loginAttempts = new Map();
const limitedWispAccounts = new Map();
// Short-lived coordination lock used by Chimera instances that share one bot.
// This stays server-side so separate machines do not race on Discord's cache.
const chimeraNicknameLeases = new Map();
const CHIMERA_NICKNAME_LEASE_MS = 10_000;
const CHIMERA_FALSE_POSITIVE_GRACE_MS = 20_000;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const LOGIN_LIMIT = 8;
const controlWebSockets = new WebSocketServer({
  noServer: true,
  maxPayload: 4096,
});
const terminalWebSockets = new WebSocketServer({
  noServer: true,
  maxPayload: 64 * 1024,
});
const monitoringWebSockets = new WebSocketServer({
  noServer: true,
  maxPayload: 1024,
});
const logsWebSockets = new WebSocketServer({
  noServer: true,
  maxPayload: 1024,
});
const survivalWebSockets = new WebSocketServer({
  noServer: true,
  maxPayload: 16 * 1024,
});

const server = http.createServer(async (request, response) => {
  const requestStartedAt = performance.now();
  const internalMonitor =
    request.headers["user-agent"] === "OrganizeOn-Monitor/1.0";
  const requestHost = getRequestHost(request);
  const requestPath = safeLogPath(request.url);
  if (!internalMonitor) {
    trafficLog.record({
      direction: "received",
      channel: "HTTP",
      method: request.method,
      path: requestPath,
      host: requestHost,
      bytes: Number(request.headers["content-length"] || 0),
      clientIp: getClientIp(request),
      message: "Requisição recebida",
    });
  }
  response.once("finish", () => {
    if (internalMonitor) return;
    const durationMs = performance.now() - requestStartedAt;
    monitoring.recordRequest({
      durationMs,
      statusCode: response.statusCode,
      host: requestHost,
    });
    trafficLog.record({
      direction: "sent",
      channel: "HTTP",
      method: request.method,
      path: requestPath,
      host: requestHost,
      statusCode: response.statusCode,
      durationMs: Number(durationMs.toFixed(2)),
      bytes: Number(response.getHeader("content-length") || 0),
      clientIp: getClientIp(request),
      message: "Resposta enviada",
    });
  });
  applySecurityHeaders(response);

  const earlyRequestUrl = new URL(
    request.url,
    `http://${request.headers.host || "localhost"}`,
  );
  if (
    (
      earlyRequestUrl.pathname === survivalPathPrefix ||
      earlyRequestUrl.pathname.startsWith(`${survivalPathPrefix}/`)
    ) &&
    (getRequestHost(request) === downloadHost || isAllowedHost(request))
  ) {
    response.removeHeader("X-Frame-Options");
    return proxySurvivalHttp(request, response);
  }

  if (getRequestHost(request) === downloadHost) {
    const downloadPath = new URL(
      request.url,
      "http://download.invalid",
    ).pathname;
    if (
      downloadPath === "/d1" &&
      (request.method === "GET" || request.method === "HEAD")
    ) {
      return sendClientDownload(request, response);
    }
    if (downloadPath.startsWith("/d2/download/") && (request.method === "GET" || request.method === "HEAD")) { return sendShortPanelFileDownload(request, response, downloadPath.slice("/d2/download/".length), true); }
    if (downloadPath.startsWith("/d2/files/") && (request.method === "GET" || request.method === "HEAD")) { return sendShortPanelFileDownload(request, response, downloadPath.slice("/d2/files/".length), new URL(request.url, "http://download.invalid").searchParams.get("download") === "1"); }
    if (downloadPath === "/d2/login" &&
      (request.method === "GET" || request.method === "HEAD")) {
      return sendPanelDownload(request, response);
    }
    if (
      downloadPath === "/d1/chimera.zip" &&
      (request.method === "GET" || request.method === "HEAD")
    ) {
      return sendChimeraDownload(request, response);
    }
    if (
      downloadPath === "/d1/chimera-installer.zip" &&
      (request.method === "GET" || request.method === "HEAD")
    ) {
      return sendChimeraInstallerDownload(request, response);
    }
    return sendEmpty(response, 404);
  }

  if (!isAllowedHost(request)) {
    return sendJson(response, 404, { error: "not_found" });
  }

  const requestUrl = new URL(request.url, `http://${request.headers.host}`);
  const isPublicGameStats =
    requestUrl.pathname === `${apiPrefix}/games/stats`;
  const origin = request.headers.origin;
  const originAllowed =
    Boolean(origin) &&
    (allowedOrigins.has(origin) || (origin === "null" && isPublicGameStats));
  if (originAllowed) {
    response.setHeader("Access-Control-Allow-Origin", origin);
    response.setHeader("Access-Control-Allow-Credentials", "true");
    response.setHeader("Vary", "Origin");
  }

  if (request.method === "OPTIONS") {
    if (!originAllowed) {
      return sendJson(response, 403, { error: "origin_not_allowed" });
    }
    response.setHeader(
      "Access-Control-Allow-Methods",
      "GET,POST,PATCH,DELETE,OPTIONS",
    );
    response.setHeader(
      "Access-Control-Allow-Headers",
      "Content-Type, Authorization, X-File-Name",
    );
    response.setHeader("Access-Control-Max-Age", "600");
    response.writeHead(204);
    return response.end();
  }

  if (requestUrl.pathname === `${apiPrefix}/auth/login`) {
    if (request.method !== "POST") {
      return sendJson(response, 405, { error: "method_not_allowed" });
    }
    if (!originAllowed) {
      return sendJson(response, 403, { error: "origin_not_allowed" });
    }

    const clientIp = getClientIp(request);
    if (!consumeLoginAttempt(clientIp)) {
      response.setHeader("Retry-After", "900");
      return sendJson(response, 429, { error: "too_many_attempts" });
    }

    let body;
    try {
      body = await readJson(request);
    } catch (error) {
      return sendJson(response, error.statusCode || 400, {
        error: "invalid_request",
      });
    }

    const account = typeof body.loginCode === "string"
      ? await accounts.authenticateLoginCode(body.loginCode)
      : typeof body.username === "string"
        ? accounts.authenticate(body.username, body.password)
        : null;
    if (!account) {
      return sendJson(response, 401, { error: "invalid_credentials" });
    }

    loginAttempts.delete(clientIp);
    const token = createSessionToken(account, sessionSecret);
    const claims = verifySessionToken(token, sessionSecret);
    response.setHeader(
      "Set-Cookie",
      sessionCookie(token, apiPrefix, cookieSecure),
    );
    return sendJson(response, 200, {
      ok: true,
      token,
      expiresAt: new Date(claims.exp * 1000).toISOString(),
      account,
    });
  }

  if (requestUrl.pathname === `${apiPrefix}/auth/register`) {
    if (request.method !== "POST") {
      return sendJson(response, 405, { error: "method_not_allowed" });
    }
    if (!originAllowed) {
      return sendJson(response, 403, { error: "origin_not_allowed" });
    }
    const clientIp = getClientIp(request);
    if (!consumeLoginAttempt(clientIp)) {
      response.setHeader("Retry-After", "900");
      return sendJson(response, 429, { error: "too_many_attempts" });
    }
    try {
      const account = await accounts.register(await readJson(request));
      loginAttempts.delete(clientIp);
      const token = createSessionToken(account, sessionSecret);
      const claims = verifySessionToken(token, sessionSecret);
      response.setHeader("Set-Cookie", sessionCookie(token, apiPrefix, cookieSecure));
      return sendJson(response, 201, {
        ok: true,
        token,
        expiresAt: new Date(claims.exp * 1000).toISOString(),
        account,
      });
    } catch (error) {
      return sendJson(response, error.statusCode || 400, {
        error: error.code || error.message || "registration_failed",
      });
    }
  }

  if (requestUrl.pathname === `${apiPrefix}/auth/session`) {
    if (request.method !== "GET") {
      return sendJson(response, 405, { error: "method_not_allowed" });
    }
    const claims = authenticate(request, requestUrl);
    if (!claims) {
      return sendJson(response, 401, { authenticated: false });
    }
    return sendJson(response, 200, {
      authenticated: true,
      username: claims.sub,
      role: claims.role,
      permissions: claims.permissions,
      expiresAt: new Date(claims.expiresAt).toISOString(),
    });
  }

  if (requestUrl.pathname === `${apiPrefix}/auth/logout`) {
    if (request.method !== "POST") {
      return sendJson(response, 405, { error: "method_not_allowed" });
    }
    response.setHeader(
      "Set-Cookie",
      clearSessionCookie(apiPrefix, cookieSecure),
    );
    return sendJson(response, 200, { ok: true });
  }

  if (requestUrl.pathname === `${apiPrefix}/account/backup`) {
    const account = authenticate(request, requestUrl);
    if (!account) return sendJson(response, 401, { error: "authentication_required" });
    try {
      if (request.method === "GET") {
        return sendJson(response, 200, await cloudBackupStore.status(account));
      }
      if (request.method === "PATCH") {
        const body = await readJson(request);
        return sendJson(response, 200, await cloudBackupStore.setEnabled(
          account,
          body.enabled === true,
        ));
      }
      if (request.method === "PUT") {
        return sendJson(response, 200, await cloudBackupStore.save(account, request));
      }
      if (request.method === "DELETE") {
        return sendJson(response, 200, await cloudBackupStore.clear(account));
      }
      return sendJson(response, 405, { error: "method_not_allowed" });
    } catch (error) {
      return sendJson(response, error.statusCode || 400, {
        error: error.code || error.message || "backup_failed",
      });
    }
  }

  if (requestUrl.pathname === `${apiPrefix}/account/backup/data`) {
    const account = authenticate(request, requestUrl);
    if (!account) return sendJson(response, 401, { error: "authentication_required" });
    if (request.method !== "GET" && request.method !== "HEAD") {
      return sendJson(response, 405, { error: "method_not_allowed" });
    }
    try {
      const backup = await cloudBackupStore.open(account);
      if (!backup) return sendJson(response, 404, { error: "backup_not_found" });
      response.writeHead(200, {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Length": backup.size,
        "Cache-Control": "no-store",
      });
      if (request.method === "HEAD") return response.end();
      return backup.stream().pipe(response);
    } catch (error) {
      return sendJson(response, error.statusCode || 400, {
        error: error.code || error.message || "backup_failed",
      });
    }
  }

  if (requestUrl.pathname === `${apiPrefix}/health`) {
    return sendJson(response, 200, { ok: true });
  }

  const publicMedia = matchPublicMediaPath(requestUrl.pathname);
  if (publicMedia) {
    if (request.method !== "GET" && request.method !== "HEAD") {
      return sendJson(response, 405, { error: "method_not_allowed" });
    }
    return sendTemporaryMedia(request, response, publicMedia);
  }

  const filesRoute = `${apiPrefix}/files`;
  if (requestUrl.pathname === filesRoute) {
    const account = authenticate(request, requestUrl);
    if (!account) return sendJson(response, 401, { error: "authentication_required" });
    if (request.method === "GET") {
      return sendJson(response, 200, { files: await panelFileStore.list(account) });
    }
    if (request.method === "POST") {
      try {
        const rawName = request.headers["x-file-name"];
        const name = rawName ? decodeURIComponent(String(rawName)) : "arquivo";
        const file = await panelFileStore.create(account, name, request.headers["content-type"], request);
        return sendJson(response, 201, { file });
      } catch (error) {
        return sendJson(response, error.statusCode || 400, { error: error.message || "upload_failed" });
      }
    }
    return sendJson(response, 405, { error: "method_not_allowed" });
  }

  if (requestUrl.pathname.startsWith(`${filesRoute}/`)) {
    {
    const relative = requestUrl.pathname.slice(filesRoute.length + 1);
    const rawSuffix = "/raw/content";
    const id = relative.endsWith(rawSuffix) ? relative.slice(0, -rawSuffix.length) : relative;
    if (relative.endsWith(rawSuffix) && /^[a-f0-9]{32}$/.test(id) && (request.method === "GET" || request.method === "HEAD")) {
      const item = await panelFileStore.publicContent(id);
      if (!item) return sendJson(response, 404, { error: "file_not_found" });
      response.writeHead(200, { "Content-Type": item.metadata.contentType || "application/octet-stream", "Content-Length": item.size, "Cache-Control": "public, max-age=300", "Content-Disposition": `${new URL(request.url, `http://${request.headers.host || "localhost"}`).searchParams.get("download") === "1" ? "attachment" : "inline"}; filename="${item.metadata.name.replace(/"/g, "")}"` });
      if (request.method === "HEAD") return response.end();
      return createReadStream(item.path).pipe(response);
    }
    }
    const account = authenticate(request, requestUrl);
    if (!account) return sendJson(response, 401, { error: "authentication_required" });
    const relative = requestUrl.pathname.slice(filesRoute.length + 1);
    const rawSuffix = "/raw/content";
    const contentSuffix = "/content";
    const isRawContent = relative.endsWith(rawSuffix);
    const isContent = isRawContent || relative.endsWith(contentSuffix);
    const id = isRawContent
      ? relative.slice(0, -rawSuffix.length)
      : isContent
        ? relative.slice(0, -contentSuffix.length)
        : relative;
    if (!/^[a-f0-9]{32}$/.test(id)) return sendJson(response, 404, { error: "file_not_found" });
    try {
      if (isContent && (request.method === "GET" || request.method === "HEAD")) {
        const item = await panelFileStore.content(account, id);
        if (!item) return sendJson(response, 404, { error: "file_not_found" });
        response.writeHead(200, {
          "Content-Type": item.metadata.contentType || "application/octet-stream",
          "Content-Length": item.size,
          "Content-Disposition": `attachment; filename="${item.metadata.name.replace(/"/g, "")}"`,
        });
        if (request.method === "HEAD") return response.end();
        return createReadStream(item.path).pipe(response);
      }
      if (request.method === "GET") {
        const item = await panelFileStore.content(account, id);
        if (!item) return sendJson(response, 404, { error: "file_not_found" });
        const result = { file: { ...item.metadata, size: item.size } };
        if (item.metadata.contentType.startsWith("text/")) result.content = await readFile(item.path, "utf8");
        return sendJson(response, 200, result);
      }
      if (request.method === "PUT") {
        const file = await panelFileStore.update(account, id, request.headers["content-type"], request);
        return sendJson(response, 200, { file });
      }
      if (request.method === "DELETE") return sendJson(response, 200, await panelFileStore.remove(account, id));
      return sendJson(response, 405, { error: "method_not_allowed" });
    } catch (error) {
      return sendJson(response, error.statusCode || 400, { error: error.message || "file_operation_failed" });
    }
  }

  if (requestUrl.pathname === `${apiPrefix}/media/upload`) {
    if (request.method !== "POST") {
      return sendJson(response, 405, { error: "method_not_allowed" });
    }
    const account = authenticate(request, requestUrl);
    if (!account) {
      return sendJson(response, 401, { error: "authentication_required" });
    }
    if (!account.permissions.includes("media.upload")) {
      return sendJson(response, 403, { error: "permission_required" });
    }
    try {
      return sendJson(
        response,
        201,
        await receiveTemporaryMedia(request, account),
      );
    } catch (error) {
      return sendJson(response, error.statusCode || 500, {
        error: error.publicCode || "upload_failed",
      });
    }
  }

  if (
    requestUrl.pathname === `${apiPrefix}/media/cache` ||
    requestUrl.pathname === `${apiPrefix}/media/cache/owner`
  ) {
    if (request.method !== "DELETE") {
      return sendJson(response, 405, { error: "method_not_allowed" });
    }
    const account = authenticate(request, requestUrl);
    if (!account) {
      return sendJson(response, 401, { error: "authentication_required" });
    }
    if (!account.permissions.includes("media.upload")) {
      return sendJson(response, 403, { error: "permission_required" });
    }
    try {
      const scope = requestUrl.pathname.endsWith("/owner") ? "owner" : "agent";
      return sendJson(response, 200, {
        ok: true,
        deleted: await clearTemporaryMedia(request, account, scope),
      });
    } catch (error) {
      return sendJson(response, error.statusCode || 500, {
        error: error.publicCode || "cache_clear_failed",
      });
    }
  }

  if (requestUrl.pathname === `${apiPrefix}/chimera/nickname-lease`) {
    if (request.method !== "POST") {
      return sendJson(response, 405, { error: "method_not_allowed" });
    }
    const account = authenticate(request, requestUrl);
    if (!account) {
      return sendJson(response, 401, { error: "authentication_required" });
    }
    if (!account.permissions.includes("media.upload")) {
      return sendJson(response, 403, { error: "permission_required" });
    }
    try {
      return sendJson(
        response,
        200,
        await coordinateChimeraNickname(request, account),
      );
    } catch (error) {
      return sendJson(response, error.statusCode || 400, {
        error: error.publicCode || "invalid_nickname_lease_request",
      });
    }
  }

  if (requestUrl.pathname === `${apiPrefix}/games/stats`) {
    if (request.method === "GET") {
      return sendJson(response, 200, gameStats.snapshot());
    }
    if (request.method !== "POST") {
      return sendJson(response, 405, { error: "method_not_allowed" });
    }
    if (!originAllowed) {
      return sendJson(response, 403, { error: "origin_not_allowed" });
    }
    try {
      const body = await readJson(request);
      const result = await gameStats.record(
        body.gameId,
        body.event,
        getClientIp(request),
      );
      if (result.reason === "invalid_game" || result.reason === "invalid_event") {
        return sendJson(response, 400, { error: result.reason });
      }
      return sendJson(response, 200, {
        ok: true,
        counted: result.accepted,
        game: result.game,
      });
    } catch (error) {
      return sendJson(response, error.statusCode || 400, {
        error: "invalid_request",
      });
    }
  }

  if (
    requestUrl.pathname === `${apiPrefix}/games/suroi/session` ||
    requestUrl.pathname === `${apiPrefix}/games/survival/session`
  ) {
    if (request.method !== "POST") {
      return sendJson(response, 405, { error: "method_not_allowed" });
    }
    if (!originAllowed) {
      return sendJson(response, 403, { error: "origin_not_allowed" });
    }
    const account = authenticate(request, requestUrl);
    if (!account) return sendJson(response, 401, { error: "unauthorized" });
    let body = {};
    try {
      body = await readJson(request);
    } catch (error) {
      return sendJson(response, error.statusCode || 400, {
        error: "invalid_request",
      });
    }
    const token = createGameSession(
      account,
      gameSessionSecret,
      typeof body.themeId === "string" ? body.themeId : "maple",
    );
    return sendJson(response, 200, {
      token,
      expiresAt: new Date(
        Date.now() + GAME_SESSION_TTL_SECONDS * 1000,
      ).toISOString(),
      url: requestUrl.pathname.endsWith("/survival/session")
        ? survivalPublicUrl
        : suroiPublicUrl,
      role: account.role,
      permissions: account.permissions.filter((permission) =>
        permission.startsWith("game.suroi.") ||
        permission.startsWith("game.survival."),
      ),
    });
  }

  if (requestUrl.pathname === `${apiPrefix}/admin/status`) {
    if (request.method !== "GET") {
      return sendJson(response, 405, { error: "method_not_allowed" });
    }
    const account = authorize(
      request,
      requestUrl,
      "admin.dashboard",
    );
    if (!account) return sendJson(response, 403, { error: "forbidden" });
    return sendJson(response, 200, {
      account,
      monitoring: monitoring.snapshot(),
    });
  }

  if (requestUrl.pathname === `${apiPrefix}/admin/monitoring`) {
    const account = authorize(
      request,
      requestUrl,
      "admin.monitoring",
    );
    if (!account) return sendJson(response, 403, { error: "forbidden" });
    return sendJson(response, 410, {
      error: "monitoring_uses_websocket",
      monitoring: monitoring.snapshot(),
    });
  }

  if (requestUrl.pathname === `${apiPrefix}/admin/users`) {
    const account = authorize(request, requestUrl, "admin.users");
    if (!account) return sendJson(response, 403, { error: "forbidden" });
    if (request.method === "GET") {
      const capabilities = accounts.capabilities(account);
      return sendJson(response, 200, {
        users: accounts.list(account),
        permissions: capabilities.allPermissions,
        grantablePermissions: capabilities.permissions,
        roles: capabilities.roles,
      });
    }
    if (request.method === "POST") {
      try {
        const created = await accounts.create(
          account,
          await readJson(request),
        );
        return sendJson(response, 201, { user: created });
      } catch (error) {
        return sendJson(response, error.statusCode || 400, {
          error: error.code || "invalid_request",
        });
      }
    }
    return sendJson(response, 405, { error: "method_not_allowed" });
  }

  const userRoute = `${apiPrefix}/admin/users/`;
  if (requestUrl.pathname.startsWith(userRoute)) {
    const account = authorize(request, requestUrl, "admin.users");
    if (!account) return sendJson(response, 403, { error: "forbidden" });
    const relativeUserPath = requestUrl.pathname.slice(userRoute.length);
    const loginCodeSuffix = "/login-code";
    const isLoginCodeRoute = relativeUserPath.endsWith(loginCodeSuffix);
    const targetUsername = safeDecodeURIComponent(
      isLoginCodeRoute
        ? relativeUserPath.slice(0, -loginCodeSuffix.length)
        : relativeUserPath,
    );
    if (!targetUsername || targetUsername.includes("/")) {
      return sendJson(response, 404, { error: "user_not_found" });
    }
    try {
      if (isLoginCodeRoute) {
        if (request.method !== "POST") {
          return sendJson(response, 405, { error: "method_not_allowed" });
        }
        const loginCode = await accounts.createLoginCode(
          account,
          targetUsername,
        );
        return sendJson(response, 201, loginCode);
      }
      if (request.method === "PATCH") {
        const updated = await accounts.update(
          account,
          targetUsername,
          await readJson(request),
        );
        return sendJson(response, 200, { user: updated });
      }
      if (request.method === "DELETE") {
        await accounts.remove(account, targetUsername);
        response.writeHead(204);
        return response.end();
      }
      return sendJson(response, 405, { error: "method_not_allowed" });
    } catch (error) {
      return sendJson(response, error.statusCode || 400, {
        error: error.code || "invalid_request",
      });
    }
  }

  if (requestUrl.pathname === `${apiPrefix}/admin/services`) {
    if (request.method !== "GET") {
      return sendJson(response, 405, { error: "method_not_allowed" });
    }
    const account = authenticate(request, requestUrl);
    if (!account) return sendJson(response, 403, { error: "forbidden" });
    return sendJson(response, 200, {
      services: await serviceControl.listWithStatus(account),
    });
  }

  const serviceRoute = `${apiPrefix}/admin/services/`;
  if (requestUrl.pathname.startsWith(serviceRoute)) {
    if (request.method !== "POST") {
      return sendJson(response, 405, { error: "method_not_allowed" });
    }
    const account = authenticate(request, requestUrl);
    if (!account) return sendJson(response, 403, { error: "forbidden" });
    const routeParts = requestUrl.pathname
      .slice(serviceRoute.length)
      .split("/")
      .filter(Boolean);
    if (routeParts.length !== 2) {
      return sendJson(response, 404, { error: "service_not_found" });
    }
    try {
      if (routeParts[0] === "api" && routeParts[1] === "restart") {
        const allowed = serviceControl.list(account).some(
          (service) => service.id === "api" && service.actions.includes("restart"),
        );
        if (!allowed) return sendJson(response, 403, { error: "forbidden" });
        setTimeout(() => {
          serviceControl.execute(account, "api", "restart").catch((error) => {
            console.error("Failed to restart API service:", error);
          });
        }, 350).unref();
        return sendJson(response, 202, {
          ok: true,
          service: { id: "api", label: "API OrganizeOn" },
          action: "restart",
        });
      }
      const result = await serviceControl.execute(
        account,
        routeParts[0],
        routeParts[1],
      );
      return sendJson(response, 202, { ok: true, ...result });
    } catch (error) {
      return sendJson(response, error.statusCode || 500, {
        error: error.code || "service_command_failed",
      });
    }
  }

  return sendJson(response, 404, { error: "not_found" });
});

server.on("upgrade", (request, socket, head) => {
  const requestUrl = new URL(request.url, `http://${request.headers.host}`);
  const logsBase = `${apiPrefix}/logs/`;
  const isLogsConnection = requestUrl.pathname.startsWith(logsBase);
  monitoring.recordRequest({
    durationMs: 0,
    statusCode: 101,
    host: getRequestHost(request),
    kind: "websocket",
  });
  if (!isLogsConnection) {
    trafficLog.record({
      direction: "received",
      channel: classifyUpgrade(requestUrl.pathname),
      method: "UPGRADE",
      path: safeLogPath(requestUrl.pathname),
      host: getRequestHost(request),
      bytes: Number(request.headers["content-length"] || 0),
      clientIp: getClientIp(request),
      message: "Conexão recebida",
    });
  }
  const isSurvivalWebSocket =
    requestUrl.pathname === `${survivalPathPrefix}/ws`;
  if (
    !isAllowedHost(request) &&
    !(getRequestHost(request) === downloadHost && isSurvivalWebSocket)
  ) {
    return rejectUpgrade(socket, 404, "Not Found");
  }

  if (isSurvivalWebSocket) {
    return survivalWebSockets.handleUpgrade(
      request,
      socket,
      head,
      (webSocket) => {
        survivalWebSockets.emit("connection", webSocket, request);
      },
    );
  }

  const origin = request.headers.origin;
  const logsToken =
    requestUrl.pathname.startsWith(logsBase) &&
    requestUrl.pathname.endsWith("/")
      ? safeDecodeURIComponent(
          requestUrl.pathname.slice(logsBase.length, -1),
        )
      : "";

  if (requestUrl.pathname === logsBase || logsToken) {
    if (!origin || !allowedOrigins.has(origin)) {
      return rejectUpgrade(socket, 404, "Not Found");
    }
    const account = authorizeWebSocket(
      request,
      requestUrl,
      logsToken,
      "admin.dashboard",
    );
    if (!account) {
      return rejectUpgrade(socket, 403, "Forbidden");
    }
    return logsWebSockets.handleUpgrade(
      request,
      socket,
      head,
      (webSocket) => {
        logsWebSockets.emit(
          "connection",
          webSocket,
          request,
          account,
        );
      },
    );
  }

  const monitoringBase = `${apiPrefix}/monitoring/`;
  const monitoringToken =
    requestUrl.pathname.startsWith(monitoringBase) &&
    requestUrl.pathname.endsWith("/")
      ? safeDecodeURIComponent(
          requestUrl.pathname.slice(monitoringBase.length, -1),
        )
      : "";

  if (requestUrl.pathname === monitoringBase || monitoringToken) {
    if (!origin || !allowedOrigins.has(origin)) {
      return rejectUpgrade(socket, 404, "Not Found");
    }
    const account = authorizeWebSocket(
      request,
      requestUrl,
      monitoringToken,
      "admin.monitoring",
    );
    if (!account) {
      return rejectUpgrade(socket, 403, "Forbidden");
    }
    return monitoringWebSockets.handleUpgrade(
      request,
      socket,
      head,
      (webSocket) => {
        monitoringWebSockets.emit(
          "connection",
          webSocket,
          request,
          account,
        );
      },
    );
  }

  const terminalBase = `${apiPrefix}/terminal/`;
  const terminalToken =
    requestUrl.pathname.startsWith(terminalBase) &&
    requestUrl.pathname.endsWith("/")
      ? safeDecodeURIComponent(
          requestUrl.pathname.slice(terminalBase.length, -1),
        )
      : "";

  if (requestUrl.pathname === terminalBase || terminalToken) {
    if (!origin || !allowedOrigins.has(origin)) {
      return rejectUpgrade(socket, 404, "Not Found");
    }
    const account = authorizeWebSocket(
      request,
      requestUrl,
      terminalToken,
      "admin.terminal",
    );
    if (!account) {
      return rejectUpgrade(socket, 403, "Forbidden");
    }
    return terminalWebSockets.handleUpgrade(
      request,
      socket,
      head,
      (webSocket) => {
        terminalWebSockets.emit(
          "connection",
          webSocket,
          request,
          account,
        );
      },
    );
  }

  const controlBase = `${apiPrefix}/connect/`;
  const controlToken =
    requestUrl.pathname.startsWith(controlBase) &&
    requestUrl.pathname.endsWith("/")
      ? safeDecodeURIComponent(
          requestUrl.pathname.slice(controlBase.length, -1),
        )
      : "";

  if (requestUrl.pathname === controlBase || controlToken) {
    if (!origin || !allowedOrigins.has(origin)) {
      return rejectUpgrade(socket, 404, "Not Found");
    }
    const account = authorizeWebSocket(
      request,
      requestUrl,
      controlToken,
      "proxy.use",
    );
    if (!account) {
      return rejectUpgrade(socket, 401, "Unauthorized");
    }
    return controlWebSockets.handleUpgrade(
      request,
      socket,
      head,
      (webSocket) => {
        controlWebSockets.emit(
          "connection",
          webSocket,
          request,
          account,
        );
      },
    );
  }

  const wispBase = `${apiPrefix}/wisp/`;
  const wispPathParts =
    requestUrl.pathname.startsWith(wispBase) &&
    requestUrl.pathname.endsWith("/")
      ? requestUrl.pathname
          .slice(wispBase.length, -1)
          .split("/")
          .filter(Boolean)
      : [];
  const bandwidthLimited =
    wispPathParts.length === 2 && wispPathParts[0] === "limited";
  const encodedPathToken = bandwidthLimited
    ? wispPathParts[1]
    : wispPathParts.length === 1
      ? wispPathParts[0]
      : "";
  const pathToken = safeDecodeURIComponent(encodedPathToken);

  if (
    (requestUrl.pathname !== wispBase && !pathToken) ||
    !origin ||
    !allowedOrigins.has(origin)
  ) {
    return rejectUpgrade(socket, 404, "Not Found");
  }

  const account = authorizeWebSocket(
    request,
    requestUrl,
    pathToken,
    "proxy.use",
  );
  if (!account) {
    return rejectUpgrade(socket, 401, "Unauthorized");
  }

  // Keep every Wisp URL ending in "/" as required by Wisp clients.
  // The original /wisp/<token>/ route remains the unlimited mode.
  const bandwidthUnlimited = !bandwidthLimited;
  let connectionOptions = {};
  if (!bandwidthUnlimited) {
    const limiterLease = acquireWispBandwidthLimiter(account.username);
    connectionOptions = createLimitedSocketOptions(limiterLease.limiter);
    socket.once("close", limiterLease.release);
  }

  // The Wisp library decides between Wisp and its wsproxy compatibility mode
  // from the trailing slash. Remove the authentication query before routing.
  request.url = requestUrl.pathname;
  const initialBytesRead = socket.bytesRead;
  const initialBytesWritten = socket.bytesWritten;
  socket.once("close", () => {
    trafficLog.record({
      direction: "sent",
      channel: "WISP",
      method: "CLOSE",
      path: safeLogPath(requestUrl.pathname),
      host: getRequestHost(request),
      bytes:
        Math.max(0, socket.bytesRead - initialBytesRead) +
        Math.max(0, socket.bytesWritten - initialBytesWritten),
      clientIp: getClientIp(request),
      message: "Túnel encerrado; bytes recebidos e enviados",
    });
  });
  trafficLog.record({
    direction: "received",
    channel: "WISP",
    method: "OPEN",
    path: safeLogPath(requestUrl.pathname),
    host: getRequestHost(request),
    bytes: 0,
    clientIp: getClientIp(request),
    message: bandwidthUnlimited
      ? "WISP aberto sem limite de banda"
      : `WISP aberto; mídia do YouTube limitada a ${wispDefaultBandwidthMbps} Mbps`,
  });
  wisp.routeRequest(request, socket, head, connectionOptions);
});

survivalWebSockets.on("connection", (client, request) => {
  const requestUrl = new URL(request.url, `http://${request.headers.host}`);
  const upstreamUrl = new URL(requestUrl.pathname + requestUrl.search, survivalOrigin);
  upstreamUrl.protocol = survivalOrigin.protocol === "https:" ? "wss:" : "ws:";
  const upstream = new WebSocket(upstreamUrl, {
    headers: {
      "x-forwarded-host": request.headers.host || "",
      "x-forwarded-proto": "https",
      "cf-connecting-ip": request.headers["cf-connecting-ip"] || "",
    },
    maxPayload: 256 * 1024,
  });
  const pending = [];
  client.on("message", (data, binary) => {
    if (upstream.readyState === WebSocket.OPEN) upstream.send(data, { binary });
    else if (upstream.readyState === WebSocket.CONNECTING && pending.length < 20) pending.push([data, binary]);
  });
  upstream.on("open", () => {
    for (const [data, binary] of pending) upstream.send(data, { binary });
    pending.length = 0;
  });
  upstream.on("message", (data, binary) => {
    if (client.readyState === WebSocket.OPEN) client.send(data, { binary });
  });
  const closeClient = () => {
    if (client.readyState === WebSocket.OPEN) client.close(1011, "Game server unavailable");
  };
  upstream.on("error", closeClient);
  upstream.on("close", (code, reason) => {
    if (client.readyState === WebSocket.OPEN) client.close(code || 1000, reason.toString().slice(0, 120));
  });
  client.on("close", () => {
    if (upstream.readyState === WebSocket.OPEN || upstream.readyState === WebSocket.CONNECTING) upstream.close();
  });
});

controlWebSockets.on("connection", (webSocket, request, account) => {
  webSocket.isAlive = true;
  webSocket.on("pong", () => {
    webSocket.isAlive = true;
  });
  sendWebSocketJson(webSocket, {
    type: "handshake",
    protocol: 1,
    authenticated: true,
    username: account.username,
    role: account.role,
    permissions: account.permissions,
    expiresAt: new Date(account.expiresAt).toISOString(),
    serverTime: new Date().toISOString(),
  });
  trafficLog.record({
    direction: "sent",
    channel: "WebSocket",
    method: "MESSAGE",
    path: `${apiPrefix}/connect/<token>/`,
    host: getRequestHost(request),
    message: "Handshake de controle enviado",
  });

  webSocket.on("message", (payload, isBinary) => {
    trafficLog.record({
      direction: "received",
      channel: "WebSocket",
      method: "MESSAGE",
      path: `${apiPrefix}/connect/<token>/`,
      host: getRequestHost(request),
      bytes: payload.length,
      message: "Mensagem de controle recebida",
    });
    if (isBinary) {
      return webSocket.close(1003, "Text messages only");
    }

    let message;
    try {
      message = JSON.parse(payload.toString());
    } catch {
      return webSocket.close(1007, "Invalid JSON");
    }

    if (message.type !== "client-ready" || message.protocol !== 1) {
      return webSocket.close(1008, "Invalid handshake");
    }

    sendWebSocketJson(webSocket, {
      type: "ready",
      protocol: 1,
      proxy: "wisp",
      serverTime: new Date().toISOString(),
    });
  });
});

terminalWebSockets.on("connection", (webSocket, request, account) => {
  const shell =
    env.TERMINAL_SHELL || env.SHELL || "/system/bin/sh";
  const child = spawn(shell, ["-l"], {
    cwd: env.HOME || process.cwd(),
    env: {
      ...env,
      TERM: "xterm-256color",
      COLORTERM: "truecolor",
    },
    stdio: ["pipe", "pipe", "pipe"],
  });

  sendWebSocketJson(webSocket, {
    type: "terminal-ready",
    username: account.username,
    shell,
  });

  const sendOutput = (chunk) => {
    trafficLog.record({
      direction: "sent",
      channel: "Terminal",
      method: "MESSAGE",
      path: `${apiPrefix}/terminal/<token>/`,
      host: getRequestHost(request),
      bytes: chunk.length,
      message: "Saída do terminal enviada; conteúdo oculto",
    });
    sendWebSocketJson(webSocket, {
      type: "output",
      data: chunk.toString("utf8"),
    });
  };
  child.stdout.on("data", sendOutput);
  child.stderr.on("data", sendOutput);
  child.on("error", (error) => {
    sendWebSocketJson(webSocket, {
      type: "error",
      message: error.message,
    });
    webSocket.close(1011, "Shell failed");
  });
  child.on("exit", (code, signal) => {
    sendWebSocketJson(webSocket, {
      type: "exit",
      code,
      signal,
    });
    webSocket.close(1000, "Shell exited");
  });

  webSocket.on("message", (payload, isBinary) => {
    trafficLog.record({
      direction: "received",
      channel: "Terminal",
      method: "MESSAGE",
      path: `${apiPrefix}/terminal/<token>/`,
      host: getRequestHost(request),
      bytes: payload.length,
      message: "Entrada do terminal recebida; conteúdo oculto",
    });
    if (isBinary || payload.length > 64 * 1024) {
      return webSocket.close(1009, "Input too large");
    }
    let message;
    try {
      message = JSON.parse(payload.toString());
    } catch {
      return webSocket.close(1007, "Invalid JSON");
    }
    if (
      message.type === "input" &&
      typeof message.data === "string"
    ) {
      child.stdin.write(message.data);
    }
  });

  webSocket.on("close", () => {
    child.kill("SIGHUP");
  });
});

monitoringWebSockets.on("connection", (webSocket) => {
  webSocket.isAlive = true;
  webSocket.on("pong", () => {
    webSocket.isAlive = true;
  });
  const unsubscribe = monitoring.subscribe((snapshot) => {
    if (webSocket.readyState === WebSocket.OPEN) {
      webSocket.send(snapshot);
    }
  });
  webSocket.on("message", (payload, isBinary) => {
    if (isBinary || payload.length > 1024) {
      return webSocket.close(1003, "Text messages only");
    }
    try {
      const message = JSON.parse(payload.toString());
      if (message.type === "refresh-routes") {
        monitoring.refreshRoutes();
      }
    } catch {
      webSocket.close(1007, "Invalid JSON");
    }
  });
  webSocket.on("close", unsubscribe);
  webSocket.on("error", unsubscribe);
});

logsWebSockets.on("connection", (webSocket) => {
  webSocket.isAlive = true;
  webSocket.on("pong", () => {
    webSocket.isAlive = true;
  });
  const unsubscribe = trafficLog.subscribe((message) => {
    if (webSocket.readyState === WebSocket.OPEN) {
      webSocket.send(message);
    }
  });
  webSocket.on("close", unsubscribe);
  webSocket.on("error", unsubscribe);
});

const controlHeartbeat = setInterval(() => {
  for (const webSocketServer of [
    controlWebSockets,
    monitoringWebSockets,
    logsWebSockets,
  ]) {
    for (const webSocket of webSocketServer.clients) {
      if (!webSocket.isAlive) {
        webSocket.terminate();
        continue;
      }
      webSocket.isAlive = false;
      webSocket.ping();
    }
  }
}, 30_000);
controlHeartbeat.unref();

server.listen(port, host, () => {
  console.log(`Authenticated Wisp listening on http://${host}:${port}`);
  console.log(`API prefix: ${apiPrefix}`);
  console.log(`Allowed hosts: ${[...allowedHosts].join(", ")}`);
  console.log(`Allowed origins: ${[...allowedOrigins].join(", ")}`);
});

function authenticate(request, requestUrl) {
  const claims = verifySessionToken(
    readToken(request, requestUrl),
    sessionSecret,
  );
  return validateClaimsAccount(claims);
}

function authorize(request, requestUrl, permission) {
  const account = authenticate(request, requestUrl);
  return account?.permissions.includes(permission) ? account : null;
}

function authorizeWebSocket(
  request,
  requestUrl,
  pathToken,
  permission,
) {
  const claims = pathToken
    ? verifySessionToken(pathToken, sessionSecret)
    : verifySessionToken(readToken(request, requestUrl), sessionSecret);
  const account = validateClaimsAccount(claims);
  if (!account?.permissions.includes(permission)) return null;
  return account;
}

function validateClaimsAccount(claims) {
  if (!claims) return null;
  const account = accounts.get(claims.sub);
  if (
    !account ||
    account.disabled ||
    claims.ver !== account.tokenVersion ||
    claims.role !== account.role ||
    !sameStringSet(claims.permissions, account.permissions)
  ) {
    return null;
  }
  return {
    ...account,
    sub: account.username,
    expiresAt: claims.exp * 1000,
  };
}

function sameStringSet(left, right) {
  const sortedLeft = [...left].sort();
  const sortedRight = [...right].sort();
  return (
    sortedLeft.length === sortedRight.length &&
    sortedLeft.every(
      (value, index) => value === sortedRight[index],
    )
  );
}

function normalizePrefix(value) {
  const withSlash = value.startsWith("/") ? value : `/${value}`;
  return withSlash.replace(/\/+$/, "");
}

async function coordinateChimeraNickname(request, account) {
  const body = await readJson(request);
  const action = typeof body.action === "string" ? body.action : "";
  const agentId = normalizedOwnershipHeader(
    request,
    "x-chimera-agent-id",
    /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/,
  );
  const ownerId = normalizedOwnershipHeader(
    request,
    "x-chimera-owner-id",
    /^\d{15,22}$/,
  );
  if (!agentId || !ownerId) throw mediaError(400, "cache_identity_required");
  const key = `${account.username}:${ownerId}`;
  const now = Date.now();
  const current = chimeraNicknameLeases.get(key);
  const machineName = typeof body.machineName === "string"
    ? body.machineName.trim().slice(0, 32)
    : "";

  if (action === "release") {
    if (current?.agentId === agentId) chimeraNicknameLeases.delete(key);
    return { ok: true, state: "released" };
  }
  if (action === "false_positive") {
    if (current?.agentId !== agentId) {
      chimeraNicknameLeases.set(key, {
        agentId, machineName, acquiredAt: now, lastSeenAt: now,
        graceUntil: now + CHIMERA_FALSE_POSITIVE_GRACE_MS,
      });
      return {
        ok: true, state: "false_positive",
        graceUntil: new Date(now + CHIMERA_FALSE_POSITIVE_GRACE_MS).toISOString(),
      };
    }
    current.lastSeenAt = now;
    return { ok: true, state: "held" };
  }
  if (action !== "claim" && action !== "heartbeat") {
    throw mediaError(400, "invalid_nickname_lease_action");
  }
  if (current?.agentId === agentId) {
    current.lastSeenAt = now;
    return { ok: true, state: "held", machineName: current.machineName };
  }
  if (current) {
    const protectedUntil = Math.max(
      current.lastSeenAt + CHIMERA_NICKNAME_LEASE_MS,
      current.graceUntil || 0,
    );
    if (now < protectedUntil) {
      return {
        ok: true, state: "busy", machineName: current.machineName,
        retryAfterMs: protectedUntil - now,
      };
    }
  }
  chimeraNicknameLeases.set(key, {
    agentId, machineName, acquiredAt: now, lastSeenAt: now, graceUntil: 0,
  });
  return {
    ok: true,
    state: current ? "recovered" : "claimed",
    machineName,
    previousMachineName: current?.machineName || null,
  };
}

function isAllowedHost(request) {
  return allowedHosts.has(getRequestHost(request));
}

function getRequestHost(request) {
  return String(request.headers.host || "").split(":")[0].toLowerCase();
}

function safeDecodeURIComponent(value) {
  try {
    return decodeURIComponent(value);
  } catch {
    return "";
  }
}

function safeLogPath(value) {
  let pathname;
  try {
    pathname = new URL(value, "http://log.invalid").pathname;
  } catch {
    pathname = "/";
  }
  return pathname
    .replace(
      new RegExp(
        `^${escapeRegex(apiPrefix)}/wisp/limited/[^/]+/`,
      ),
      `${apiPrefix}/wisp/limited/<token>/`,
    )
    .replace(
    new RegExp(
      `^${escapeRegex(apiPrefix)}/(wisp|connect|monitoring|terminal|logs)/[^/]+/`,
    ),
    `${apiPrefix}/$1/<token>/`,
  );
}

function classifyUpgrade(pathname) {
  if (pathname.startsWith(`${apiPrefix}/wisp/`)) return "WISP";
  if (pathname.startsWith(`${apiPrefix}/terminal/`)) return "Terminal";
  if (pathname.startsWith(`${apiPrefix}/monitoring/`)) {
    return "Monitoring";
  }
  return "WebSocket";
}

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function sendWebSocketJson(webSocket, value) {
  if (webSocket.readyState === WebSocket.OPEN) {
    webSocket.send(JSON.stringify(value));
  }
}

function acquireWispBandwidthLimiter(accountUsername) {
  let entry = limitedWispAccounts.get(accountUsername);
  if (!entry) {
    entry = {
      limiter: new SharedBandwidthLimiter({
        bitsPerSecond: wispDefaultBandwidthBitsPerSecond,
      }),
      references: 0,
    };
    limitedWispAccounts.set(accountUsername, entry);
  }
  entry.references += 1;
  let released = false;
  return {
    limiter: entry.limiter,
    release() {
      if (released) return;
      released = true;
      entry.references -= 1;
      if (entry.references <= 0) {
        limitedWispAccounts.delete(accountUsername);
      }
    },
  };
}

function validateConfiguration() {
  const errors = [];
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    errors.push("PORT must be a valid TCP port");
  }
  if (
    !Number.isInteger(publicPort) ||
    publicPort < 1 ||
    publicPort > 65535
  ) {
    errors.push("PUBLIC_PORT must be a valid TCP port");
  }
  if (!username) errors.push("AUTH_USERNAME is required");
  if (!passwordHash.startsWith("scrypt$")) {
    errors.push("AUTH_PASSWORD_HASH must be generated with npm run hash-password");
  }
  if (!ownerUsername) errors.push("OWNER_USERNAME is required");
  if (!ownerPasswordHash.startsWith("scrypt$")) {
    errors.push("OWNER_PASSWORD_HASH must be generated with npm run hash-password");
  }
  if (
    !Number.isFinite(wispDefaultBandwidthMbps) ||
    wispDefaultBandwidthMbps < 0.5 ||
    wispDefaultBandwidthMbps > 1000
  ) {
    errors.push(
      "WISP_DEFAULT_BANDWIDTH_MBPS must be between 0.5 and 1000",
    );
  }
  if (!Number.isFinite(mediaUploadTtlSeconds) || mediaUploadTtlSeconds <= 0) {
    errors.push("MEDIA_UPLOAD_TTL_SECONDS must be greater than zero");
  }
  if (sessionSecret.length < 32) {
    errors.push("SESSION_SECRET must contain at least 32 characters");
  }
  if (gameSessionSecret.length < 32) {
    errors.push("GAME_SESSION_SECRET must contain at least 32 characters");
  }
  if (allowedOrigins.size === 0) errors.push("ALLOWED_ORIGINS is required");
  if (errors.length > 0) {
    throw new Error(`Invalid configuration:\n- ${errors.join("\n- ")}`);
  }
}

function applySecurityHeaders(response) {
  response.setHeader("Cache-Control", "no-store");
  response.setHeader("X-Content-Type-Options", "nosniff");
  response.setHeader("X-Frame-Options", "DENY");
  response.setHeader("Referrer-Policy", "no-referrer");
  response.setHeader(
    "Permissions-Policy",
    "camera=(), microphone=(), geolocation=()",
  );
}

function proxySurvivalHttp(request, response) {
  const upstream = http.request(
    {
      protocol: survivalOrigin.protocol,
      hostname: survivalOrigin.hostname,
      port: survivalOrigin.port || undefined,
      method: request.method,
      path: request.url,
      headers: {
        ...request.headers,
        host: survivalOrigin.host,
        "x-forwarded-host": request.headers.host || "",
        "x-forwarded-proto": "https",
      },
    },
    (upstreamResponse) => {
      const headers = { ...upstreamResponse.headers };
      delete headers["x-frame-options"];
      response.writeHead(upstreamResponse.statusCode || 502, headers);
      upstreamResponse.pipe(response);
    },
  );
  upstream.setTimeout(15_000, () => upstream.destroy(new Error("upstream_timeout")));
  upstream.on("error", () => {
    if (!response.headersSent) return sendJson(response, 502, { error: "game_unavailable" });
    response.destroy();
  });
  request.pipe(upstream);
}

function sendJson(response, statusCode, value) {
  const body = JSON.stringify(value);
  response.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
  });
  response.end(body);
}

function sendEmpty(response, statusCode) {
  response.writeHead(statusCode, {
    "Content-Length": "0",
  });
  response.end();
}

async function sendShortPanelFileDownload(request, response, encodedName, forceDownload = false) { try { const name = decodeURIComponent(encodedName); const item = await panelFileStore.publicByName(name); if (!item) return sendEmpty(response, 404); const target = `https://${publicDomain}${apiPrefix}/files/${item.metadata.id}/raw/content${forceDownload ? "?download=1" : ""}`; response.writeHead(302, { Location: target, "Cache-Control": "public, max-age=300" }); response.end(); } catch { sendEmpty(response, 404); } }

async function sendPanelDownload(request, response) {
  try {
    const panelPath = fileURLToPath(new URL("../d2-panel.html", import.meta.url));
    const file = await stat(panelPath);
    response.writeHead(200, { "Content-Type": "text/html; charset=UTF-8", "Content-Length": file.size, "Cache-Control": "no-cache" });
    if (request.method === "HEAD") return response.end();
    createReadStream(panelPath).pipe(response);
  } catch { sendJson(response, 404, { error: "panel_not_found" }); }
}

async function sendClientDownload(request, response) {
  try {
    const file = await stat(clientIndex);
    response.writeHead(200, {
      "Content-Type": "text/html; charset=UTF-8",
      "Content-Length": file.size,
      "Content-Disposition": 'attachment; filename="index.html"',
      "Cache-Control": "no-cache",
    });
    if (request.method === "HEAD") return response.end();
    createReadStream(clientIndex).pipe(response);
  } catch {
    sendJson(response, 404, { error: "client_not_built" });
  }
}

async function sendChimeraDownload(request, response) {
  try {
    const file = await stat(chimeraArchive);
    response.writeHead(200, {
      "Content-Type": "application/zip",
      "Content-Length": file.size,
      "Content-Disposition": 'attachment; filename="chimera.zip"',
      "Cache-Control": "no-cache",
    });
    if (request.method === "HEAD") return response.end();
    createReadStream(chimeraArchive).pipe(response);
  } catch {
    sendJson(response, 404, { error: "chimera_not_found" });
  }
}

async function sendChimeraInstallerDownload(request, response) {
  try {
    const file = await stat(chimeraInstallerArchive);
    response.writeHead(200, {
      "Content-Type": "application/zip",
      "Content-Length": file.size,
      "Content-Disposition": 'attachment; filename="chimera-installer.zip"',
      "Cache-Control": "no-cache",
    });
    if (request.method === "HEAD") return response.end();
    createReadStream(chimeraInstallerArchive).pipe(response);
  } catch {
    sendJson(response, 404, { error: "chimera_installer_not_found" });
  }
}

function mediaError(statusCode, publicCode) {
  const error = new Error(publicCode);
  error.statusCode = statusCode;
  error.publicCode = publicCode;
  return error;
}

function normalizedMediaType(request) {
  return String(request.headers["content-type"] || "")
    .split(";", 1)[0]
    .trim()
    .toLowerCase();
}

function normalizedOwnershipHeader(request, name, pattern) {
  const value = String(request.headers[name] || "").trim().toLowerCase();
  if (!value) return null;
  if (!pattern.test(value)) throw mediaError(400, "invalid_cache_identity");
  return value;
}

function mediaOwnership(request, account) {
  return {
    account: account.username,
    agentId: normalizedOwnershipHeader(
      request,
      "x-chimera-agent-id",
      /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/,
    ),
    ownerId: normalizedOwnershipHeader(
      request,
      "x-chimera-owner-id",
      /^\d{15,22}$/,
    ),
  };
}

function mediaMetadataPath(filename) {
  return `${mediaMetadataDirectory}/${filename}.json`;
}

async function receiveTemporaryMedia(request, account) {
  const contentType = normalizedMediaType(request);
  const rule = mediaTypes[contentType];
  if (!rule) throw mediaError(415, "unsupported_media_type");
  const ownership = mediaOwnership(request, account);

  const declaredSize = Number(request.headers["content-length"]);
  if (!Number.isInteger(declaredSize) || declaredSize < 1) {
    throw mediaError(411, "content_length_required");
  }
  if (declaredSize > rule.limit) {
    throw mediaError(413, "media_too_large");
  }

  const identifier = randomBytes(18).toString("hex");
  const filename = `${identifier}.${rule.extension}`;
  const filePath = `${mediaUploadDirectory}/${filename}`;
  let receivedSize = 0;
  const limiter = new Transform({
    transform(chunk, encoding, callback) {
      receivedSize += chunk.length;
      if (receivedSize > rule.limit) {
        callback(mediaError(413, "media_too_large"));
        return;
      }
      callback(null, chunk);
    },
  });

  try {
    await pipeline(
      request,
      limiter,
      createWriteStream(filePath, { flags: "wx", mode: 0o600 }),
    );
    if (receivedSize !== declaredSize) {
      throw mediaError(400, "content_length_mismatch");
    }
    await writeFile(
      mediaMetadataPath(filename),
      JSON.stringify(ownership),
      { flag: "wx", mode: 0o600 },
    );
  } catch (error) {
    await unlink(filePath).catch(() => {});
    await unlink(mediaMetadataPath(filename)).catch(() => {});
    throw error;
  }

  return {
    ok: true,
    url: `${mediaPublicBaseUrl}/${filename}`,
    contentType,
    size: receivedSize,
    expiresAt: new Date(Date.now() + mediaUploadTtlMs).toISOString(),
  };
}

async function removeTemporaryMedia(filename) {
  const filePath = `${mediaUploadDirectory}/${filename}`;
  const existed = await stat(filePath).then(() => true).catch(() => false);
  await unlink(filePath).catch(() => {});
  await unlink(mediaMetadataPath(filename)).catch(() => {});
  return existed;
}

async function clearTemporaryMedia(request, account, scope) {
  const ownership = mediaOwnership(request, account);
  const field = scope === "owner" ? "ownerId" : "agentId";
  const expected = ownership[field];
  if (!expected) throw mediaError(400, "cache_identity_required");

  const entries = await readdir(mediaMetadataDirectory, { withFileTypes: true })
    .catch(() => []);
  let deleted = 0;
  for (const entry of entries) {
    const match = /^([a-f0-9]{36}\.[a-z0-9]+)\.json$/.exec(entry.name);
    if (!entry.isFile() || !match) continue;
    let metadata;
    try {
      metadata = JSON.parse(
        await readFile(`${mediaMetadataDirectory}/${entry.name}`, "utf8"),
      );
    } catch {
      continue;
    }
    if (metadata.account !== account.username || metadata[field] !== expected) {
      continue;
    }
    if (await removeTemporaryMedia(match[1])) deleted += 1;
  }
  return deleted;
}

function matchPublicMediaPath(pathname) {
  const prefix = `${apiPrefix}/media/files/`;
  if (!pathname.startsWith(prefix)) return null;
  const filename = pathname.slice(prefix.length);
  const match = /^([a-f0-9]{36})\.([a-z0-9]+)$/.exec(filename);
  if (!match || !mediaTypesByExtension[match[2]]) return null;
  return {
    filename,
    contentType: mediaTypesByExtension[match[2]],
  };
}

function requestedByteRange(value, size) {
  if (!value) return null;
  const match = /^bytes=(\d*)-(\d*)$/.exec(String(value).trim());
  if (!match) return false;
  let start;
  let end;
  if (!match[1]) {
    const suffixLength = Number(match[2]);
    if (!Number.isInteger(suffixLength) || suffixLength < 1) return false;
    start = Math.max(0, size - suffixLength);
    end = size - 1;
  } else {
    start = Number(match[1]);
    end = match[2] ? Number(match[2]) : size - 1;
  }
  if (
    !Number.isInteger(start) ||
    !Number.isInteger(end) ||
    start < 0 ||
    end < start ||
    start >= size
  ) return false;
  return { start, end: Math.min(end, size - 1) };
}

async function sendTemporaryMedia(request, response, media) {
  const filePath = `${mediaUploadDirectory}/${media.filename}`;
  let file;
  try {
    file = await stat(filePath);
  } catch {
    return sendJson(response, 404, { error: "media_not_found" });
  }
  if (Date.now() - file.mtimeMs >= mediaUploadTtlMs) {
    await removeTemporaryMedia(media.filename);
    return sendJson(response, 404, { error: "media_expired" });
  }

  const range = requestedByteRange(request.headers.range, file.size);
  if (range === false) {
    response.writeHead(416, {
      "Content-Range": `bytes */${file.size}`,
      "Content-Length": "0",
    });
    return response.end();
  }
  const start = range?.start ?? 0;
  const end = range?.end ?? file.size - 1;
  response.writeHead(range ? 206 : 200, {
    "Content-Type": media.contentType,
    "Content-Length": end - start + 1,
    "Content-Disposition": `inline; filename="${media.filename}"`,
    "Accept-Ranges": "bytes",
    "Cache-Control": "no-store",
    ...(range ? { "Content-Range": `bytes ${start}-${end}/${file.size}` } : {}),
  });
  if (request.method === "HEAD") return response.end();
  createReadStream(filePath, { start, end }).pipe(response);
}

async function cleanupExpiredMedia() {
  const entries = await readdir(mediaUploadDirectory, { withFileTypes: true })
    .catch(() => []);
  const now = Date.now();
  await Promise.all(entries.map(async (entry) => {
    if (!entry.isFile() || !/^[a-f0-9]{36}\.[a-z0-9]+$/.test(entry.name)) {
      return;
    }
    const filePath = `${mediaUploadDirectory}/${entry.name}`;
    const file = await stat(filePath).catch(() => null);
    if (file && now - file.mtimeMs >= mediaUploadTtlMs) {
      await removeTemporaryMedia(entry.name);
    }
  }));

  const metadataEntries = await readdir(mediaMetadataDirectory, {
    withFileTypes: true,
  }).catch(() => []);
  await Promise.all(metadataEntries.map(async (entry) => {
    const match = /^([a-f0-9]{36}\.[a-z0-9]+)\.json$/.exec(entry.name);
    if (!entry.isFile() || !match) return;
    const file = await stat(`${mediaUploadDirectory}/${match[1]}`).catch(() => null);
    if (!file) {
      await unlink(`${mediaMetadataDirectory}/${entry.name}`).catch(() => {});
    }
  }));
}

async function readJson(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 16 * 1024) {
      const error = new Error("request_too_large");
      error.statusCode = 413;
      throw error;
    }
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

function getClientIp(request) {
  if (trustCloudflare && request.headers["cf-connecting-ip"]) {
    return String(request.headers["cf-connecting-ip"]);
  }
  return request.socket.remoteAddress || "unknown";
}

function consumeLoginAttempt(clientIp) {
  const now = Date.now();
  const existing = loginAttempts.get(clientIp);
  if (!existing || now - existing.startedAt >= LOGIN_WINDOW_MS) {
    loginAttempts.set(clientIp, { count: 1, startedAt: now });
    return true;
  }
  existing.count += 1;
  return existing.count <= LOGIN_LIMIT;
}

function rejectUpgrade(socket, statusCode, message) {
  socket.write(
    `HTTP/1.1 ${statusCode} ${message}\r
Connection: close\r
Content-Length: 0\r
\r
`,
  );
  socket.destroy();
}
