/** Ten-minute step-up grants bound to a single authenticated session. */
export function createAdminReauth({ttlMs=600000,now=Date.now}={}) {
 const grants=new Map();
 const key=claims=>claims&&typeof claims.jti==='string'?`${claims.sub}:${claims.ver}:${claims.jti}`:null;
 return {
  expiresAt(claims){const id=key(claims),expiry=grants.get(id)||0;if(expiry<=now()){grants.delete(id);return 0;}return expiry;},
  grant(claims){const id=key(claims);if(!id)throw Error('invalid_session');const time=now();for(const [id,expiry] of grants)if(expiry<=time)grants.delete(id);if(grants.size>=10000)grants.delete(grants.keys().next().value);const expiry=time+ttlMs;grants.set(id,expiry);return expiry;},
 };
}
