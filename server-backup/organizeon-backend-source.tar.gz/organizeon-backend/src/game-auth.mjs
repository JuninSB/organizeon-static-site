import { createHmac, timingSafeEqual } from "node:crypto";

export const GAME_SESSION_TTL_SECONDS = 5 * 60;

const THEME_COLORS = Object.freeze({
  maple: 0x5df0c8,
  ocean: 0x39c9ef,
  purple: 0xd58cff,
  sunset: 0xffa65c,
  rose: 0xff858d,
});

function encode(value) {
  return Buffer.from(JSON.stringify(value)).toString("base64url");
}

function signature(payload, secret) {
  return createHmac("sha256", secret).update(payload).digest("base64url");
}

export function createGameSession(account, secret, themeId = "maple", now = Date.now()) {
  const issuedAt = Math.floor(now / 1000);
  const gamePermissions = account.permissions.filter((permission) =>
    permission.startsWith("game.suroi.") ||
    permission.startsWith("game.survival."),
  );
  const tag = account.role === "owner"
    ? "[Owner]"
    : gamePermissions.includes("game.suroi.admin") ||
        gamePermissions.includes("game.survival.admin")
      ? "[ADMIN]"
      : "";
  const payload = encode({
    sub: account.username,
    role: account.role,
    tag,
    nameColor: THEME_COLORS[themeId] ?? THEME_COLORS.maple,
    permissions: gamePermissions,
    iat: issuedAt,
    exp: issuedAt + GAME_SESSION_TTL_SECONDS,
    aud: "organizeon-suroi",
  });
  return `${payload}.${signature(payload, secret)}`;
}

export function verifyGameSession(token, secret, now = Date.now()) {
  if (typeof token !== "string") return null;
  const [payload, receivedSignature, extra] = token.split(".");
  if (!payload || !receivedSignature || extra) return null;
  const expected = Buffer.from(signature(payload, secret));
  const received = Buffer.from(receivedSignature);
  if (
    expected.length !== received.length ||
    !timingSafeEqual(expected, received)
  ) return null;
  try {
    const claims = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    const currentTime = Math.floor(now / 1000);
    if (
      claims.aud !== "organizeon-suroi" ||
      typeof claims.sub !== "string" ||
      typeof claims.role !== "string" ||
      typeof claims.tag !== "string" ||
      typeof claims.nameColor !== "number" ||
      !Array.isArray(claims.permissions) ||
      !claims.permissions.every((permission) => typeof permission === "string") ||
      typeof claims.iat !== "number" ||
      typeof claims.exp !== "number" ||
      claims.exp <= currentTime ||
      claims.iat > currentTime + 60
    ) return null;
    return claims;
  } catch {
    return null;
  }
}
