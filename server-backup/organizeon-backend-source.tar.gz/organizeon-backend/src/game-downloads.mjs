import {readFile,stat} from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import {join} from 'node:path';
/** Public, allowlisted static archives. No executable HTML or filesystem browsing. */
export function createGameDownloadsHandler({root}) {
  let cached;
  return async (request,response) => {
    const path=new URL(request.url,'http://download.invalid').pathname;
    if(!path.startsWith('/d1/downloads/'))return false;
    const headers={'Access-Control-Allow-Origin':'*','Access-Control-Expose-Headers':'Content-Length, ETag','X-Content-Type-Options':'nosniff'};
    if(!['GET','HEAD'].includes(request.method)){response.writeHead(405,{...headers,Allow:'GET, HEAD'});response.end();return true;}
    let stream;
    try {
      const manifestPath=join(root,'downloads.json');const info=await stat(manifestPath);
      if(!cached||cached.modified!==info.mtimeMs)cached={modified:info.mtimeMs,files:JSON.parse(await readFile(manifestPath,'utf8'))};
      const name=decodeURIComponent(path.slice('/d1/downloads/'.length));
      if(!/^[a-zA-Z0-9_.-]+\.zip$/.test(name)||!Object.hasOwn(cached.files,name)){response.writeHead(404,headers);response.end();return true;}
      const entry=cached.files[name],file=join(root,name);const actual=await stat(file);
      if(!actual.isFile()||actual.size!==entry.size)throw Error('Invalid archive');
      const tag='"'+entry.sha256+'"';
      const output={...headers,'Content-Type':'application/zip','Content-Disposition':`attachment; filename="${name}"`,'Cache-Control':'public, max-age=3600',ETag:tag};
      if(request.headers['if-none-match']===tag){response.writeHead(304,output);response.end();return true;}
      if(request.method==='HEAD'){response.writeHead(200,{...output,'Content-Length':actual.size});response.end();return true;}
      stream=createReadStream(file);await new Promise((resolve,reject)=>{stream.once('open',resolve);stream.once('error',reject);});
      response.writeHead(200,{...output,'Content-Length':actual.size});
      response.once('close',()=>stream.destroy());stream.on('error',()=>response.destroy()).pipe(response);
    }catch{stream?.destroy();if(!response.headersSent)response.writeHead(503,{...headers,'Cache-Control':'no-store'});response.end();}
    return true;
  };
}
