import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { createHash, randomInt, timingSafeEqual } from "node:crypto";
import { hashPassword, verifyPassword } from "./auth.mjs";

export const ROLES = Object.freeze([
  "user",
  "admin",
  "ultra_admin",
  "owner",
]);

export const BASE_PERMISSIONS = Object.freeze([
  "proxy.use",
  "media.upload",
  "admin.dashboard",
  "admin.monitoring",
  "admin.users",
  "admin.terminal",
]);

export const EXTRA_PERMISSIONS = Object.freeze([
  "game.suroi.admin",
  "game.suroi.godmode",
  "game.suroi.spawn",
  "game.suroi.barrier",
  "game.suroi.speed",
  "game.suroi.time",
  "game.survival.admin",
  "game.survival.godmode",
  "game.survival.spawn",
  "game.survival.speed",
  "game.survival.world",
  "services.api.restart",
  "services.relay.manage",
  "services.servers.manage",
]);

export const ALL_PERMISSIONS = Object.freeze([
  ...BASE_PERMISSIONS,
  ...EXTRA_PERMISSIONS,
]);
export const DEFAULT_USER_PERMISSIONS = Object.freeze(["proxy.use"]);
export const REGISTERED_USER_PERMISSIONS = Object.freeze([]);
const HIDDEN_SYSTEM_USERNAME = "organizeon";

const ROLE_RANK = Object.freeze({
  user: 0,
  admin: 1,
  ultra_admin: 2,
  owner: 3,
});
const LOGIN_CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const LOGIN_CODE_TTL_MS = 15 * 60 * 1000;

export async function createAccountStore({
  filePath,
  initialAdminUsername,
  initialAdminPasswordHash,
  initialOwnerUsername,
  initialOwnerPasswordHash,
}) {
  let state = await loadState(filePath);
  let bootstrapChanged = false;

  if (initialAdminUsername && !state.users[initialAdminUsername]) {
    state.users[initialAdminUsername] = makeAccount({
      username: initialAdminUsername,
      passwordHash: initialAdminPasswordHash,
      role: "admin",
      permissions: defaultPermissions("admin"),
    });
    bootstrapChanged = true;
  }

  if (initialOwnerUsername && !state.users[initialOwnerUsername]) {
    state.users[initialOwnerUsername] = makeAccount({
      username: initialOwnerUsername,
      passwordHash: initialOwnerPasswordHash,
      role: "owner",
      permissions: [...ALL_PERMISSIONS],
      hidden: initialOwnerUsername === HIDDEN_SYSTEM_USERNAME,
    });
    bootstrapChanged = true;
  }

  if (bootstrapChanged) await persist();

  return Object.freeze({
    authenticate(username, password) {
      const account = state.users[username];
      if (
        !account ||
        account.disabled ||
        !verifyPassword(password, account.passwordHash)
      ) {
        return null;
      }
      return publicAccount(account);
    },

    async authenticateLoginCode(code) {
      const normalized = normalizeLoginCode(code);
      if (!normalized) return null;
      const now = Date.now();
      for (const account of Object.values(state.users)) {
        const loginCode = account.loginCode;
        if (
          !loginCode ||
          account.disabled ||
          new Date(loginCode.expiresAt).getTime() <= now
        ) continue;
        const received = Buffer.from(
          hashLoginCode(normalized, loginCode.salt),
          "hex",
        );
        const expected = Buffer.from(loginCode.hash, "hex");
        if (
          received.length !== expected.length ||
          !timingSafeEqual(received, expected)
        ) continue;
        delete account.loginCode;
        await persist();
        return publicAccount(account);
      }
      return null;
    },

    get(username) {
      const account = state.users[username];
      return account ? publicAccount(account) : null;
    },

    async register({ username, password }) {
      validateUsername(username);
      if (state.users[username]) throw accountError(409, "username_exists");
      const account = makeAccount({
        username,
        passwordHash: hashPassword(password),
        role: "user",
        permissions: [...REGISTERED_USER_PERMISSIONS],
        hidden: false,
      });
      state.users[username] = account;
      await persist();
      return publicAccount(account);
    },

    list(actor) {
      requirePermission(actor, "admin.users");
      return Object.values(state.users)
        .filter((account) => !account.hidden)
        .map(publicAccount)
        .sort((left, right) => left.username.localeCompare(right.username));
    },

    capabilities(actor) {
      requirePermission(actor, "admin.users");
      return {
        roles: ROLES.filter((role) => canCreateRole(actor, role)),
        permissions: permissionsActorCanGrant(actor),
        allPermissions: [...ALL_PERMISSIONS],
      };
    },

    async create(actor, { username, password, role = "user", permissions }) {
      requirePermission(actor, "admin.users");
      validateUsername(username);
      validateRole(role);
      if (!canCreateRole(actor, role)) {
        throw accountError(403, "cannot_assign_role");
      }
      if (state.users[username]) {
        throw accountError(409, "username_exists");
      }
      const normalizedPermissions = normalizePermissions(role, permissions);
      ensureCanGrantPermissions(actor, normalizedPermissions);
      const account = makeAccount({
        username,
        passwordHash: hashPassword(password),
        role,
        permissions: normalizedPermissions,
        hidden: username === HIDDEN_SYSTEM_USERNAME,
      });
      state.users[username] = account;
      await persist();
      return publicAccount(account);
    },

    async update(actor, username, changes) {
      const account = state.users[username];
      if (!account) throw accountError(404, "user_not_found");
      requirePermission(actor, "admin.users");
      validateUpdateAuthority(actor, account, changes);

      const nextRole =
        changes.role === undefined ? account.role : changes.role;
      validateRole(nextRole);
      if (nextRole !== account.role && !canCreateRole(actor, nextRole)) {
        throw accountError(403, "cannot_assign_role");
      }
      const nextDisabled =
        changes.disabled === undefined
          ? account.disabled
          : Boolean(changes.disabled);
      const nextPermissions =
        changes.permissions === undefined
          ? normalizePermissions(nextRole, account.permissions)
          : normalizePermissions(nextRole, changes.permissions);
      ensureCanGrantPermissions(actor, nextPermissions);

      if (
        account.role === "owner" &&
        !account.disabled &&
        (nextRole !== "owner" || nextDisabled) &&
        countEnabledRole("owner") <= 1
      ) {
        throw accountError(409, "last_owner");
      }

      const securityChanged =
        account.role !== nextRole ||
        account.disabled !== nextDisabled ||
        !samePermissions(account.permissions, nextPermissions) ||
        changes.password !== undefined;
      if (!securityChanged) return publicAccount(account);

      account.role = nextRole;
      account.permissions = nextPermissions;
      account.disabled = nextDisabled;
      account.hidden = account.username === HIDDEN_SYSTEM_USERNAME;
      if (changes.password !== undefined) {
        account.passwordHash = hashPassword(changes.password);
      }
      account.tokenVersion += 1;
      account.updatedAt = new Date().toISOString();
      await persist();
      return publicAccount(account);
    },

    async createLoginCode(actor, username) {
      const account = state.users[username];
      if (!account) throw accountError(404, "user_not_found");
      requirePermission(actor, "admin.users");
      if ((ROLE_RANK[actor.role] ?? -1) < (ROLE_RANK[account.role] ?? -1)) {
        throw accountError(403, "cannot_view_higher_role_login_code");
      }
      if (
        account.username === HIDDEN_SYSTEM_USERNAME &&
        actor.username !== HIDDEN_SYSTEM_USERNAME
      ) {
        throw accountError(403, "system_account_required");
      }
      const code = Array.from({ length: 6 }, () =>
        LOGIN_CODE_ALPHABET[randomInt(LOGIN_CODE_ALPHABET.length)],
      ).join("");
      const salt = Array.from({ length: 16 }, () =>
        randomInt(256).toString(16).padStart(2, "0"),
      ).join("");
      const expiresAt = new Date(Date.now() + LOGIN_CODE_TTL_MS).toISOString();
      account.loginCode = {
        hash: hashLoginCode(code, salt),
        salt,
        expiresAt,
      };
      await persist();
      return { code, expiresAt };
    },

    async remove(actor, username) {
      const account = state.users[username];
      if (!account) throw accountError(404, "user_not_found");
      requirePermission(actor, "admin.users");
      if (actor.username === username) {
        throw accountError(409, "cannot_delete_current_user");
      }
      validateUpdateAuthority(actor, account, { remove: true });
      if (
        account.role === "owner" &&
        !account.disabled &&
        countEnabledRole("owner") <= 1
      ) {
        throw accountError(409, "last_owner");
      }
      delete state.users[username];
      await persist();
    },
  });

  function countEnabledRole(role) {
    return Object.values(state.users).filter(
      (account) => account.role === role && !account.disabled,
    ).length;
  }

  async function persist() {
    await mkdir(dirname(filePath), { recursive: true });
    const temporaryPath = `${filePath}.tmp`;
    await writeFile(
      temporaryPath,
      `${JSON.stringify(state, null, 2)}\n`,
      { mode: 0o600 },
    );
    await rename(temporaryPath, filePath);
  }
}

async function loadState(filePath) {
  try {
    const parsed = JSON.parse(await readFile(filePath, "utf8"));
    if (!parsed || parsed.version !== 1 || !parsed.users) {
      throw new Error("Unsupported accounts database");
    }
    for (const account of Object.values(parsed.users)) {
      account.hidden = account.username === HIDDEN_SYSTEM_USERNAME;
      account.permissions = normalizePermissions(
        account.role,
        account.permissions,
      );
    }
    return parsed;
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    return { version: 1, users: {} };
  }
}

function makeAccount({ username, passwordHash, role, permissions, hidden = false }) {
  const now = new Date().toISOString();
  return {
    username,
    passwordHash,
    role,
    permissions,
    tokenVersion: 1,
    disabled: false,
    hidden,
    createdAt: now,
    updatedAt: now,
  };
}

function publicAccount(account) {
  return {
    username: account.username,
    role: account.role,
    permissions: [...account.permissions],
    tokenVersion: account.tokenVersion,
    disabled: account.disabled,
    createdAt: account.createdAt,
    updatedAt: account.updatedAt,
  };
}

function validateUsername(username) {
  if (
    typeof username !== "string" ||
    !/^[a-zA-Z0-9_.-]{3,32}$/.test(username)
  ) {
    throw accountError(400, "invalid_username");
  }
}

function normalizeLoginCode(code) {
  if (typeof code !== "string") return "";
  const normalized = code.trim().toUpperCase();
  return /^[A-Z0-9]{6}$/.test(normalized) ? normalized : "";
}

function hashLoginCode(code, salt) {
  return createHash("sha256").update(`${salt}:${code}`).digest("hex");
}

function validateRole(role) {
  if (!ROLES.includes(role)) {
    throw accountError(400, "invalid_role");
  }
}

function defaultPermissions(role) {
  if (role === "owner" || role === "ultra_admin") {
    return [...ALL_PERMISSIONS];
  }
  if (role === "admin") return [...BASE_PERMISSIONS];
  return [...DEFAULT_USER_PERMISSIONS];
}

function normalizePermissions(role, permissions) {
  const requested = permissions === undefined
    ? defaultPermissions(role)
    : permissions;
  if (!Array.isArray(requested)) {
    throw accountError(400, "invalid_permissions");
  }
  if (requested.some((permission) => !ALL_PERMISSIONS.includes(permission))) {
    throw accountError(400, "invalid_permissions");
  }
  return [...new Set(requested)];
}

function requirePermission(actor, permission) {
  if (!actor?.permissions?.includes(permission)) {
    throw accountError(403, "forbidden");
  }
}

function canCreateRole(actor, role) {
  if (!actor || !ROLES.includes(actor.role)) return false;
  if (role === "owner") return actor.role === "owner";
  if (role === "ultra_admin") {
    return actor.role === "ultra_admin" || actor.role === "owner";
  }
  return ROLE_RANK[role] <= ROLE_RANK[actor.role];
}

function permissionsActorCanGrant(actor) {
  if (actor.role === "owner" || actor.role === "ultra_admin") {
    return [...ALL_PERMISSIONS];
  }
  return actor.permissions.filter(
    (permission) => !EXTRA_PERMISSIONS.includes(permission),
  );
}

function ensureCanGrantPermissions(actor, permissions) {
  const allowed = new Set(permissionsActorCanGrant(actor));
  if (permissions.some((permission) => !allowed.has(permission))) {
    throw accountError(403, "cannot_grant_permission");
  }
}

function validateUpdateAuthority(actor, target, changes) {
  if (
    target.username === HIDDEN_SYSTEM_USERNAME &&
    actor.username !== HIDDEN_SYSTEM_USERNAME
  ) {
    throw accountError(403, "system_account_required");
  }
  const actorRank = ROLE_RANK[actor.role] ?? -1;
  const targetRank = ROLE_RANK[target.role] ?? -1;
  if (actorRank < targetRank) {
    throw accountError(403, "cannot_manage_higher_role");
  }

  if (actor.username === target.username) {
    const keys = Object.keys(changes).filter(
      (key) => changes[key] !== undefined,
    );
    if (keys.some((key) => key !== "password")) {
      throw accountError(403, "cannot_change_own_access");
    }
    return;
  }

  if (actorRank === targetRank && actor.role !== "owner") {
    const keys = Object.keys(changes).filter(
      (key) => changes[key] !== undefined,
    );
    if (keys.some((key) => key !== "password")) {
      throw accountError(403, "cannot_change_peer_access");
    }
  }

  if (target.role === "ultra_admin" && actor.role !== "owner") {
    const keys = Object.keys(changes).filter(
      (key) => changes[key] !== undefined,
    );
    if (keys.some((key) => key !== "password")) {
      throw accountError(403, "owner_required");
    }
  }
}

function accountError(statusCode, code) {
  return Object.assign(new Error(code), { statusCode, code });
}

function samePermissions(left, right) {
  const sortedLeft = [...left].sort();
  const sortedRight = [...right].sort();
  return (
    sortedLeft.length === sortedRight.length &&
    sortedLeft.every(
      (permission, index) => permission === sortedRight[index],
    )
  );
}
