import os from "node:os";
import http from "node:http";
import https from "node:https";
import { lookup as dnsLookup } from "node:dns";
import { mkdir, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";

export function createMonitoring({ snapshotFile, service = {} } = {}) {
  let timer = null;
  let routeProbeTimer = null;
  let routeProbeRunning = false;
  let history = [];
  let requests = [];
  let totalRequests = 0;
  let totalWebSocketUpgrades = 0;
  let lastRequestAt = null;
  const domainRequestTotals = new Map();
  const domainActivity = new Map();
  const routeResults = new Map(
    (service.routes || []).map((route) => [
      route.id,
      {
        status: "pending",
        statusCode: null,
        latencyMs: null,
        checkedAt: null,
      },
    ]),
  );
  let previousCpu = readCpuTimes();
  let startedAt = null;
  let persistQueue = Promise.resolve();
  const subscribers = new Set();
  let cachedSnapshot = buildSnapshot(false, Date.now());
  let serializedSnapshot = JSON.stringify(cachedSnapshot);

  return Object.freeze({
    subscribe(listener) {
      subscribers.add(listener);
      if (subscribers.size === 1) start();
      else collect();

      let subscribed = true;
      return () => {
        if (!subscribed) return;
        subscribed = false;
        subscribers.delete(listener);
        if (subscribers.size === 0) stop();
        else collect();
      };
    },

    recordRequest({
      durationMs,
      statusCode,
      host = "",
      kind = "http",
    }) {
      const now = Date.now();
      totalRequests += 1;
      if (kind === "websocket") totalWebSocketUpgrades += 1;
      lastRequestAt = new Date(now).toISOString();
      const normalizedHost = String(host).toLowerCase();
      if (normalizedHost) domainActivity.set(normalizedHost, now);
      const requestDomain = normalizedHost || "unknown";
      domainRequestTotals.set(
        requestDomain,
        (domainRequestTotals.get(requestDomain) || 0) + 1,
      );
      requests.push({
        at: now,
        durationMs,
        statusCode,
        kind,
        host: requestDomain,
      });
      pruneRequests(now);
      if (subscribers.size === 0) {
        cachedSnapshot = buildSnapshot(false, now);
        serializedSnapshot = JSON.stringify(cachedSnapshot);
      }
    },

    snapshot() {
      return cachedSnapshot;
    },

    refreshRoutes() {
      return probeRoutes();
    },
  });

  function start() {
    startedAt = new Date().toISOString();
    previousCpu = readCpuTimes();
    collect();
    timer = setInterval(collect, 2000);
    timer.unref();
    probeRoutes();
    routeProbeTimer = setInterval(probeRoutes, 30_000);
    routeProbeTimer.unref();
  }

  function stop() {
    clearInterval(timer);
    clearInterval(routeProbeTimer);
    timer = null;
    routeProbeTimer = null;
    history = [];
    startedAt = null;
    cachedSnapshot = buildSnapshot(false, Date.now());
    serializedSnapshot = JSON.stringify(cachedSnapshot);
    persist(serializedSnapshot);
  }

  function collect() {
    if (subscribers.size === 0) return;
    const now = Date.now();
    const currentCpu = readCpuTimes();
    const totalDelta = currentCpu.total - previousCpu.total;
    const idleDelta = currentCpu.idle - previousCpu.idle;
    const cpuPercent =
      totalDelta > 0
        ? Math.max(
            0,
            Math.min(
              100,
              ((totalDelta - idleDelta) / totalDelta) * 100,
            ),
          )
        : 0;
    previousCpu = currentCpu;
    const currentRequests = requestStats(now);
    history.push({
      at: new Date(now).toISOString(),
      cpuPercent: round(cpuPercent),
      ramPercent: round(
        ((os.totalmem() - os.freemem()) / os.totalmem()) * 100,
      ),
      requestsPerMinute: currentRequests.perMinute,
      requestsPerMinuteByDomain: Object.fromEntries(
        currentRequests.byDomain.map((domain) => [
          domain.domain,
          domain.perMinute,
        ]),
      ),
    });
    if (history.length > 150) history = history.slice(-150);

    cachedSnapshot = buildSnapshot(true, now);
    serializedSnapshot = JSON.stringify(cachedSnapshot);
    persist(serializedSnapshot);
    for (const listener of subscribers) listener(serializedSnapshot);
  }

  function buildSnapshot(active, now) {
    const memory = process.memoryUsage();
    return {
      active,
      viewers: subscribers.size,
      startedAt,
      serverTime: new Date(now).toISOString(),
      uptimeSeconds: Math.floor(process.uptime()),
      cpu: {
        cores: os.cpus().length,
        model: os.cpus()[0]?.model || "Unknown",
        loadAverage: os.loadavg().map(round),
        percent: history.at(-1)?.cpuPercent ?? 0,
      },
      ram: {
        totalBytes: os.totalmem(),
        usedBytes: os.totalmem() - os.freemem(),
        freeBytes: os.freemem(),
        percent: history.at(-1)?.ramPercent ?? 0,
        processRssBytes: memory.rss,
      },
      service: serviceSnapshot(now),
      requests: requestStats(now),
      history: active ? history : [],
    };
  }

  function requestStats(now) {
    pruneRequests(now);
    const aggregate = calculateRequestStats(requests, now);
    const domains = [...new Set(requests.map((request) => request.host))]
      .sort()
      .map((domain) => ({
        domain,
        totalSinceStart: domainRequestTotals.get(domain) || 0,
        ...calculateRequestStats(
          requests.filter((request) => request.host === domain),
          now,
        ),
      }));
    return {
      ...aggregate,
      byDomain: domains,
      totalSinceStart: totalRequests,
      webSocketUpgradesSinceStart: totalWebSocketUpgrades,
      lastRequestAt,
    };
  }

  function calculateRequestStats(source, now) {
    const lastMinute = source.filter(
      (request) => request.at >= now - 60_000,
    );
    const durationTotal = source.reduce(
      (total, request) => total + request.durationMs,
      0,
    );
    return {
      perMinute: lastMinute.length,
      trackedFiveMinutes: source.length,
      averageResponseMs:
        source.length > 0
          ? round(durationTotal / source.length)
          : 0,
      errorsFiveMinutes: source.filter(
        (request) => request.statusCode >= 400,
      ).length,
    };
  }

  function serviceSnapshot(now) {
    const publicDomain = String(service.publicDomain || "").toLowerCase();
    const lastSeen = publicDomain
      ? domainActivity.get(publicDomain) || null
      : null;
    return {
      status: "online",
      publicDomain: publicDomain || null,
      domainStatus:
        lastSeen && now - lastSeen <= 5 * 60_000
          ? "online"
          : "unverified",
      domainLastSeenAt:
        lastSeen ? new Date(lastSeen).toISOString() : null,
      bindHost: service.bindHost || null,
      internalPort: service.internalPort || null,
      publicPort: service.publicPort || null,
      apiPrefix: service.apiPrefix || null,
      transports: ["HTTP", "WebSocket", "WISP"],
      routes: (service.routes || []).map((route) => ({
        id: route.id,
        label: route.label,
        url: route.url,
        purpose: route.purpose,
        used: Boolean(route.used),
        expectedStatuses: route.expectedStatuses,
        ...routeResults.get(route.id),
      })),
    };
  }

  async function probeRoutes() {
    if (
      routeProbeRunning ||
      subscribers.size === 0 ||
      !service.routes?.length
    ) {
      return;
    }
    routeProbeRunning = true;
    await Promise.all(service.routes.map(probeRoute));
    routeProbeRunning = false;
    if (subscribers.size === 0) return;
    const now = Date.now();
    cachedSnapshot = buildSnapshot(true, now);
    serializedSnapshot = JSON.stringify(cachedSnapshot);
    persist(serializedSnapshot);
    for (const listener of subscribers) listener(serializedSnapshot);
  }

  async function probeRoute(route) {
    try {
      const result = await probeHttpPhases(route.url);
      const expected = route.expectedStatuses.includes(result.statusCode);
      routeResults.set(route.id, {
        status: expected ? "online" : "unexpected",
        statusCode: result.statusCode,
        latencyMs: result.timings.totalMs,
        timings: result.timings,
        checkedAt: new Date().toISOString(),
      });
    } catch (error) {
      routeResults.set(route.id, {
        status: "offline",
        statusCode: null,
        latencyMs: error.timings?.totalMs ?? null,
        timings: error.timings || null,
        checkedAt: new Date().toISOString(),
        error:
          error?.code === "ENOTFOUND" ||
          error?.cause?.code === "ENOTFOUND"
            ? "dns_not_found"
            : error?.name === "TimeoutError"
              ? "timeout"
              : "connection_failed",
      });
    }
  }

  function pruneRequests(now) {
    requests = requests.filter(
      (request) => request.at >= now - 5 * 60_000,
    );
  }

  function persist(serialized) {
    if (!snapshotFile) return;
    persistQueue = persistQueue
      .then(async () => {
        await mkdir(dirname(snapshotFile), { recursive: true });
        const temporaryFile = `${snapshotFile}.tmp`;
        await writeFile(temporaryFile, `${serialized}\n`, "utf8");
        await rename(temporaryFile, snapshotFile);
      })
      .catch((error) => {
        console.error("Could not write monitoring snapshot:", error);
      });
  }
}

export function probeHttpPhases(url, { timeoutMs = 5_000 } = {}) {
  return new Promise((resolve, reject) => {
    const target = new URL(url);
    const transport = target.protocol === "https:" ? https : http;
    const startedAt = performance.now();
    const marks = {
      dnsAt: null,
      connectAt: null,
      secureAt: null,
      responseAt: null,
    };
    let settled = false;

    const timings = () => {
      const now = marks.responseAt ?? performance.now();
      const dnsEnd = marks.dnsAt ?? startedAt;
      const connectEnd = marks.connectAt ?? dnsEnd;
      const secureEnd =
        target.protocol === "https:"
          ? marks.secureAt ?? connectEnd
          : connectEnd;
      return {
        dnsMs: round(Math.max(0, dnsEnd - startedAt)),
        tcpMs: round(Math.max(0, connectEnd - dnsEnd)),
        tlsMs:
          target.protocol === "https:"
            ? round(Math.max(0, secureEnd - connectEnd))
            : 0,
        ttfbMs: round(Math.max(0, now - secureEnd)),
        totalMs: round(Math.max(0, now - startedAt)),
      };
    };

    const finishError = (error) => {
      if (settled) return;
      settled = true;
      error.timings = timings();
      reject(error);
    };

    const request = transport.request(target, {
      method: "GET",
      agent: false,
      headers: {
        "Cache-Control": "no-cache",
        "User-Agent": "OrganizeOn-Monitor/1.0",
      },
      lookup(hostname, options, callback) {
        dnsLookup(hostname, options, (error, address, family) => {
          marks.dnsAt = performance.now();
          callback(error, address, family);
        });
      },
    });

    request.once("socket", (socket) => {
      socket.once("connect", () => {
        marks.connectAt = performance.now();
      });
      socket.once("secureConnect", () => {
        marks.secureAt = performance.now();
      });
    });
    request.once("response", (response) => {
      if (settled) return;
      settled = true;
      marks.responseAt = performance.now();
      const result = {
        statusCode: response.statusCode || 0,
        timings: timings(),
      };
      response.destroy();
      resolve(result);
    });
    request.once("timeout", () => {
      const error = new Error("timeout");
      error.name = "TimeoutError";
      request.destroy(error);
    });
    request.once("error", finishError);
    request.setTimeout(timeoutMs);
    request.end();
  });
}

function readCpuTimes() {
  let idle = 0;
  let total = 0;
  for (const cpu of os.cpus()) {
    idle += cpu.times.idle;
    total += Object.values(cpu.times).reduce(
      (sum, value) => sum + value,
      0,
    );
  }
  return { idle, total };
}

function round(value) {
  return Number(value.toFixed(2));
}
