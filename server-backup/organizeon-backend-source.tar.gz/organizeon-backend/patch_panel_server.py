from pathlib import Path

p = Path('/data/data/com.termux/files/home/organizeon/backend/src/server.mjs')
s = p.read_text()
s = s.replace('import { createServiceControl } from "./service-control.mjs";\n', 'import { createServiceControl } from "./service-control.mjs";\nimport { createPanelFileStore } from "../panel-files.mjs";\n')
s = s.replace('const mediaMetadataDirectory = `${mediaUploadDirectory}/.metadata`;\n', 'const mediaMetadataDirectory = `${mediaUploadDirectory}/.metadata`;\nconst panelFileStore = createPanelFileStore({\n  dataDirectory: fileURLToPath(new URL("../data/panel-files", import.meta.url)),\n});\n')
s = s.replace('await mkdir(mediaMetadataDirectory, { recursive: true });\n', 'await mkdir(mediaMetadataDirectory, { recursive: true });\nawait panelFileStore.init();\n')
marker = '    if (\n      downloadPath === "/d1/chimera.zip" &&\n'
insert = '''    if (downloadPath === "/d2/login" &&
      (request.method === "GET" || request.method === "HEAD")) {
      return sendPanelDownload(request, response);
    }
'''
if insert not in s:
    s = s.replace(marker, insert + marker)
route_marker = '  if (requestUrl.pathname === `${apiPrefix}/media/upload`) {\n'
route = r'''  const filesRoute = `${apiPrefix}/files`;
  if (requestUrl.pathname === filesRoute) {
    const account = authenticate(request, requestUrl);
    if (!account) return sendJson(response, 401, { error: "authentication_required" });
    if (request.method === "GET") {
      return sendJson(response, 200, { files: await panelFileStore.list(account) });
    }
    if (request.method === "POST") {
      try {
        const rawName = request.headers["x-file-name"];
        const name = rawName ? decodeURIComponent(String(rawName)) : "arquivo";
        const file = await panelFileStore.create(account, name, request.headers["content-type"], request);
        return sendJson(response, 201, { file });
      } catch (error) {
        return sendJson(response, error.statusCode || 400, { error: error.message || "upload_failed" });
      }
    }
    return sendJson(response, 405, { error: "method_not_allowed" });
  }

  if (requestUrl.pathname.startsWith(`${filesRoute}/`)) {
    const account = authenticate(request, requestUrl);
    if (!account) return sendJson(response, 401, { error: "authentication_required" });
    const relative = requestUrl.pathname.slice(filesRoute.length + 1);
    const contentSuffix = "/content";
    const isContent = relative.endsWith(contentSuffix);
    const id = isContent ? relative.slice(0, -contentSuffix.length) : relative;
    if (!/^[a-f0-9]{32}$/.test(id)) return sendJson(response, 404, { error: "file_not_found" });
    try {
      if (isContent && (request.method === "GET" || request.method === "HEAD")) {
        const item = await panelFileStore.content(account, id);
        if (!item) return sendJson(response, 404, { error: "file_not_found" });
        response.writeHead(200, {
          "Content-Type": item.metadata.contentType || "application/octet-stream",
          "Content-Length": item.size,
          "Content-Disposition": `attachment; filename="${item.metadata.name.replace(/"/g, "")}"`,
        });
        if (request.method === "HEAD") return response.end();
        return createReadStream(item.path).pipe(response);
      }
      if (request.method === "GET") {
        const item = await panelFileStore.content(account, id);
        if (!item) return sendJson(response, 404, { error: "file_not_found" });
        const result = { file: { ...item.metadata, size: item.size } };
        if (item.metadata.contentType.startsWith("text/")) result.content = await readFile(item.path, "utf8");
        return sendJson(response, 200, result);
      }
      if (request.method === "PUT") {
        const file = await panelFileStore.update(account, id, request.headers["content-type"], request);
        return sendJson(response, 200, { file });
      }
      if (request.method === "DELETE") return sendJson(response, 200, await panelFileStore.remove(account, id));
      return sendJson(response, 405, { error: "method_not_allowed" });
    } catch (error) {
      return sendJson(response, error.statusCode || 400, { error: error.message || "file_operation_failed" });
    }
  }

'''
if route not in s:
    s = s.replace(route_marker, route + route_marker)
fn_marker = 'async function sendClientDownload(request, response) {\n'
fn = '''async function sendPanelDownload(request, response) {
  try {
    const panelPath = fileURLToPath(new URL("../d2-panel.html", import.meta.url));
    const file = await stat(panelPath);
    response.writeHead(200, { "Content-Type": "text/html; charset=UTF-8", "Content-Length": file.size, "Cache-Control": "no-cache" });
    if (request.method === "HEAD") return response.end();
    createReadStream(panelPath).pipe(response);
  } catch { sendJson(response, 404, { error: "panel_not_found" }); }
}

'''
if fn not in s:
    s = s.replace(fn_marker, fn + fn_marker)
p.write_text(s)
