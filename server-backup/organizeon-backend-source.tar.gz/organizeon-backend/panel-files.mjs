import { mkdir, readdir, readFile, stat, unlink, writeFile } from "node:fs/promises";
import { randomBytes } from "node:crypto";
import { basename, join } from "node:path";

const MAX_FILE_SIZE = 100 * 1024 * 1024;
const MAX_TEXT_SIZE = 20 * 1024 * 1024;
const NAME_PATTERN = /^[^\x00-\x1f\x7f\\/]{1,180}$/;

export function createPanelFileStore({ dataDirectory }) {
  const filesDirectory = join(dataDirectory, "files");
  const metadataDirectory = join(dataDirectory, "metadata");

  async function init() {
    await mkdir(filesDirectory, { recursive: true, mode: 0o700 });
    await mkdir(metadataDirectory, { recursive: true, mode: 0o700 });
  }

  function metadataPath(id) { return join(metadataDirectory, `${id}.json`); }
  function filePath(id) { return join(filesDirectory, id); }
  function cleanName(value) {
    const name = basename(String(value || "").trim());
    if (!NAME_PATTERN.test(name) || name === "." || name === "..") {
      const error = new Error("invalid_file_name"); error.statusCode = 400; throw error;
    }
    return name;
  }

  async function getOwned(account, id) {
    if (!/^[a-f0-9]{32}$/.test(id)) return null;
    try {
      const metadata = JSON.parse(await readFile(metadataPath(id), "utf8"));
      return metadata.owner === account.username ? metadata : null;
    } catch { return null; }
  }

  async function list(account) {
    const entries = await readdir(metadataDirectory, { withFileTypes: true }).catch(() => []);
    const result = [];
    for (const entry of entries) {
      if (!entry.isFile() || !entry.name.endsWith(".json")) continue;
      try {
        const metadata = JSON.parse(await readFile(join(metadataDirectory, entry.name), "utf8"));
        if (metadata.owner !== account.username) continue;
        const info = await stat(filePath(metadata.id)).catch(() => null);
        if (!info) continue;
        result.push({ ...metadata, size: info.size });
      } catch { /* ignore malformed metadata */ }
    }
    return result.sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)));
  }

  async function create(account, name, contentType, request) {
    const safeName = cleanName(name);
    const declaredSize = Number(request.headers["content-length"]);
    if (!Number.isInteger(declaredSize) || declaredSize < 0 || declaredSize > MAX_FILE_SIZE) {
      const error = new Error("file_too_large_or_length_required"); error.statusCode = 413; throw error;
    }
    const id = randomBytes(16).toString("hex");
    const destination = filePath(id);
    const chunks = [];
    let received = 0;
    for await (const chunk of request) {
      received += chunk.length;
      if (received > MAX_FILE_SIZE) { const error = new Error("file_too_large"); error.statusCode = 413; throw error; }
      chunks.push(chunk);
    }
    if (received !== declaredSize) { const error = new Error("content_length_mismatch"); error.statusCode = 400; throw error; }
    await writeFile(destination, Buffer.concat(chunks), { flag: "wx", mode: 0o600 });
    const metadata = {
      id, owner: account.username, name: safeName,
      contentType: String(contentType || "application/octet-stream").split(";", 1)[0],
      createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
    };
    await writeFile(metadataPath(id), JSON.stringify(metadata), { flag: "wx", mode: 0o600 });
    return { ...metadata, size: received };
  }

  async function update(account, id, contentType, request) {
    const metadata = await getOwned(account, id);
    if (!metadata) { const error = new Error("file_not_found"); error.statusCode = 404; throw error; }
    if (!String(contentType).toLowerCase().startsWith("text/")) { const error = new Error("only_text_files_editable"); error.statusCode = 415; throw error; }
    const declaredSize = Number(request.headers["content-length"]);
    if (!Number.isInteger(declaredSize) || declaredSize > MAX_TEXT_SIZE) { const error = new Error("text_too_large"); error.statusCode = 413; throw error; }
    const chunks = []; let received = 0;
    for await (const chunk of request) { received += chunk.length; if (received > MAX_TEXT_SIZE) { const error = new Error("text_too_large"); error.statusCode = 413; throw error; } chunks.push(chunk); }
    if (received !== declaredSize) { const error = new Error("content_length_mismatch"); error.statusCode = 400; throw error; }
    await writeFile(filePath(id), Buffer.concat(chunks), { mode: 0o600 });
    metadata.updatedAt = new Date().toISOString();
    metadata.contentType = "text/plain; charset=utf-8";
    await writeFile(metadataPath(id), JSON.stringify(metadata), { mode: 0o600 });
    return { ...metadata, size: received };
  }

  async function remove(account, id) {
    const metadata = await getOwned(account, id);
    if (!metadata) { const error = new Error("file_not_found"); error.statusCode = 404; throw error; }
    await unlink(filePath(id)).catch(() => {});
    await unlink(metadataPath(id)).catch(() => {});
    return { ok: true };
  }

  async function publicByName(name) {
    const wanted = basename(String(name || "").trim());
    if (!wanted || wanted === "." || wanted === "..") return null;
    const entries = await readdir(metadataDirectory, { withFileTypes: true }).catch(() => []);
    const matches = [];
    for (const entry of entries) { if (!entry.isFile() || !entry.name.endsWith(".json")) continue; try { const metadata = JSON.parse(await readFile(join(metadataDirectory, entry.name), "utf8")); if (metadata.name !== wanted) continue; const item = await stat(filePath(metadata.id)).catch(() => null); if (item) matches.push({ metadata, path: filePath(metadata.id), size: item.size }); } catch {} }
    return matches.length === 1 ? matches[0] : null;
  }

  async function publicContent(id) {
    if (!/^[a-f0-9]{32}$/.test(id)) return null;
    try {
      const metadata = JSON.parse(await readFile(metadataPath(id), "utf8"));
      const info = await stat(filePath(id));
      return { metadata, path: filePath(id), size: info.size };
    } catch { return null; }
  }

  async function content(account, id) {
    const metadata = await getOwned(account, id);
    if (!metadata) return null;
    const info = await stat(filePath(id)).catch(() => null);
    if (!info) return null;
    return { metadata, path: filePath(id), size: info.size };
  }

  return { init, list, create, update, remove, content, publicContent, publicByName };
}
