from pathlib import Path
p = Path('src/server.mjs')
s = p.read_text()
marker = '  if (requestUrl.pathname.startsWith(`${filesRoute}/`)) {\n    const account = authenticate(request, requestUrl);'
prefix = '''  if (requestUrl.pathname.startsWith(`${filesRoute}/`)) {
    const publicRelative = requestUrl.pathname.slice(filesRoute.length + 1);
    const rawSuffix = "/raw/content";
    const publicId = publicRelative.endsWith(rawSuffix) ? publicRelative.slice(0, -rawSuffix.length) : publicRelative;
    if (publicRelative.endsWith(rawSuffix) && /^[a-f0-9]{32}$/.test(publicId) && (request.method === "GET" || request.method === "HEAD")) {
      const item = await panelFileStore.publicContent(publicId);
      if (!item) return sendJson(response, 404, { error: "file_not_found" });
      response.writeHead(200, { "Content-Type": item.metadata.contentType || "application/octet-stream", "Content-Length": item.size, "Cache-Control": "public, max-age=300", "Content-Disposition": `inline; filename="${item.metadata.name.replace(/"/g, "")}"` });
      if (request.method === "HEAD") return response.end();
      return createReadStream(item.path).pipe(response);
    }
'''
if 'panelFileStore.publicContent(id)' not in s:
    s = s.replace(marker, prefix + '    const account = authenticate(request, requestUrl);')
old = '''    const contentSuffix = "/content";
    const isContent = relative.endsWith(contentSuffix);
    const id = isContent ? relative.slice(0, -contentSuffix.length) : relative;'''
new = '''    const rawSuffix = "/raw/content";
    const contentSuffix = "/content";
    const isRawContent = relative.endsWith(rawSuffix);
    const isContent = isRawContent || relative.endsWith(contentSuffix);
    const id = isRawContent
      ? relative.slice(0, -rawSuffix.length)
      : isContent
        ? relative.slice(0, -contentSuffix.length)
        : relative;'''
if 'const rawSuffix = "/raw/content"' not in s:
    s = s.replace(old, new)
p.write_text(s)
