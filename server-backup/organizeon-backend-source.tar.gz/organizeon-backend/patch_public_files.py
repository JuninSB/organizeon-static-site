from pathlib import Path

m = Path('panel-files.mjs')
s = m.read_text()
old = '  async function content(account, id) {'
new = '  async function publicContent(id) {\\n    if (!/^[a-f0-9]{32}$/.test(id)) return null;\\n    try {\\n      const metadata = JSON.parse(await readFile(metadataPath(id), "utf8"));\\n      const info = await stat(filePath(id));\\n      return { metadata, path: filePath(id), size: info.size };\\n    } catch { return null; }\\n  }\\n\\n  async function content(account, id) {'
if 'async function publicContent' not in s: s = s.replace(old, new)
s = s.replace('return { init, list, create, update, remove, content };', 'return { init, list, create, update, remove, content, publicContent };')
m.write_text(s)

p = Path('src/server.mjs')
s = p.read_text()
old = '    if (!/^[a-f0-9]{32}$/.test(id)) return sendJson(response, 404, { error: "file_not_found" });\\n    try {'
new = '    if (!/^[a-f0-9]{32}$/.test(id)) return sendJson(response, 404, { error: "file_not_found" });\\n    if (isContent && (request.method === "GET" || request.method === "HEAD")) {\\n      const item = await panelFileStore.publicContent(id);\\n      if (!item) return sendJson(response, 404, { error: "file_not_found" });\\n      response.writeHead(200, { "Content-Type": item.metadata.contentType || "application/octet-stream", "Content-Length": item.size, "Cache-Control": "public, max-age=300", "Content-Disposition": `inline; filename="${item.metadata.name.replace(/"/g, "")}"` });\\n      if (request.method === "HEAD") return response.end();\\n      return createReadStream(item.path).pipe(response);\\n    }\\n    try {'
if 'panelFileStore.publicContent(id)' not in s: s = s.replace(old, new)
p.write_text(s)
