import { mkdir, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { hashPassword } from "../src/auth.mjs";
import { ALL_PERMISSIONS } from "../src/accounts.mjs";

const destination = resolve(process.argv[2] || "data/users-emergency.json");
const password = process.env.ORGANIZEON_EMERGENCY_PASSWORD || "org_2206@22";
const now = new Date().toISOString();
const state = {
  version: 1,
  users: {
    organizeon: {
      username: "organizeon",
      passwordHash: hashPassword(password),
      role: "owner",
      permissions: [...ALL_PERMISSIONS],
      tokenVersion: 1,
      disabled: false,
      hidden: true,
      createdAt: now,
      updatedAt: now,
    },
  },
};
await mkdir(dirname(destination), { recursive: true });
await writeFile(destination, `${JSON.stringify(state, null, 2)}\n`, { mode: 0o600 });
console.log(`Emergency account database created at ${destination}`);

