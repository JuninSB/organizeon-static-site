#!/data/data/com.termux/files/usr/bin/sh
set -eu
BACKEND_DIR="${ORGANIZEON_BACKEND_DIR:-$HOME/organizeon/backend}"
ACTIVE_FILE="$BACKEND_DIR/data/accounts-file.active"
USERS="$BACKEND_DIR/data/users.json"
EMERGENCY="$BACKEND_DIR/data/users-emergency.json"
valid_users() {
  node -e 'const fs=require("fs");const x=JSON.parse(fs.readFileSync(process.argv[1],"utf8"));if(x?.version!==1||!x.users||typeof x.users!=="object")process.exit(1)' "$1" >/dev/null 2>&1
}
if [ -s "$ACTIVE_FILE" ] && valid_users "$(sed -n '1p' "$ACTIVE_FILE")"; then
  ACCOUNTS_FILE="$(sed -n '1p' "$ACTIVE_FILE")"
elif valid_users "$USERS"; then
  ACCOUNTS_FILE="$USERS"
elif valid_users "$EMERGENCY"; then
  ACCOUNTS_FILE="$EMERGENCY"
  printf '%s\n' "AVISO: users.json inválido; usando users-emergency.json" >&2
else
  printf '%s\n' "ERRO: users.json e users-emergency.json estão ausentes ou corrompidos" >&2
  exit 1
fi
export ACCOUNTS_FILE
cd "$BACKEND_DIR"
exec node \
  --env-file=.env \
  --env-file="$HOME/organizeon/secrets/backend-extra.env" \
  src/server.mjs >> server.log 2>&1
