import { randomBytes, scryptSync } from "node:crypto";

const password = process.argv[2];

if (!password || password.length < 12) {
  console.error(
    "Uso: npm run hash-password -- 'uma-senha-forte-com-12-ou-mais-caracteres'",
  );
  process.exitCode = 1;
} else {
  const salt = randomBytes(16);
  const cost = 16384;
  const blockSize = 8;
  const parallelization = 1;
  const hash = scryptSync(password, salt, 32, {
    N: cost,
    r: blockSize,
    p: parallelization,
  });

  console.log(
    `scrypt$${cost}$${blockSize}$${parallelization}$${salt.toString("base64url")}$${hash.toString("base64url")}`,
  );
}
