import { readFile, rename, writeFile } from "node:fs/promises";

const [currentPath, fallbackPath] = process.argv.slice(2);
if (!currentPath || !fallbackPath) {
  throw new Error("usage: node repair-truncated-users.mjs users.json fallback.json");
}
const damaged = await readFile(currentPath, "utf8");
try {
  JSON.parse(damaged);
  console.log("users.json is already valid; no repair needed");
  process.exit(0);
} catch {}
if (!/"user"\s*:\s*\{[\s\S]*"permissions"\s*:\s*\[[\s\S]*\],\s*$/.test(damaged)) {
  throw new Error("refusing repair: truncation does not match the known final user record");
}
const fallback = JSON.parse(await readFile(fallbackPath, "utf8"));
const prior = fallback.users?.user || {};
const now = new Date().toISOString();
const fields = {
  tokenVersion: Number.isInteger(prior.tokenVersion) ? prior.tokenVersion : 1,
  disabled: prior.disabled === true,
  hidden: false,
  createdAt: prior.createdAt || now,
  updatedAt: prior.updatedAt || now,
};
const tail = Object.entries(fields).map(([key, value]) =>
  `      ${JSON.stringify(key)}: ${JSON.stringify(value)}`
).join(",\n");
const repaired = `${damaged}${tail}\n    }\n  }\n}\n`;
const parsed = JSON.parse(repaired);
if (parsed.version !== 1 || !parsed.users?.organizeon || !parsed.users?.user) {
  throw new Error("repaired database failed schema checks");
}
const temporary = `${currentPath}.repairing`;
await writeFile(temporary, repaired, { mode: 0o600 });
await rename(temporary, currentPath);
console.log(`Repaired ${Object.keys(parsed.users).length} user records`);
