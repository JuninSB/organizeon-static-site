import assert from "node:assert/strict";

const base = process.argv[2] || "http://127.0.0.1:5000/827e7h3heuw823eh";
const username = `flow_test_${Date.now().toString(36)}`;
const origin = "https://organizeon.com.br";
const registration = await fetch(`${base}/auth/register`, {
  method: "POST",
  headers: { "Content-Type": "application/json", Origin: origin },
  body: JSON.stringify({ username, password: "temporary-test-123" }),
});
assert.equal(registration.status, 201);
const session = await registration.json();
assert.deepEqual(session.account.permissions, []);
const headers = { Authorization: `Bearer ${session.token}`, Origin: origin };
let response = await fetch(`${base}/account/backup`, { headers });
assert.equal(response.status, 200);
assert.equal((await response.json()).enabled, false);
response = await fetch(`${base}/account/backup`, {
  method: "PATCH",
  headers: { ...headers, "Content-Type": "application/json" },
  body: JSON.stringify({ enabled: true }),
});
assert.equal(response.status, 200);
const payload = JSON.stringify({
  version: 1,
  preferences: { theme: "dark" },
  gameProgress: { tetris: { score: 800 } },
  indexedDB: [],
});
response = await fetch(`${base}/account/backup`, {
  method: "PUT",
  headers: { ...headers, "Content-Type": "application/json" },
  body: payload,
});
assert.equal(response.status, 200);
response = await fetch(`${base}/account/backup/data`, { headers });
assert.equal(response.status, 200);
assert.deepEqual(await response.json(), JSON.parse(payload));
response = await fetch(`${base}/account/backup`, { method: "DELETE", headers });
assert.equal(response.status, 200);
assert.equal((await response.json()).size, 0);
console.log(JSON.stringify({ ok: true, username }));
