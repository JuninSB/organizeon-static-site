import { readFile, rename, unlink, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";

const [fileArgument, username] = process.argv.slice(2);
if (!fileArgument || !/^flow_test_[a-z0-9]+$/.test(username || "")) {
  throw new Error("refusing cleanup: expected users.json and a flow_test_* username");
}
const file = resolve(fileArgument);
const state = JSON.parse(await readFile(file, "utf8"));
if (!state.users?.[username]) throw new Error("test account was not found");
delete state.users[username];
const temporary = `${file}.cleanup`;
await writeFile(temporary, `${JSON.stringify(state, null, 2)}\n`, { mode: 0o600 });
await rename(temporary, file);
const cloudDirectory = join(dirname(file), "cloud-backups");
await Promise.all([
  unlink(join(cloudDirectory, "settings", `${username}.json`)).catch(() => {}),
  unlink(join(cloudDirectory, "data", `${username}.json`)).catch(() => {}),
]);
console.log(`Removed temporary account ${username}`);
