#!/usr/bin/env sh
set -eu

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
project_root=$(CDPATH= cd -- "$script_dir/../.." && pwd)
downloads_dir="$project_root/backend/downloads"
archive="$downloads_dir/organizeon-client.zip"

mkdir -p "$downloads_dir"
temporary_archive=$(mktemp "$downloads_dir/.organizeon-client.XXXXXX.zip")

bsdtar -a -cf "$temporary_archive" -C "$project_root" site
mv "$temporary_archive" "$archive"
chmod 0644 "$archive"

printf 'Cliente criado: %s\n' "$archive"
