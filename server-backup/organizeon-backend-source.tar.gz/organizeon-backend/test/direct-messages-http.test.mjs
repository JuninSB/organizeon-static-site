import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {mkdtempSync,rmSync,statSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createDirectMessagesStore} from '../src/direct-messages/store.mjs';
import {createDirectMessagesHandler} from '../src/direct-messages/http.mjs';
const account=username=>['alice','bob','carol'].includes(username)?{username,role:'user',profile:{displayName:username,nameColor:'#FAFAFA',bio:'',avatarShape:'circle',avatar:'data:image/jpeg;base64,'+'A'.repeat(65536)}}:null;
test('HTTP authentication, origin checks, private ACLs and persistence across restart',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'organizeon-dm-'));const filePath=join(dir,'dm.sqlite');
 let store=createDirectMessagesStore({filePath,resolveAccount:account});
 const handler=createDirectMessagesHandler({store,authenticate:req=>account((req.headers.authorization||'').replace('Bearer ','')),originAllowed:req=>req.headers.origin==='https://fixture.local',readJson:async req=>{let body='';for await(const chunk of req)body+=chunk;return JSON.parse(body||'{}');},sendJson:(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json'});res.end(JSON.stringify(data));}});
 const server=createServer((req,res)=>handler(req,res,new URL(req.url,'http://localhost'),'/dm'));
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const base='http://127.0.0.1:'+server.address().port;
 const request=async(who,path,method='GET',body,origin='https://fixture.local')=>{const r=await fetch(base+'/dm'+path,{method,headers:{Authorization:'Bearer '+who,Origin:origin,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});return {status:r.status,data:await r.json()};};
 try{
 assert.equal((await request('nobody','/inbox')).status,401);
 const full=await request('alice','/inbox?compact=1');const delta=await request('alice','/inbox?compact=1&version='+full.data.version);assert.equal(delta.data.unchanged,true);assert.ok(JSON.stringify(delta.data).length<JSON.stringify(full.data).length*.05);console.log('INBOX_BYTES',JSON.stringify(full.data).length,JSON.stringify(delta.data).length);
 
 assert.equal((await request('alice','/requests','POST',{username:'bob'},'https://bad.local')).status,403);
 const c=await request('alice','/requests','POST',{username:'bob'});assert.equal(c.status,200);const id=c.data.id;
 assert.equal((await request('alice',`/conversations/${id}/messages`,'POST',{content:'premature',nonce:crypto.randomUUID()})).status,409);
 assert.equal((await request('bob',`/conversations/${id}/request`,'POST',{action:'accept'})).status,200);
 const sent=await request('alice',`/conversations/${id}/messages`,'POST',{content:'fixture only',nonce:crypto.randomUUID()});assert.equal(sent.status,200);
 const page=await request('bob',`/conversations/${id}/messages?compact=1`);const thin=await request('bob',`/conversations/${id}/messages?compact=1&conversationVersion=${page.data.conversationVersion}`);assert.equal(thin.data.conversation,null);assert.equal(thin.data.messages[0].content,'fixture only');
 store.updateConversation('bob',id,{favorite:true,pinned:true});const meta=store.getInbox('bob').conversations[0];assert.equal(meta.favorite,true);assert.equal(meta.pinned,true);assert.equal(store.getInbox('alice').conversations[0].favorite,false);
 const changed=await request('alice','/inbox?compact=1&version='+full.data.version);assert.equal(changed.data.unchanged,undefined);
 const mid=sent.data.message.id;assert.equal((await request('bob',`/messages/${mid}`)).data.message.content,'fixture only');
 assert.equal((await request('carol',`/messages/${mid}`)).status,404);
 assert.equal((await request('bob',`/messages/${mid}`,'PATCH',{content:'forged'})).status,403);
 store.updateConversation('alice',id,{archived:true});assert.equal(store.createRequest('alice','bob').archived,false);
 store.close();store=createDirectMessagesStore({filePath,resolveAccount:account});assert.equal(store.getMessages('bob',id).messages[0].id,mid);assert.equal(statSync(filePath).mode&0o777,0o600);
 }finally{await new Promise(resolve=>server.close(resolve));store.close();rmSync(dir,{recursive:true,force:true});}
});
