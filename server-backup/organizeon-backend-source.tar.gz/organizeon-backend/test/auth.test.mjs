import assert from "node:assert/strict";
import test from "node:test";
import {
  createSessionToken,
  parseCookies,
  SESSION_TTL_SECONDS,
  verifyPassword,
  verifySessionToken,
} from "../src/auth.mjs";

const secret = "test-secret-with-at-least-32-characters";
const now = Date.UTC(2026, 6, 29);

test("session is valid before the 14-day expiration", () => {
  const token = createSessionToken("admin", secret, now);
  const claims = verifySessionToken(
    token,
    secret,
    now + (SESSION_TTL_SECONDS - 1) * 1000,
  );

  assert.equal(claims.sub, "admin");
});

test("session expires automatically after 14 days", () => {
  const token = createSessionToken("admin", secret, now);
  const claims = verifySessionToken(
    token,
    secret,
    now + SESSION_TTL_SECONDS * 1000,
  );

  assert.equal(claims, null);
});

test("modified tokens are rejected", () => {
  const token = createSessionToken("admin", secret, now);
  const modified = `${token.slice(0, -1)}x`;

  assert.equal(verifySessionToken(modified, secret, now), null);
});

test("password verification accepts only the correct password", () => {
  const encodedHash =
    "scrypt$16384$8$1$c2FsdC1mb3ItdGVzdHM$Q_c8g9fzfWIe5OBqxQ5S0Pp0DEJn7dZIdvupjN4nZ0Y";

  assert.equal(verifyPassword("correct horse battery staple", encodedHash), true);
  assert.equal(verifyPassword("wrong password", encodedHash), false);
});

test("cookie parser preserves signed token values", () => {
  const token = createSessionToken("admin", secret, now);
  const cookies = parseCookies(`theme=dark; organizeon_session=${token}`);

  assert.equal(cookies.get("organizeon_session"), token);
});
