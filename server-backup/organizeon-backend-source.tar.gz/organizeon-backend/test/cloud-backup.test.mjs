import assert from "node:assert/strict";
import { mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Readable } from "node:stream";
import test from "node:test";
import {
  CLOUD_BACKUP_LIMIT_BYTES,
  createCloudBackupStore,
} from "../src/cloud-backup.mjs";

const account = { username: "test_user" };

async function fixture() {
  const directory = await mkdtemp(join(tmpdir(), "organizeon-backup-"));
  const store = createCloudBackupStore({ directory });
  await store.init();
  return store;
}

function request(value, declared = Buffer.byteLength(value)) {
  const stream = Readable.from([value]);
  stream.headers = { "content-length": String(declared) };
  return stream;
}

test("cloud backup starts OFF and is isolated by account", async () => {
  const store = await fixture();
  assert.deepEqual(await store.status(account), {
    enabled: false,
    size: 0,
    limit: CLOUD_BACKUP_LIMIT_BYTES,
    updatedAt: null,
  });
  await store.setEnabled(account, true);
  await store.save(account, request('{"theme":"dark"}'));
  assert.equal((await store.open(account)).size, 16);
  assert.equal(await store.open({ username: "other_user" }).catch((error) => error.code), "cloud_backup_disabled");
});

test("backup refuses declarations above 500 MB before reading the body", async () => {
  const store = await fixture();
  await store.setEnabled(account, true);
  await assert.rejects(
    store.save(account, request("{}", CLOUD_BACKUP_LIMIT_BYTES + 1)),
    (error) => error.code === "backup_limit_exceeded" && error.statusCode === 413,
  );
});

test("backup validates JSON and exact content length", async () => {
  const store = await fixture();
  await store.setEnabled(account, true);
  await assert.rejects(store.save(account, request("not-json")));
  await assert.rejects(
    store.save(account, request("{}", 8)),
    (error) => error.code === "content_length_mismatch",
  );
});

