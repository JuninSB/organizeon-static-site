import assert from "node:assert/strict";
import test from "node:test";
import { createServiceControl } from "../src/service-control.mjs";

test("restart is authorized and dispatched to the configured service", async () => {
  const calls = [];
  const control = createServiceControl({
    definitions: [{
      id: "api",
      label: "API OrganizeOn",
      serviceName: "organizeon-backend",
      permission: "services.api.restart",
      actions: ["restart"],
    }],
    runner: async (...args) => calls.push(args),
  });
  const account = { permissions: ["services.api.restart"] };
  assert.equal((await control.execute(account, "api", "restart")).action, "restart");
  assert.deepEqual(calls, [["organizeon-backend", "restart"]]);
});

test("restart cannot be used without permission", async () => {
  const control = createServiceControl({
    definitions: [{ id: "api", label: "API", serviceName: "api", permission: "restart", actions: ["restart"] }],
    runner: async () => assert.fail("runner must not be called"),
  });
  await assert.rejects(
    control.execute({ permissions: [] }, "api", "restart"),
    (error) => error.code === "forbidden",
  );
});

