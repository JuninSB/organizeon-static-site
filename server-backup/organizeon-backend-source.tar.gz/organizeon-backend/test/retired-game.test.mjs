import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,writeFile,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createAccountStore,ALL_PERMISSIONS} from '../src/accounts.mjs';
import {createGameSession,verifyGameSession} from '../src/game-auth.mjs';

test('retired Suroi grants are removed on load without changing account credentials',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'retired-game-'));
 try {
  const filePath=join(dir,'accounts.json');
  const original={version:1,users:{tester:{username:'tester',role:'admin',passwordHash:'fixture-unchanged',permissions:['admin.dashboard','game.suroi.admin','game.survival.speed'],tokenVersion:7,disabled:false}}};
  await writeFile(filePath,JSON.stringify(original));
  const store=await createAccountStore({filePath});
  const account=store.get('tester');
  assert.deepEqual(account.permissions,['admin.dashboard','game.survival.speed']);
  assert.equal(account.tokenVersion,7);
  assert.equal(ALL_PERMISSIONS.some(p=>p.startsWith('game.suroi.')),false);
  assert.deepEqual(JSON.parse(await readFile(filePath,'utf8')),original);
 }finally{await rm(dir,{recursive:true,force:true});}
});

test('Survival sessions retain wire compatibility and exclude retired grants',()=>{
 const token=createGameSession({username:'tester',role:'admin',permissions:['game.suroi.admin','game.survival.speed']},'test-only-session-secret');
 const claims=verifyGameSession(token,'test-only-session-secret');
 assert.ok(claims);
 assert.equal(claims.aud,'organizeon-suroi');
 assert.deepEqual(claims.permissions,['game.survival.speed']);
 assert.equal(claims.tag,'');
});

test('service catalog and HTTP route no longer expose the retired game',async()=>{
 const server=await readFile(new URL('../src/server.mjs',import.meta.url),'utf8');
 assert.doesNotMatch(server,/id: "suroi"|SUROI_PUBLIC_URL|games\/suroi\/session/);
 assert.match(server,/games\/survival\/session/);
});
