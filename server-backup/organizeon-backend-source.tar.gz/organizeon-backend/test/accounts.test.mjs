import assert from "node:assert/strict";
import { mkdtemp, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { createAccountStore, ALL_PERMISSIONS } from "../src/accounts.mjs";
import { hashPassword } from "../src/auth.mjs";

async function fixture() {
  const directory = await mkdtemp(join(tmpdir(), "organizeon-accounts-"));
  const store = await createAccountStore({
    filePath: join(directory, "users.json"),
    initialOwnerUsername: "organizeon",
    initialOwnerPasswordHash: hashPassword("org_2206@22"),
  });
  return { directory, store };
}

test("self-registration creates a visible user with zero permissions", async () => {
  const { directory, store } = await fixture();
  const account = await store.register({ username: "new_user", password: "password-123" });
  assert.equal(account.role, "user");
  assert.deepEqual(account.permissions, []);
  const state = JSON.parse(await readFile(join(directory, "users.json"), "utf8"));
  assert.equal(state.users.new_user.hidden, false);
});

test("only the literal organizeon account is hidden", async () => {
  const { directory, store } = await fixture();
  const organizeon = store.authenticate("organizeon", "org_2206@22");
  await store.create(organizeon, {
    username: "another_owner",
    password: "password-123",
    role: "owner",
    permissions: [...ALL_PERMISSIONS],
  });
  const state = JSON.parse(await readFile(join(directory, "users.json"), "utf8"));
  assert.equal(state.users.organizeon.hidden, true);
  assert.equal(state.users.another_owner.hidden, false);
  assert.deepEqual(store.list(organizeon).map((user) => user.username), ["another_owner"]);
});

test("organizeon can only be modified while logged in as organizeon", async () => {
  const { store } = await fixture();
  const organizeon = store.authenticate("organizeon", "org_2206@22");
  const peer = await store.create(organizeon, {
    username: "another_owner",
    password: "password-123",
    role: "owner",
    permissions: [...ALL_PERMISSIONS],
  });
  await assert.rejects(
    store.update(peer, "organizeon", { password: "changed-123" }),
    (error) => error.code === "system_account_required",
  );
  await store.update(organizeon, "organizeon", { password: "changed-123" });
  assert.ok(store.authenticate("organizeon", "changed-123"));
});

test("login code follows rank rather than requiring owner", async () => {
  const { store } = await fixture();
  const organizeon = store.authenticate("organizeon", "org_2206@22");
  const first = await store.create(organizeon, {
    username: "admin_one",
    password: "password-123",
    role: "admin",
  });
  await store.create(organizeon, {
    username: "admin_two",
    password: "password-123",
    role: "admin",
  });
  const result = await store.createLoginCode(first, "admin_two");
  assert.match(result.code, /^[A-Z0-9]{6}$/);
  assert.equal((await store.authenticateLoginCode(result.code)).username, "admin_two");
});

