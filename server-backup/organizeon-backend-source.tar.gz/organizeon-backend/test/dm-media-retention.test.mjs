import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {DatabaseSync} from 'node:sqlite';
import {createDirectMessagesStore} from '../src/direct-messages/store.mjs';
import {MB, DM_FILE_LIMIT, DM_UPLOAD_BODY_LIMIT, mediaExpiresAt} from '../src/direct-messages/media-policy.mjs';
const nonce=()=>crypto.randomUUID();
function fixture(filePath=':memory:',start=Date.UTC(2026,7,31,12,3,2)) {
 let time=start;const users=new Map(['alice','bob','carol'].map(username=>[username,{username,role:'user'}]));
 const store=createDirectMessagesStore({filePath,resolveAccount:u=>users.get(u),now:()=>time});
 return {store,advance:ms=>time+=ms};
}
function accepted(s,a,b){const c=s.createRequest(a,b);s.respond(b,c.id,'accept');return c.id;}
test('size thresholds are contiguous and use calendar months with UTC month-end clamping',()=>{
 const start=Date.UTC(2026,7,31,12,3,2), six=Date.UTC(2027,1,28,12,3,2),three=Date.UTC(2026,10,30,12,3,2);
 for(const [size,expected] of [[1,null],[8*MB-1,null],[8*MB,six],[16*MB,six],[16*MB+1,three],[28*MB,three],[28*MB+1,start+15*86400000],[40*MB,start+15*86400000],[40*MB+1,start+7*86400000],[50*MB,start+7*86400000]])assert.equal(mediaExpiresAt(size,start),expected);
 assert.equal(DM_FILE_LIMIT,50*MB);assert.ok(DM_UPLOAD_BODY_LIMIT>Math.ceil(DM_FILE_LIMIT/3)*4);
 assert.equal(mediaExpiresAt(8*MB,Date.UTC(2023,7,31)),Date.UTC(2024,1,29));
});
test('50 MB upload survives forwarding without renewed expiry, is blocked at expiry and purged from all copies',()=>{
 const {store:s,advance}=fixture();try{
 const id=accepted(s,'alice','bob'),other=accepted(s,'alice','carol');
 const a=s.upload('alice',id,{name:'large.bin',mime:'application/octet-stream',data:Buffer.alloc(50*MB,7).toString('base64')});
 assert.equal(a.size,DM_FILE_LIMIT);assert.ok(a.expiresAt);
 const msg=s.send('alice',id,{content:'keep text',attachmentIds:[a.id],nonce:nonce()});advance(86400000);
 const f=s.send('alice',other,{forwardId:msg.id,nonce:nonce()});assert.equal(f.attachments[0].expiresAt,a.expiresAt);
 advance(6*86400000-1);assert.equal(s.download('bob',a.id).size,50*MB);advance(1);
 assert.throws(()=>s.download('bob',a.id),e=>e.statusCode===410);assert.equal(s.getMessage('bob',msg.id).attachments[0].expired,true);
 assert.throws(()=>s.send('alice',other,{forwardId:msg.id,nonce:nonce()}),e=>e.code==='dm_attachment_expired');
 const cursor=s.getInbox('carol').cursor;assert.deepEqual(s.expireMedia(),{blobs:1,bytes:50*MB});assert.deepEqual(s.expireMedia(),{blobs:0,bytes:0});
 assert.equal(s.getMessage('bob',msg.id).content,'keep text');assert.equal(s.getMessage('carol',f.id).attachments[0].expired,true);assert.ok(s.getInbox('carol',cursor).events.some(e=>e.kind==='changed'&&e.messageId===f.id));
 assert.throws(()=>s.download('carol',a.id),e=>e.statusCode===404);
 }finally{s.close();}
});
test('small media persists until last message reference is manually deleted',()=>{
 const {store:s,advance}=fixture();try{const id=accepted(s,'alice','bob'),a=s.upload('alice',id,{name:'small',mime:'text/plain',data:'aGVsbG8='});const m=s.send('alice',id,{content:'',attachmentIds:[a.id],nonce:nonce()});assert.equal(a.expiresAt,null);advance(10*366*86400000);assert.equal(s.expireMedia().blobs,0);assert.equal(s.download('bob',a.id).data,'aGVsbG8=');s.remove('alice',m.id);assert.throws(()=>s.download('bob',a.id),e=>e.statusCode===404);}finally{s.close();}
});
test('legacy database migrates using the original upload date and clears expired bytes on disk',()=>{
 const dir=mkdtempSync(join(tmpdir(),'dm-retention-')),path=join(dir,'dm.sqlite');
 try{
  const db=new DatabaseSync(path);db.exec(`CREATE TABLE dm_blobs(id TEXT PRIMARY KEY,owner TEXT NOT NULL,name TEXT NOT NULL,mime TEXT NOT NULL,size INTEGER NOT NULL,data BLOB NOT NULL);CREATE TABLE dm_attachments(id TEXT PRIMARY KEY,conversation_id TEXT NOT NULL,blob_id TEXT NOT NULL,uploader TEXT NOT NULL,message_id TEXT,created_at INTEGER NOT NULL);`);
  const created=Date.UTC(2026,0,1);db.prepare('INSERT INTO dm_blobs VALUES(?,?,?,?,?,?)').run('b','alice','legacy','application/octet-stream',41*MB,Buffer.from('old private bytes'));db.prepare('INSERT INTO dm_attachments VALUES(?,?,?,?,?,?)').run('a','c','b','alice',null,created);db.close();
  const {store:s}=fixture(path,created+8*86400000);assert.equal(s.expireMedia().blobs,1);s.close();const check=new DatabaseSync(path);const row=check.prepare('SELECT created_at,expires_at,expired_at,length(data) AS bytes FROM dm_blobs').get();assert.equal(row.created_at,created);assert.equal(row.expires_at,created+7*86400000);assert.ok(row.expired_at);assert.equal(row.bytes,0);check.close();
 }finally{rmSync(dir,{recursive:true});}
});
test('hash dedup shares bytes across users, preserves names and renews all references only on upload',()=>{
 const dir=mkdtempSync(join(tmpdir(),'dm-dedup-')),path=join(dir,'dm.sqlite');const {store:s,advance}=fixture(path);
 try{
  const id=accepted(s,'alice','bob'),other=accepted(s,'bob','carol');const data=Buffer.alloc(8*MB,3).toString('base64');
  const a=s.upload('alice',id,{name:'first.bin',mime:'application/octet-stream',data});const first=s.send('alice',id,{attachmentIds:[a.id],nonce:nonce()});
  advance(86400000);const b=s.upload('bob',other,{name:'renamed.bin',mime:'application/octet-stream',data});const second=s.send('bob',other,{attachmentIds:[b.id],nonce:nonce()});
  assert.notEqual(a.id,b.id);assert.notEqual(a.expiresAt,b.expiresAt);assert.equal(s.getMessage('alice',first.id).attachments[0].expiresAt,b.expiresAt);
  assert.equal(s.download('alice',a.id).name,'first.bin');assert.equal(s.download('carol',b.id).name,'renamed.bin');assert.throws(()=>s.download('carol',a.id),e=>e.statusCode===404);
  let db=new DatabaseSync(path);assert.equal(db.prepare('SELECT COUNT(*) AS n FROM dm_blobs').get().n,1);assert.equal(db.prepare('SELECT COUNT(DISTINCT blob_id) AS n FROM dm_attachments').get().n,1);db.close();
  advance(220*86400000);s.expireMedia();assert.equal(s.getMessage('alice',first.id).attachments[0].expired,true);
  s.upload('bob',other,{name:'again.bin',mime:'application/octet-stream',data});assert.equal(s.getMessage('alice',first.id).attachments[0].expired,false);assert.equal(s.getMessage('carol',second.id).attachments[0].expired,false);
  db=new DatabaseSync(path);assert.equal(db.prepare('SELECT COUNT(*) AS n FROM dm_blobs').get().n,1);assert.equal(db.prepare('SELECT length(data) AS bytes FROM dm_blobs').get().bytes,8*MB);db.close();
 }finally{s.close();rmSync(dir,{recursive:true});}
});
test('deleting A removes its reference while the identical file in B remains accessible',()=>{
 const dir=mkdtempSync(join(tmpdir(),'dm-references-')),path=join(dir,'dm.sqlite');const {store:s}=fixture(path);
 try{const a=accepted(s,'alice','bob'),b=accepted(s,'alice','carol');const file={name:'a.txt',mime:'text/plain',data:'c2hhcmVk'};
 const first=s.upload('alice',a,file),second=s.upload('alice',b,{...file,name:'b.txt'});
 const msgA=s.send('alice',a,{attachmentIds:[first.id],nonce:nonce()}),msgB=s.send('alice',b,{attachmentIds:[second.id],nonce:nonce()});
 s.remove('alice',msgA.id);assert.throws(()=>s.download('bob',first.id),e=>e.statusCode===404);assert.equal(s.download('carol',second.id).data,file.data);
 let db=new DatabaseSync(path);assert.equal(db.prepare('SELECT COUNT(*) AS n FROM dm_blobs').get().n,1);db.close();s.remove('alice',msgB.id);
 db=new DatabaseSync(path);assert.equal(db.prepare('SELECT COUNT(*) AS n FROM dm_blobs').get().n,0);db.close();
 }finally{s.close();rmSync(dir,{recursive:true});}
});
test('media filters use each attachment MIME after hash deduplication',()=>{
 const {store:s}=fixture();try{const id=accepted(s,'alice','bob'),data=Buffer.from('89504e470d0a1a0a','hex').toString('base64');const bin=s.upload('alice',id,{name:'first.bin',mime:'application/octet-stream',data});s.send('alice',id,{attachmentIds:[bin.id],nonce:nonce()});const image=s.upload('alice',id,{name:'image.png',mime:'image/png',data});const m=s.send('alice',id,{attachmentIds:[image.id],nonce:nonce()});const media=s.getMessages('bob',id,{filter:'media'}).messages;assert.equal(media.length,1);assert.equal(media[0].id,m.id);assert.equal(media[0].attachments[0].mime,'image/png');}finally{s.close();}
});
