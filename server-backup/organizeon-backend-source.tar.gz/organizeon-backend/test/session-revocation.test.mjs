import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';import {join} from 'node:path';import {EventEmitter} from 'node:events';
import {createAccountStore} from '../src/accounts.mjs';
import {hashPassword,createSessionToken,verifySessionToken} from '../src/auth.mjs';
import {createSessionConnections} from '../src/session-connections.mjs';
test('targeted revocation persists, removes login codes and preserves other accounts and passwords',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'revoke-test-'));try{
 const filePath=join(dir,'users.json');const store=await createAccountStore({filePath,initialOwnerUsername:'test_owner',initialOwnerPasswordHash:hashPassword('fixture-password')});
 const owner=store.get('test_owner');await store.create(owner,{username:'selected',password:'fixture-password',role:'user'});await store.create(owner,{username:'untouched',password:'fixture-password',role:'user'});
 await store.createLoginCode(owner,'selected');
 const before=JSON.parse(await readFile(filePath,'utf8'));const old=store.get('selected');const token=createSessionToken(old,'test-secret');
 await store.revokeSessions(owner,'selected');const after=JSON.parse(await readFile(filePath,'utf8'));
 assert.equal(after.users.selected.tokenVersion,old.tokenVersion+1);assert.equal(after.users.selected.loginCode,undefined);
 for(const key of ['passwordHash','role','permissions','disabled'])assert.deepEqual(after.users.selected[key],before.users.selected[key]);
 assert.deepEqual(after.users.untouched,before.users.untouched);assert.deepEqual(after.users.test_owner,before.users.test_owner);
 const reloaded=await createAccountStore({filePath});assert.notEqual(verifySessionToken(token,'test-secret').ver,reloaded.get('selected').tokenVersion);assert.ok(reloaded.authenticate('selected','fixture-password'));
 await assert.rejects(store.revokeSessions(store.get('selected'),'untouched'),e=>e.code==='forbidden');
 await store.create(owner,{username:'test_admin',password:'fixture-password',role:'admin'});await store.create(owner,{username:'peer_admin',password:'fixture-password',role:'admin'});
 await assert.rejects(store.revokeSessions(store.get('test_admin'),'test_owner'),e=>e.code==='cannot_manage_higher_role');
 await assert.rejects(store.revokeSessions(store.get('test_admin'),'peer_admin'),e=>e.code==='cannot_change_peer_access');
 await store.revokeSessions(store.get('test_admin'),'test_admin');
 assert.equal(store.get('test_admin').tokenVersion,2);
 }finally{await rm(dir,{recursive:true,force:true});}
});
test('revoking sockets disconnects only the selected account and cleans up closed sockets',()=>{
 const tracker=createSessionConnections();const socket=()=>{const s=new EventEmitter();s.destroy=()=>{s.destroyed=true;s.emit('close');};return s;};const a=socket(),b=socket(),c=socket();
 tracker.track('selected',a);tracker.track('selected',a);tracker.track('selected',b);tracker.track('other',c);
 assert.equal(tracker.revoke('selected'),2);assert.equal(a.destroyed,true);assert.equal(b.destroyed,true);assert.equal(c.destroyed,undefined);assert.equal(tracker.revoke('selected'),0);
 c.emit('close');assert.equal(tracker.revoke('other'),0);
});
