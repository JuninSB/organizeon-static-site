import test from 'node:test';import assert from 'node:assert/strict';import {mkdtemp,rm,readFile} from 'node:fs/promises';import {join} from 'node:path';import {tmpdir} from 'node:os';import {createAccountStore} from '../src/accounts.mjs';import {hashPassword} from '../src/auth.mjs';import {publicProfile,validateProfile} from '../src/profiles.mjs';
test('profile background is independently editable without a badge and rejects unsafe image inputs',()=>{
 const account={username:'fixture',profile:{bio:'keep',avatar:null}};
 assert.equal(publicProfile(account).bannerImage,null);assert.equal(publicProfile(account).bannerFit,'cover');
 for(const patch of [{bannerImage:'https://example.org/photo.jpg'},{bannerImage:'data:image/svg+xml;base64,PHN2Zz4='},{bannerImage:'data:image/jpeg;base64,AAAA'},{bannerImage:'x'.repeat(132001)},{bannerFit:'contain'}])assert.throws(()=>validateProfile(patch,account),e=>e.code==='invalid_profile');
 const cleared=validateProfile({bannerImage:null,bannerFit:'fill'},account);assert.equal(cleared.bannerImage,null);assert.equal(cleared.bannerFit,'fill');assert.equal(cleared.bio,'keep');
});
test('image is a background style, preserves existing uploads, and switches cleanly to animated or solid styles',async()=>{
 const image='data:image/jpeg;base64,'+(await readFile(new URL('./fixtures/profile-banner.jpg',import.meta.url))).toString('base64');
 const user={username:'fixture'};const saved=validateProfile({bannerStyle:'image',bannerImage:image},user);
 assert.equal(saved.bannerStyle,'image');assert.equal(publicProfile({...user,profile:saved}).bannerStyle,'image');
 assert.throws(()=>validateProfile({bannerStyle:'image'},user),e=>e.code==='invalid_profile');
 const legacy={...user,profile:{bannerImage:image,bannerStyle:'solid'}};assert.equal(publicProfile(legacy).bannerStyle,'image');
 assert.equal(validateProfile({bio:'keep photo'},legacy).bannerImage,image);
 const awarded={...user,goldBadge:{awardedBy:'owner'},profile:saved};
 const stars=validateProfile({bannerStyle:'stars'},awarded);assert.equal(stars.bannerImage,null);assert.equal(publicProfile({...awarded,profile:stars}).bannerStyle,'stars');
 const solid=validateProfile({bannerStyle:'solid'},legacy);assert.equal(solid.bannerImage,null);
 assert.equal(validateProfile({bannerImage:null},legacy).bannerStyle,'solid');
});
test('profile defaults and validation reject roles, external/SVG images, unsafe color and oversized fields',()=>{
 const user={username:'fixture'};assert.equal(publicProfile(user).displayName,'fixture');for(const patch of [{role:'owner'},{nameColor:'url(javascript:alert(1))'},{displayName:''},{displayName:'x'.repeat(41)},{bio:'x'.repeat(281)},{avatar:'https://example.com/photo.jpg'},{avatar:'data:image/svg+xml;base64,PHN2Zz4='},{avatarShape:'triangle'}])assert.throws(()=>validateProfile(patch,user),e=>e.code==='invalid_profile');assert.equal(validateProfile({displayName:' Display '},user).displayName,'Display');
});
test('own profile persists independently of login identity, credentials, rank and sessions',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'profile-test-'));try{const filePath=join(dir,'users.json');const store=await createAccountStore({filePath,initialOwnerUsername:'fixture_owner',initialOwnerPasswordHash:hashPassword('test-password')});const actor=store.get('fixture_owner');const before=JSON.parse(await readFile(filePath,'utf8'));const profile=await store.updateOwnProfile(actor,{displayName:'Display',bio:'Descrição',nameColor:'#34D399',avatarShape:'rounded'});assert.equal(profile.avatar,null);const reloaded=await createAccountStore({filePath});assert.deepEqual(reloaded.get(actor.username).profile,profile);const after=JSON.parse(await readFile(filePath,'utf8'));for(const key of ['username','passwordHash','role','permissions','tokenVersion'])assert.deepEqual(after.users[actor.username][key],before.users[actor.username][key]);await assert.rejects(store.updateOwnProfile(actor,{username:'someone_else'}),e=>e.code==='invalid_profile');
 }finally{await rm(dir,{recursive:true,force:true});}
});
test('only an actual owner can grant a persistent gold badge; appearance cannot forge entitlement',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'gold-badge-test-'));try{
  const filePath=join(dir,'users.json');const store=await createAccountStore({filePath,initialOwnerUsername:'fixture_owner',initialOwnerPasswordHash:hashPassword('test-password')});
  const owner=store.get('fixture_owner');await store.create(owner,{username:'fixture_user',password:'test-password',role:'user',permissions:[]});await store.create(owner,{username:'fixture_admin',password:'test-password',role:'admin',permissions:[]});
  const user=store.get('fixture_user'),admin=store.get('fixture_admin');const before=JSON.parse(await readFile(filePath,'utf8')).users.fixture_user;
  for(const actor of [user,admin,{...user,role:'owner'},null])await assert.rejects(store.grantGoldBadge(actor,'fixture_user'),e=>e.code==='forbidden');
  await assert.rejects(store.updateOwnProfile(user,{goldBadge:true}),e=>e.code==='invalid_profile');await assert.rejects(store.updateOwnProfile(user,{bannerStyle:'lava'}),e=>e.code==='invalid_profile');
  const granted=await store.grantGoldBadge(owner,'fixture_user');assert.equal(granted.goldBadge,true);assert.equal(granted.bannerStyle,'lava');assert.equal(granted.showGoldBadge,true);assert.equal(store.get('fixture_user').goldBadgeNotificationPending,true);const offline=await createAccountStore({filePath});assert.equal(offline.get('fixture_user').goldBadgeNotificationPending,true);assert.equal((await store.claimGoldBadgeNotification(user)).claimed,true);assert.equal((await store.claimGoldBadgeNotification(user)).claimed,false);assert.equal(store.get('fixture_user').goldBadgeNotificationPending,false);assert.equal((await createAccountStore({filePath})).get('fixture_user').goldBadgeNotificationPending,false);
  const saved=await store.updateOwnProfile(user,{showGoldBadge:false,bannerStyle:'solid'});assert.equal(saved.goldBadge,true);assert.equal(saved.showGoldBadge,false);assert.equal(saved.bannerStyle,'solid');
  assert.deepEqual(await store.grantGoldBadge(owner,'fixture_user'),saved);const reloaded=await createAccountStore({filePath});assert.deepEqual(reloaded.get('fixture_user').profile,saved);
  const after=JSON.parse(await readFile(filePath,'utf8')).users.fixture_user;for(const key of ['passwordHash','role','permissions','tokenVersion'])assert.deepEqual(after[key],before[key]);assert.equal(after.goldBadge.awardedBy,'fixture_owner');
 }finally{await rm(dir,{recursive:true,force:true});}
});
test('the owner can award its own profile even when its administrative identity is hidden from user listings',async()=>{const dir=await mkdtemp(join(tmpdir(),'gold-owner-self-'));try{const store=await createAccountStore({filePath:join(dir,'users.json'),initialOwnerUsername:'organizeon',initialOwnerPasswordHash:hashPassword('test-password')});const owner=store.get('organizeon');assert.equal((await store.grantGoldBadge(owner,owner.username)).goldBadge,true);}finally{await rm(dir,{recursive:true,force:true});}});
test('banner reroll requires award, changes only own seed, enforces persisted rolling 24h cooldown and serializes simultaneous writes',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'banner-reroll-'));let time=Date.parse('2026-11-16T12:00:00Z');
 try{const filePath=join(dir,'users.json');const store=await createAccountStore({filePath,initialOwnerUsername:'owner_fixture',initialOwnerPasswordHash:hashPassword('test-password'),now:()=>time});const owner=store.get('owner_fixture');await store.create(owner,{username:'user_fixture',password:'test-password',role:'user',permissions:[]});const user=store.get('user_fixture');
 await assert.rejects(store.rerollProfileBanner(user),e=>e.code==='gold_badge_required');await store.grantGoldBadge(owner,user.username);await store.claimGoldBadgeNotification(user);const before=store.get(user.username),initial=before.profile.bannerSeed;
 for(const patch of [{bannerSeed:'a'.repeat(32)},{bannerRerollAvailableAt:null}])await assert.rejects(store.updateOwnProfile(user,patch),e=>e.code==='invalid_profile');
 const results=await Promise.allSettled([store.rerollProfileBanner(user),store.rerollProfileBanner(user),store.updateOwnProfile(user,{bio:'concurrent edit'})]);assert.equal(results[0].status,'fulfilled');assert.equal(results[1].status,'rejected');assert.equal(results[1].reason.code,'banner_reroll_cooldown');assert.equal(results[2].status,'fulfilled');
 const first=store.get(user.username).profile;assert.notEqual(first.bannerSeed,initial);assert.match(first.bannerSeed,/^[a-f0-9]{32}$/);assert.equal(first.bannerRerollAvailableAt,new Date(time+86400000).toISOString());assert.equal(first.bio,'concurrent edit');assert.equal(store.get(user.username).goldBadgeNotificationPending,false);
 const reloaded=await createAccountStore({filePath,now:()=>time});await assert.rejects(reloaded.rerollProfileBanner(reloaded.get(user.username)),e=>e.code==='banner_reroll_cooldown'&&e.retryAfter===86400);
 time+=86399999;await assert.rejects(reloaded.rerollProfileBanner(reloaded.get(user.username)),e=>e.code==='banner_reroll_cooldown');time++;const second=await reloaded.rerollProfileBanner(reloaded.get(user.username));assert.notEqual(second.bannerSeed,first.bannerSeed);
 assert.equal(reloaded.get(owner.username).profile.bannerSeed,store.get(owner.username).profile.bannerSeed);
 const account=reloaded.get(user.username);for(const key of ['role','permissions','tokenVersion'])assert.deepEqual(account[key],before[key]);
 }finally{await rm(dir,{recursive:true,force:true});}
});
test('owners can reroll repeatedly without cooldown while a forged owner label cannot bypass another account cooldown',async()=>{const dir=await mkdtemp(join(tmpdir(),'owner-reroll-'));try{const store=await createAccountStore({filePath:join(dir,'users.json'),initialOwnerUsername:'owner_fixture',initialOwnerPasswordHash:hashPassword('test-password')});const owner=store.get('owner_fixture');await store.grantGoldBadge(owner,owner.username);const first=await store.rerollProfileBanner(owner),second=await store.rerollProfileBanner(owner);assert.notEqual(first.bannerSeed,second.bannerSeed);assert.equal(second.bannerRerollAvailableAt,null);assert.equal(second.bannerRerollUnlimited,true);await store.create(owner,{username:'user_fixture',password:'test-password',role:'user',permissions:[]});await store.grantGoldBadge(owner,'user_fixture');const user=store.get('user_fixture');await store.rerollProfileBanner(user);await assert.rejects(store.rerollProfileBanner({...user,role:'owner'}),error=>error.code==='banner_reroll_cooldown');}finally{await rm(dir,{recursive:true,force:true});}});
test('additional banner materials require the gold badge and retain the selected material',()=>{for(const bannerStyle of ['slime','bubbles','gradient','magma','stars','rainbow']){assert.throws(()=>validateProfile({bannerStyle},{username:'fixture'}),e=>e.code==='invalid_profile');const account={username:'fixture',goldBadge:{awardedBy:'owner'}};const saved=validateProfile({bannerStyle},account);assert.equal(publicProfile({...account,profile:saved}).bannerStyle,bannerStyle);}});
test('custom banner color requires badge, persists and defaults to following nickname',async()=>{
 const user={username:'fixture',profile:{nameColor:'#34d399'}};
 assert.equal(publicProfile(user).bannerColor,null);
 assert.throws(()=>validateProfile({bannerColor:'#8822cc'},user));
 const awarded={...user,goldBadge:{awardedBy:'owner'}};
 assert.equal(validateProfile({bannerColor:'#8822cc'},awarded).bannerColor,'#8822cc');
 assert.throws(()=>validateProfile({bannerColor:'url(x)'},awarded));
 assert.equal(validateProfile({bannerColor:null},awarded).bannerColor,null);
 const dir=await mkdtemp(join(tmpdir(),'banner-color-'));try{
 const filePath=join(dir,'users.json');const store=await createAccountStore({filePath,initialOwnerUsername:'fixture_owner',initialOwnerPasswordHash:hashPassword('fixture-password')});
 const owner=store.get('fixture_owner');await store.grantGoldBadge(owner,'fixture_owner');await store.updateOwnProfile(store.get('fixture_owner'),{bannerColor:'#8822cc'});
 const reloaded=await createAccountStore({filePath});assert.equal(reloaded.get('fixture_owner').profile.bannerColor,'#8822cc');
 }finally{await rm(dir,{recursive:true,force:true});}
});
