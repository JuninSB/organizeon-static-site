from pathlib import Path
p = Path('d2-panel.html')
s = p.read_text()
needle = '</script></body></html>'
extra = r'''// Authenticated downloads and browser-compatible uploads.
async function downloadFile(id,name){try{const r=await fetch(API+'/files/'+id+'/content',{headers:{Authorization:'Bearer '+token}});if(!r.ok)throw Error('download_failed');const a=document.createElement('a');a.href=URL.createObjectURL(await r.blob());a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}catch(e){alert(e.message)}}
async function uploadFile(){const f=$('upload').files[0];if(!f)return;$('msg').textContent='Enviando...';try{await api('/files',{method:'POST',headers:{'Content-Type':f.type||'application/octet-stream','X-File-Name':encodeURIComponent(f.name)},body:f});$('msg').textContent='Enviado.';$('upload').value='';await refresh()}catch(e){$('msg').textContent=e.message}}
async function copyLink(id){await navigator.clipboard.writeText(API+'/files/'+id+'/raw/content');alert('Link raw copiado.')}
const originalRefresh=refresh;refresh=async function(){await originalRefresh();document.querySelectorAll('#files a[href*="/content"]').forEach(a=>{const id=a.href.split('/files/')[1].split('/')[0],name=a.closest('.file').querySelector('b').textContent;const b=document.createElement('button');b.textContent='Baixar';b.onclick=()=>downloadFile(id,name);const c=document.createElement('button');c.textContent='Copiar link';c.onclick=()=>copyLink(id);a.replaceWith(b);b.after(c)})};
login=async function(){const status=$('loginMsg');status.textContent='Entrando...';try{const r=await fetch(API+'/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('user').value,password:$('pass').value})});const d=await r.json();if(!r.ok)throw Error(d.error||('HTTP '+r.status));token=d.token;localStorage.setItem('organizeon_panel_token',token);status.textContent='Login realizado.';alert('Login realizado com sucesso.');await showApp()}catch(e){status.textContent='Erro: '+e.message;alert('Erro no login: '+e.message)}};
'''
s = s.split('// Authenticated downloads')[0]
if needle in s:
    s = s.replace(needle, extra + needle)
else:
    s = s.rstrip() + extra + needle
p.write_text(s)
