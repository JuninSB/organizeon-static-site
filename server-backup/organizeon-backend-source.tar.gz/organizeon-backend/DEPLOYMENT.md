# OrganizeOn: instalação, recuperação e publicação

Este pacote contém o backend autenticado, o painel D2, os testes e os scripts de
recuperação. Credenciais reais, bancos de usuários, logs, uploads e pacotes do
Chimera não fazem parte do backup público.

## Requisitos no Termux

```sh
pkg update
pkg install nodejs-lts termux-services cloudflared openssh
mkdir -p "$HOME/organizeon/backend"
```

Extraia o código em `$HOME/organizeon/backend`, copie `.env.example` para `.env`
e preencha os valores. Nunca publique `.env` nem o arquivo extra de segredos.

```sh
cd "$HOME/organizeon/backend"
npm ci --omit=dev
mkdir -p data
node scripts/create-emergency-users.mjs data/users-emergency.json
chmod 700 start-organizeon.sh scripts/runit-backend-run.sh
```

A senha inicial do modo de emergência é `org_2206@22`. Troque-a logo depois do
primeiro login ou defina `ORGANIZEON_EMERGENCY_PASSWORD` ao gerar o arquivo.

## Runit e boot do Android

```sh
mkdir -p "$PREFIX/var/service/organizeon-backend"
cp deploy/runit/organizeon-backend/run "$PREFIX/var/service/organizeon-backend/run"
chmod 700 "$PREFIX/var/service/organizeon-backend/run"
mkdir -p "$HOME/.termux/boot"
cp deploy/termux-boot/start-organizeon "$HOME/.termux/boot/start-organizeon"
chmod 700 "$HOME/.termux/boot/start-organizeon"
```

O lançador do runit valida o banco antes de iniciar. Se `data/users.json` estiver
ausente ou inválido, ele usa `data/users-emergency.json`, sem sobrescrever o banco
quebrado.

## Comandos de manutenção

```sh
./start-organizeon.sh       # inicia; fallback automático se necessário
./start-organizeon.sh -e    # força o banco de emergência
./start-organizeon.sh -r    # reinicia e aguarda o health check
./start-organizeon.sh -s    # status do processo e da API
npm test                    # testes unitários
node scripts/live-flow-test.mjs  # teste integrado local; cria conta temporária
```

Após o teste integrado, remova a conta indicada na saída com o backend parado:

```sh
sv down "$PREFIX/var/service/organizeon-backend"
node scripts/remove-flow-test-account.mjs data/users.json flow_test_ID
./start-organizeon.sh
```

## Cloudflare Tunnel

Use `cloudflared-config.example.yml` como referência. As rotas públicas devem
apontar a API para a porta definida em `.env`, o relay Eaglercraft para `6699` e
o frontend para o domínio estático. Armazene o token do tunnel fora do repositório
e dê permissão `600` ao arquivo.

## Frontend e GitHub Pages

O frontend fica no repositório `organizeon-static-site`. Antes de publicar:

```sh
npm test
git status
git add -A
git commit -m "Atualiza OrganizeOn e recuperação do servidor"
git push origin main
```

O `download-manifest.json` contém tamanho e SHA-256 dos arquivos distribuídos.
Qualquer alteração nesses arquivos exige atualizar o manifesto e executar os
testes antes do push.

## Backup privado completo

Faça backup de código e dados separadamente. O segundo arquivo é privado:

```sh
tar -czf organizeon-source.tar.gz -C "$HOME" organizeon/backend \
  --exclude='organizeon/backend/node_modules' \
  --exclude='organizeon/backend/data' \
  --exclude='organizeon/backend/.env' \
  --exclude='organizeon/backend/server.log'
tar -czf organizeon-private-data.tar.gz -C "$HOME/organizeon/backend" data .env
chmod 600 organizeon-private-data.tar.gz
```

Não envie o backup privado ao GitHub.

