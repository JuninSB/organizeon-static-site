from pathlib import Path
p=Path('src/server.mjs'); s=p.read_text()
s=s.replace('    if (downloadPath.startsWith("/d2/files/")', '    if (downloadPath.startsWith("/d2/download/") && (request.method === "GET" || request.method === "HEAD")) { return sendShortPanelFileDownload(request, response, downloadPath.slice("/d2/download/".length), true); }\n    if (downloadPath.startsWith("/d2/files/")')
s=s.replace('return sendShortPanelFileDownload(request, response, downloadPath.slice("/d2/files/".length));', 'return sendShortPanelFileDownload(request, response, downloadPath.slice("/d2/files/".length), new URL(request.url, "http://download.invalid").searchParams.get("download") === "1");')
s=s.replace('async function sendShortPanelFileDownload(request, response, encodedName)', 'async function sendShortPanelFileDownload(request, response, encodedName, forceDownload = false)')
s=s.replace('new URL(request.url, "http://download.invalid").searchParams.get("download") === "1" ? "?download=1" : ""', 'forceDownload ? "?download=1" : ""')
s=s.replace('"Content-Disposition": `inline; filename="${item.metadata.name.replace(/"/g, "")}"`,', '"Content-Disposition": `${new URL(request.url, `http://${request.headers.host || "localhost"}`).searchParams.get("download") === "1" ? "attachment" : "inline"}; filename="${item.metadata.name.replace(/"/g, "")}"`,')
p.write_text(s)
