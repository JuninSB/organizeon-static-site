import path from 'node:path'
import { fileURLToPath } from 'node:url'
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vitest/config'

const root = path.dirname(fileURLToPath(import.meta.url))
export default defineConfig({
  base: '/d3/',
  plugins: [react()],
  resolve: { alias: { '@': path.resolve(root, 'src') } },
  build: { outDir: 'dist', emptyOutDir: true, sourcemap: false, cssMinify: false },
  test: { environment: 'jsdom', setupFiles: './src/test/setup.ts', restoreMocks: true, testTimeout: 20000, hookTimeout: 20000 },
})
