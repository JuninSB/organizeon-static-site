import { create } from 'zustand';
import type { DashboardStatus, PageFilters } from '@/types/dashboard';

type DashboardState = {
  status: DashboardStatus | null;
  serverOffsetMs: number;
  connected: boolean;
  lastSyncAt: number | null;
  historyFilters: PageFilters;
  logFilters: PageFilters;
  setStatus: (status: DashboardStatus, offsetMs: number) => void;
  setConnected: (connected: boolean) => void;
  setHistoryFilters: (filters: Partial<PageFilters>) => void;
  setLogFilters: (filters: Partial<PageFilters>) => void;
};
const initialFilters: PageFilters = { from: '', to: '', result: '', severity: '', offset: 0 };
export const useDashboardStore = create<DashboardState>((set) => ({
  status: null,
  serverOffsetMs: 0,
  connected: false,
  lastSyncAt: null,
  historyFilters: { ...initialFilters },
  logFilters: { ...initialFilters },
  setStatus: (status, offsetMs) => set({ status, serverOffsetMs: offsetMs, connected: true, lastSyncAt: Date.now() }),
  setConnected: (connected) => set({ connected }),
  setHistoryFilters: (filters) => set((state) => ({ historyFilters: { ...state.historyFilters, ...filters } })),
  setLogFilters: (filters) => set((state) => ({ logFilters: { ...state.logFilters, ...filters } })),
}));
