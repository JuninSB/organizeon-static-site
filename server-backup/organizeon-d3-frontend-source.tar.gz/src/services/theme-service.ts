export type Theme = 'dark' | 'light';

export function getThemePreference(): Theme {
  try { return window.localStorage.getItem('d3-theme') === 'light' ? 'light' : 'dark'; }
  catch { return 'dark'; }
}

export function applyTheme(theme: Theme) {
  const root = document.documentElement;
  root.classList.toggle('dark', theme === 'dark');
  root.classList.toggle('light', theme === 'light');
  root.dataset.theme = theme;
  try { window.localStorage.setItem('d3-theme', theme); } catch { /* applied for the current document */ }
  document.querySelector('meta[name="color-scheme"]')?.setAttribute('content', theme);
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme === 'dark' ? '#09090B' : '#FFFFFF');
  const favicon = document.getElementById('d3-favicon') as HTMLLinkElement | null;
  if (favicon) favicon.href = theme === 'dark' ? '/d3/assets/organizeon-icon.png' : '/d3/assets/organizeon_icon_black_128.png';
}
