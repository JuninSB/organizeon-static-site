import { apiRequest } from './api-client';
import type { Session } from '@/types/dashboard';

type Credentials = { username: string; password: string };

export const authService = {
  session: () => apiRequest<Session>('session'),
  login: (credentials: Credentials) => apiRequest<Session & { ok: boolean }>('login', {
    method: 'POST',
    body: JSON.stringify(credentials),
  }),
  logout: () => apiRequest<{ ok: boolean }>('logout', { method: 'POST', body: '{}' }),
};
