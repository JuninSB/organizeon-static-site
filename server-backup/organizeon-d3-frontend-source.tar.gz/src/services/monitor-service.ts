import { apiRequest } from './api-client';
import type { Attempt, DashboardStatus, EventLog, Settings } from '@/types/dashboard';

export type QueryFilters = { from?: string; to?: string; result?: string; severity?: string; offset?: number };
function queryString(filters: QueryFilters) {
  const query = new URLSearchParams();
  for (const [key, value] of Object.entries({ ...filters, limit: 50 })) {
    if (value !== '' && value !== undefined && value !== null) query.set(key, String(value));
  }
  return query.toString();
}

export const monitorService = {
  status: (signal?: AbortSignal) => apiRequest<DashboardStatus>('status', { signal }),
  settings: (signal?: AbortSignal) => apiRequest<Settings>('settings', { signal }),
  updateDelay: (delayMs: number) => apiRequest<{ ok: boolean; delayMs: number; schedulerRestarted: boolean }>('settings/delay', {
    method: 'PUT',
    body: JSON.stringify({ delayMs }),
  }),
  history: (filters: QueryFilters, signal?: AbortSignal) =>
    apiRequest<{ items: Attempt[]; offset: number; limit: number }>(`history?${queryString(filters)}`, { signal }),
  logs: (filters: QueryFilters, signal?: AbortSignal) =>
    apiRequest<{ items: EventLog[]; offset: number; limit: number }>(`logs?${queryString(filters)}`, { signal }),
};
