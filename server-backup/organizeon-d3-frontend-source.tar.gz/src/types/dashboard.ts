export type Session = {
  authenticated: boolean;
  username?: string;
  role?: string;
};

export type Attempt = {
  id: string;
  at: string;
  requestSent: boolean;
  result: string;
  code: string | null;
  message: string | null;
  latencyMs: number | null;
  durationMs: number | null;
  error: string | null;
  authorizationState: string;
  brazilTime: string | null;
  chinaTime: string | null;
};

export type EventLog = {
  id: string;
  at: string;
  kind: string;
  severity: 'info' | 'success' | 'warning' | 'error';
  message: string;
};

export type DashboardStatus = {
  serverOnline: boolean;
  xiaomiProcess: boolean;
  tmux: boolean;
  androidUptimeSeconds: number;
  cpuPercent: number | null;
  memory: { total: number; available: number; used: number };
  connectivity: boolean;
  updatedAt: string;
  state: string;
  authValidated: boolean;
  approved: boolean;
  scheduler: 'active' | 'stopped';
  nextAttempt: { china: string; brazil: string; epoch: number };
  lastAttempt: Pick<Attempt, 'at' | 'result' | 'message' | 'requestSent'> | null;
};

export type Settings = {
  toolVersion: string;
  auth: string;
  timezone: string;
  delayMs: number;
  delayMinMs: number;
  delayMaxMs: number;
  canConfigureDelay: boolean;
  installDirectory: string;
  process: string;
  storage: string;
  authAccount: string;
};

export type PageFilters = {
  from: string;
  to: string;
  result: string;
  severity: string;
  offset: number;
};
