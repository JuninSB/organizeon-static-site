import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { authService } from '@/services/auth-service';
import type { Session } from '@/types/dashboard';

type AuthContextValue = {
  session: Session | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
};
const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshSession = useCallback(async () => {
    setLoading(true);
    try {
      const value = await authService.session();
      const authenticated = value.authenticated ? value : null;
      setSession(authenticated);
      return authenticated;
    } catch {
      setSession(null);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const onUnauthorized = () => { setSession(null); setLoading(false); };
    window.addEventListener('d3:unauthorized', onUnauthorized);
    void refreshSession();
    return () => { window.removeEventListener('d3:unauthorized', onUnauthorized); };
  }, [refreshSession]);

  const login = useCallback(async (username: string, password: string) => {
    await authService.login({ username, password });
    const authenticated = await refreshSession();
    if (!authenticated) throw new Error('Não foi possível validar a sessão do painel.');
  }, [refreshSession]);

  const logout = useCallback(async () => {
    await authService.logout();
    setSession(null);
  }, []);
  const value = useMemo(() => ({ session, loading, login, logout }), [session, loading, login, logout]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useAuth deve ser usado dentro de AuthProvider.');
  return value;
}
