import { LavaBanner } from "./lava-banner";
import { profileBannerPattern } from "./profile-banner";
import { GoldBadge } from "./gold-badge";
import "./profile-banner.css";
import type { CSSProperties } from "react";
import { Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { Profile } from "@/services/profile-service";
import { ProfileAvatar, avatarRadius } from "./profile-avatar";
export type ProfileField = "identity" | "bio" | "photo" | "appearance";
/** Presentation is shared by own/public profiles; editing is an explicit capability. */
export function ProfileCard({
  username,
  role,
  profile,
  onEdit,
  frameless = false,
}: {
  username: string;
  role: string;
  profile: Profile;
  onEdit?: (field: ProfileField) => void;
  frameless?: boolean;
}) {
  const pencil = (field: ProfileField, label: string) =>
    onEdit && (
      <Button
        type="button"
        size="icon-sm"
        variant="ghost"
        className="size-11 rounded-full"
        aria-label={label}
        onClick={() => onEdit(field)}
      >
        <Pencil className="size-3.5" />
      </Button>
    );
  return (
    <div
      className={
        frameless
          ? "overflow-hidden"
          : "overflow-hidden rounded-xl border border-border bg-card"
      }
    >
      <div
        data-lava={!profile.bannerImage && profile.goldBadge && profile.bannerStyle !== "solid" && !!profile.bannerStyle ? "" : undefined}
        className={`oo-profile-banner ${frameless ? "h-28" : "h-20 border-b border-border"} bg-card`}
        style={
          frameless
            ? {
                ...profileBannerPattern(profile.bannerSeed || username),
                "--profile-color": profile.nameColor,
                background: `color-mix(in srgb, ${profile.bannerColor || profile.nameColor} 18%, rgb(var(--card)))`,
              } as CSSProperties
            : { ...profileBannerPattern(profile.bannerSeed || username), "--profile-color": profile.nameColor } as CSSProperties
        }
      >
        {profile.bannerImage ? <img src={profile.bannerImage} alt="Fundo do perfil" className="absolute inset-0 size-full" style={{objectFit:profile.bannerFit || "cover"}} /> : profile.goldBadge && profile.bannerStyle !== "solid" && !!profile.bannerStyle && <LavaBanner seed={profile.bannerSeed || username} color={profile.bannerColor || profile.nameColor} material={profile.bannerStyle === "lava" ? undefined : profile.bannerStyle === "magma" ? "lava" : profile.bannerStyle} />}
        {onEdit && <div className="absolute left-3 top-3 rounded-lg bg-background/80">{pencil("appearance", "Editar aparência")}</div>}
      </div>
      <div className="px-5 pb-5 sm:px-6 sm:pb-6">
        <div className="relative -mt-10 mb-4 flex items-end justify-between gap-3">
          <div
            data-avatar-frame
            className={`${frameless ? "bg-popover" : "bg-card"} p-1`}
            style={{ borderRadius: avatarRadius(profile.avatarShape) }}
          >
            <ProfileAvatar
              profile={profile}
              className={frameless ? "size-24" : "size-20"}
            />
          </div>
          <div className="flex items-center gap-2">
            {profile.goldBadge && profile.showGoldBadge !== false && <GoldBadge color={profile.nameColor} />}
            {pencil("photo", "Editar foto de perfil")}
          </div>
        </div>
        <div className="flex min-w-0 items-start gap-2">
          <div className="min-w-0 flex-1">
            <h2
              className="break-words text-xl font-semibold leading-tight tracking-tight"
              style={{
                color:
                  profile.nameColor.toUpperCase() === "#FAFAFA"
                    ? undefined
                    : profile.nameColor,
              }}
            >
              {profile.displayName}
            </h2>
            <p className="mt-1 break-all text-sm text-muted-foreground">
              @{username}
            </p>
          </div>
          {pencil("identity", "Editar nome e cor")}
        </div>
        <Badge variant="secondary" className="mt-3">
          {role}
        </Badge>
        <section
          className="mt-5 border-t border-border pt-4"
          aria-label="Descrição do perfil"
        >
          <div className="mb-2 flex items-center justify-between gap-3">
            <h3 className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Sobre
            </h3>
            {pencil("bio", "Editar descrição")}
          </div>
          <p className="whitespace-pre-wrap break-words text-sm leading-relaxed">
            {profile.bio || (
              <span className="text-muted-foreground">
                Nenhuma descrição adicionada.
              </span>
            )}
          </p>
        </section>
      </div>
    </div>
  );
}
