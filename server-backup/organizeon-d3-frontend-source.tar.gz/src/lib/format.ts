export function formatDateTime(value?: string | null, timeZone?: string) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('pt-BR', {
    dateStyle: 'medium', timeStyle: 'short', ...(timeZone ? { timeZone } : {}),
  }).format(date);
}
export function formatDuration(seconds?: number | null) {
  if (seconds == null || !Number.isFinite(seconds) || seconds < 0) return '—';
  let value = Math.floor(seconds);
  const days = Math.floor(value / 86400); value %= 86400;
  const hours = Math.floor(value / 3600); value %= 3600;
  const minutes = Math.floor(value / 60); const rest = value % 60;
  return `${days ? `${days}d ` : ''}${[hours, minutes, rest].map(x => String(x).padStart(2, '0')).join(':')}`;
}
export function formatBytes(bytes?: number | null) {
  return bytes == null || !Number.isFinite(bytes) ? '—' : `${Math.round(bytes / 1048576)} MB`;
}
export function getCountdown(epochSeconds: number, now = Date.now()) {
  return formatDuration(Math.max(0, (epochSeconds * 1000 - now) / 1000));
}
