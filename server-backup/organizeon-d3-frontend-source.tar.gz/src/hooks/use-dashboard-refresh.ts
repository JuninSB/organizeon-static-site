import { useCallback, useEffect, useRef, useState } from 'react';
import { monitorService } from '@/services/monitor-service';
import { useDashboardStore } from '@/store/dashboard-store';

export function useDashboardRefresh() {
  const setStatus = useDashboardStore((state) => state.setStatus);
  const setConnected = useDashboardStore((state) => state.setConnected);
  const [refreshing, setRefreshing] = useState(false);
  const controller = useRef<AbortController | null>(null);
  const refresh = useCallback(async () => {
    controller.current?.abort();
    const next = new AbortController(); controller.current = next;
    const startedAt = Date.now(); setRefreshing(true);
    try {
      const status = await monitorService.status(next.signal);
      if (!next.signal.aborted) setStatus(status, Date.now() - startedAt);
    } catch {
      if (!next.signal.aborted) setConnected(false);
    } finally {
      if (!next.signal.aborted) setRefreshing(false);
    }
  }, [setConnected, setStatus]);

  useEffect(() => {
    void refresh();
    const timer = window.setInterval(() => {
      if (document.visibilityState === 'visible') void refresh();
    }, 15000);
    const onVisible = () => { if (document.visibilityState === 'visible') void refresh(); };
    document.addEventListener('visibilitychange', onVisible);
    return () => { window.clearInterval(timer); document.removeEventListener('visibilitychange', onVisible); controller.current?.abort(); };
  }, [refresh]);
  return { refresh, refreshing };
}
