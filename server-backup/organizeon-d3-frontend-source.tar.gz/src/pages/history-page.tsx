import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, ExternalLink, Search } from 'lucide-react';
import type { Attempt } from '@/types/dashboard';
import { monitorService } from '@/services/monitor-service';
import { useDashboardStore } from '@/store/dashboard-store';
import { formatDateTime } from '@/lib/format';
import { PageHeading } from '@/components/shared/page-heading';
import { EmptyState, ErrorState, LoadingBlock } from '@/components/shared/feedback-state';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';

const resultOptions = ['Autorização concedida', 'Cota esgotada', 'Falha', 'Resposta recebida', 'Resposta pendente'];
export function HistoryPage() {
  const filters = useDashboardStore((s) => s.historyFilters);
  const update = useDashboardStore((s) => s.setHistoryFilters);
  const [items, setItems] = useState<Attempt[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selected, setSelected] = useState<Attempt | null>(null);
  const [retry, setRetry] = useState(0);

  useEffect(() => {
    const controller = new AbortController(); let current = true;
    setLoading(true); setError('');
    monitorService.history(filters, controller.signal).then((data) => { if (current) setItems(data.items); })
      .catch((reason: unknown) => { if (current && !controller.signal.aborted) setError(reason instanceof Error ? reason.message : 'Falha ao carregar histórico.'); })
      .finally(() => { if (current) setLoading(false); });
    return () => { current = false; controller.abort(); };
  }, [filters, retry]);

  return (
    <div className="space-y-6">
      <PageHeading title="Histórico" description="Tentativas registradas pela automação, sem reconstrução de eventos ausentes." />
      <Card className="border-border bg-card shadow-none">
        <CardContent className="space-y-4 p-4 sm:p-5">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_1.5fr_auto] lg:items-end">
            <label className="grid gap-1.5 text-xs font-medium text-muted-foreground">De<input type="date" value={filters.from} onChange={(event) => update({ from: event.target.value, offset: 0 })} className="h-9 rounded-md border border-input bg-background px-3 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring" /></label>
            <label className="grid gap-1.5 text-xs font-medium text-muted-foreground">Até<input type="date" value={filters.to} onChange={(event) => update({ to: event.target.value, offset: 0 })} className="h-9 rounded-md border border-input bg-background px-3 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring" /></label>
            <label className="grid gap-1.5 text-xs font-medium text-muted-foreground">Resultado
              <Select value={filters.result || 'all'} onValueChange={(value) => update({ result: value === 'all' ? '' : String(value ?? ''), offset: 0 })}>
                <SelectTrigger aria-label="Filtrar por resultado" className="w-full"><SelectValue placeholder="Todos os resultados" /></SelectTrigger>
                <SelectContent><SelectItem value="all">Todos os resultados</SelectItem>{resultOptions.map((option) => <SelectItem key={option} value={option}>{option}</SelectItem>)}</SelectContent>
              </Select>
            </label>
            <Button variant="outline" onClick={() => update({ from: '', to: '', result: '', offset: 0 })}><Search />Limpar filtros</Button>
          </div>
          {loading ? <LoadingBlock rows={4} /> : error ? <ErrorState message={error} onRetry={() => setRetry((value) => value + 1)} /> : items.length === 0 ? <EmptyState title="Nenhuma tentativa encontrada" description="Não há registros para os filtros selecionados." /> : (
            <>
              <div className="overflow-x-auto rounded-md border border-border">
                <Table>
                  <TableHeader><TableRow><TableHead>Horário de Brasília</TableHead><TableHead>Horário da China</TableHead><TableHead>Resultado</TableHead><TableHead>Solicitação</TableHead><TableHead className="w-10"><span className="sr-only">Detalhes</span></TableHead></TableRow></TableHeader>
                  <TableBody>{items.map((item) => <TableRow key={item.id}>
                    <TableCell className="whitespace-nowrap">{formatDateTime(item.at, 'America/Sao_Paulo')}</TableCell>
                    <TableCell className="whitespace-nowrap text-muted-foreground">{formatDateTime(item.at, 'Asia/Shanghai')}</TableCell>
                    <TableCell><Badge variant="outline" className={item.result.includes('concedida') ? 'border-emerald-200 text-emerald-700 dark:border-emerald-900/70 dark:text-emerald-400' : ''}>{item.result}</Badge></TableCell>
                    <TableCell>{item.requestSent ? 'Enviada' : 'Não enviada'}</TableCell>
                    <TableCell><Button variant="ghost" size="icon-sm" aria-label={`Ver detalhes da tentativa ${item.id}`} onClick={() => setSelected(item)}><ExternalLink /></Button></TableCell>
                  </TableRow>)}</TableBody>
                </Table>
              </div>
              <div className="flex items-center justify-between gap-3">
                <p className="text-xs text-muted-foreground">Registros exibidos: {items.length} · Página {Math.floor(filters.offset / 50) + 1}</p>
                <div className="flex gap-2"><Button variant="outline" size="sm" disabled={filters.offset === 0} onClick={() => update({ offset: Math.max(0, filters.offset - 50) })}><ChevronLeft />Anterior</Button><Button variant="outline" size="sm" disabled={items.length < 50} onClick={() => update({ offset: filters.offset + 50 })}>Próxima<ChevronRight /></Button></div>
              </div>
            </>
          )}
        </CardContent>
      </Card>
      <Dialog open={!!selected} onOpenChange={(open) => { if (!open) setSelected(null); }}>
        <DialogContent className="max-h-[85svh] overflow-y-auto sm:max-w-lg">
          <DialogHeader><DialogTitle>Detalhes da tentativa</DialogTitle><DialogDescription>Somente campos que foram registrados são apresentados.</DialogDescription></DialogHeader>
          {selected && <dl className="grid gap-3 text-sm sm:grid-cols-[150px_1fr]">
            <dt className="text-muted-foreground">Identificador</dt><dd className="break-all font-mono text-xs">{selected.id}</dd>
            <dt className="text-muted-foreground">Brasília</dt><dd>{formatDateTime(selected.at, 'America/Sao_Paulo')}</dd>
            <dt className="text-muted-foreground">China</dt><dd>{formatDateTime(selected.at, 'Asia/Shanghai')}</dd>
            <dt className="text-muted-foreground">Solicitação enviada</dt><dd>{selected.requestSent ? 'Sim' : 'Não'}</dd>
            <dt className="text-muted-foreground">Resultado</dt><dd>{selected.result}</dd>
            <dt className="text-muted-foreground">Código Xiaomi</dt><dd>{selected.code ?? 'Não registrado'}</dd>
            <dt className="text-muted-foreground">Latência</dt><dd>{selected.latencyMs == null ? 'Não registrada' : `${selected.latencyMs} ms`}</dd>
            <dt className="text-muted-foreground">Duração</dt><dd>{selected.durationMs == null ? 'Não registrada' : `${selected.durationMs} ms`}</dd>
            <dt className="text-muted-foreground">Autorização após tentativa</dt><dd>{selected.authorizationState || 'Desconhecida'}</dd>
            <dt className="text-muted-foreground">Mensagem</dt><dd className="break-words">{selected.message ?? 'Não registrada'}</dd>
            <dt className="text-muted-foreground">Erro</dt><dd className="break-words">{selected.error ?? 'Nenhum erro registrado'}</dd>
          </dl>}
        </DialogContent>
      </Dialog>
    </div>
  );
}
