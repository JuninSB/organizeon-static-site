import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Info, LockKeyhole, Server, Settings2 } from 'lucide-react';
import type { Settings } from '@/types/dashboard';
import { monitorService } from '@/services/monitor-service';
import { useDashboardStore } from '@/store/dashboard-store';
import { formatBytes, formatDateTime, formatDuration } from '@/lib/format';
import { PageHeading } from '@/components/shared/page-heading';
import { ErrorState, LoadingBlock } from '@/components/shared/feedback-state';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

function SettingRow({ label, value }: { label: string; value?: string | number | null }) {
  return <div className="grid gap-1 py-3 sm:grid-cols-[220px_1fr] sm:gap-4"><dt className="text-sm text-muted-foreground">{label}</dt><dd className="break-words text-sm font-medium">{value ?? 'Indisponível'}</dd></div>;
}
export function SettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [error, setError] = useState('');
  const status = useDashboardStore((s) => s.status);
  const [retry, setRetry] = useState(0);
  const delayInput = useRef<HTMLInputElement>(null);
  const [savingDelay, setSavingDelay] = useState(false);

  async function saveDelay(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const delayMs = Number(delayInput.current?.value);
    if (!Number.isInteger(delayMs) || !settings || delayMs < settings.delayMinMs || delayMs > settings.delayMaxMs) {
      toast.error(`Informe um número inteiro entre ${settings?.delayMinMs ?? -500} e ${settings?.delayMaxMs ?? 30000} ms.`);
      return;
    }
    if (delayMs === settings.delayMs) {
      toast.info('Este valor já está salvo.');
      return;
    }
    setSavingDelay(true);
    try {
      const result = await monitorService.updateDelay(delayMs);
      setSettings((current) => current ? { ...current, delayMs: result.delayMs } : current);
      if (delayInput.current) delayInput.current.value = String(result.delayMs);
      toast.success(result.schedulerRestarted ? 'Atraso salvo. O agendador foi recarregado para usar o novo valor.' : 'Atraso salvo para o próximo ciclo do agendador.');
    } catch {
      toast.error('Não foi possível salvar o atraso. A configuração atual foi mantida.');
    } finally {
      setSavingDelay(false);
    }
  }
  useEffect(() => {
    const controller = new AbortController(); setError('');
    monitorService.settings(controller.signal).then(setSettings).catch((reason: unknown) => {
      if (!controller.signal.aborted) setError(reason instanceof Error ? reason.message : 'Configurações indisponíveis.');
    });
    return () => controller.abort();
  }, [retry]);

  return <div className="space-y-6">
    <PageHeading title="Configurações" description="Parâmetros do serviço e estado do servidor." actions={<Badge variant="outline" className="gap-1.5"><LockKeyhole className="size-3.5" />{settings?.canConfigureDelay ? 'Ajuste privilegiado' : 'Somente leitura'}</Badge>} />
    {error ? <ErrorState message={error} onRetry={() => setRetry((value) => value + 1)} /> : !settings ? <LoadingBlock rows={4} /> : (
      <Tabs defaultValue="automation" className="space-y-4">
        <TabsList aria-label="Grupos de configuração">
          <TabsTrigger value="automation"><Settings2 />Automação</TabsTrigger>
          <TabsTrigger value="server"><Server />Servidor</TabsTrigger>
        </TabsList>
        <TabsContent value="automation">
          <Card className="border-border bg-card shadow-none">
            <CardHeader><CardTitle className="text-sm">Ferramenta Xiaomi</CardTitle><CardDescription>Estado da instalação local e parâmetros do agendador.</CardDescription></CardHeader>
            <CardContent>
              <dl className="divide-y divide-border">
                <SettingRow label="Versão" value={settings.toolVersion} />
                <SettingRow label="Autenticação Xiaomi" value={settings.auth} />
                <SettingRow label="Fuso da cota" value={settings.timezone} />
                <SettingRow label="Atraso local atual" value={`${settings.delayMs} ms`} />
                <SettingRow label="Processo agendador" value={settings.process} />
                <SettingRow label="Diretório de instalação" value={settings.installDirectory} />
              </dl>
              {settings.canConfigureDelay && <form onSubmit={saveDelay} className="mt-4 space-y-3 border-t border-border pt-4">
                <div className="grid gap-3 sm:grid-cols-[minmax(0,1fr)_150px_auto] sm:items-end">
                  <div className="space-y-1.5">
                    <label htmlFor="delay-ms" className="text-sm font-medium">Ajustar horário de envio</label>
                    <p id="delay-help" className="text-xs leading-5 text-muted-foreground">Valor negativo programa antes da abertura; positivo, depois. Faixa: {settings.delayMinMs} a {settings.delayMaxMs} ms.</p>
                  </div>
                  <Input ref={delayInput} id="delay-ms" type="number" inputMode="numeric" step="1" min={settings.delayMinMs} max={settings.delayMaxMs} defaultValue={settings.delayMs} aria-describedby="delay-help" disabled={savingDelay} />
                  <Button type="submit" disabled={savingDelay}>{savingDelay ? 'Salvando…' : 'Salvar atraso'}</Button>
                </div>
                <p className="flex items-start gap-2 rounded-md border border-border bg-muted/40 p-3 text-xs leading-5 text-muted-foreground"><Info className="mt-0.5 size-4 shrink-0" />O valor altera o instante local em que a solicitação começa. A latência até a Xiaomi varia; o horário de chegada não é garantido.</p>
              </form>}
              {!settings.canConfigureDelay && <p className="mt-3 flex items-start gap-2 rounded-md border border-border bg-muted/40 p-3 text-xs leading-5 text-muted-foreground"><Info className="mt-0.5 size-4 shrink-0" />Tokens, cookies e credenciais não são apresentados nem editáveis no dashboard.</p>}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="server">
          <Card className="border-border bg-card shadow-none">
            <CardHeader><CardTitle className="text-sm">Servidor e armazenamento</CardTitle><CardDescription>Valores lidos do processo Android em execução.</CardDescription></CardHeader>
            <CardContent><dl className="divide-y divide-border">
              <SettingRow label="Servidor" value={status?.serverOnline ? 'Online' : 'Indisponível'} />
              <SettingRow label="Processo Xiaomi" value={status?.xiaomiProcess ? 'Ativo' : 'Parado'} />
              <SettingRow label="Sessão tmux" value={status?.tmux ? 'Presente' : 'Ausente'} />
              <SettingRow label="Tempo ligado" value={formatDuration(status?.androidUptimeSeconds)} />
              <SettingRow label="CPU" value={status?.cpuPercent == null ? 'Aguardando amostra' : `${status.cpuPercent}%`} />
              <SettingRow label="Memória disponível" value={formatBytes(status?.memory.available)} />
              <SettingRow label="Armazenamento histórico" value={settings.storage} />
              <SettingRow label="Última sincronização" value={formatDateTime(status?.updatedAt)} />
            </dl></CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    )}
  </div>;
}
