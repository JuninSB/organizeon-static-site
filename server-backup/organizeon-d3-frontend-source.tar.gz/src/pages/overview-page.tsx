import { useEffect, useState } from 'react';
import { Activity, Check, Cpu, HardDrive, Server, ShieldCheck, TimerReset, Wifi } from 'lucide-react';
import { useDashboardStore } from '@/store/dashboard-store';
import { formatBytes, formatDateTime, formatDuration, getCountdown } from '@/lib/format';
import { PageHeading } from '@/components/shared/page-heading';
import { StateBadge } from '@/components/shared/state-badge';
import { EmptyState, LoadingBlock } from '@/components/shared/feedback-state';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

export function OverviewPage() {
  const status = useDashboardStore((s) => s.status);
  const connected = useDashboardStore((s) => s.connected);
  const offset = useDashboardStore((s) => s.serverOffsetMs);
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const id = window.setInterval(() => setNow(Date.now()), 500); return () => window.clearInterval(id); }, []);
  if (!status) return <><PageHeading title="Visão geral" description="Estado atual da automação de autorização Xiaomi." /><LoadingBlock rows={5} /></>;

  const grant = status.state === 'Autorização concedida';
  const stats = [
    { label: 'Processo Xiaomi', value: status.xiaomiProcess ? 'Ativo' : 'Parado', description: status.tmux ? 'Sessão tmux presente' : 'Sessão tmux ausente', icon: Activity, tone: status.xiaomiProcess },
    { label: 'CPU', value: status.cpuPercent == null ? '—' : `${status.cpuPercent}%`, description: 'Amostra do servidor Android', icon: Cpu, tone: null },
    { label: 'Memória disponível', value: formatBytes(status.memory.available), description: `de ${formatBytes(status.memory.total)}`, icon: HardDrive, tone: null },
  ];
  return (
    <div className="space-y-6">
      <PageHeading title="Visão geral" description="Estado atual da automação de autorização Xiaomi." />
      <div className="grid gap-3 lg:grid-cols-[1.2fr_0.8fr]">
        <Card className="border-border bg-card shadow-none">
          <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0 p-5 sm:p-6">
            <div><CardTitle className="text-sm font-semibold">Próxima abertura da cota</CardTitle><CardDescription className="mt-1">Agendamento diário com fuso Asia/Shanghai.</CardDescription></div>
            <Badge variant="outline" className={status.scheduler === 'active' ? 'border-emerald-200 text-emerald-700 dark:border-emerald-900/70 dark:text-emerald-400' : ''}>{status.scheduler === 'active' ? 'Agendador ativo' : 'Agendador parado'}</Badge>
          </CardHeader>
          <CardContent className="px-5 pb-5 sm:px-6 sm:pb-6">
            <p className="font-mono text-3xl font-semibold tabular-nums tracking-tight sm:text-4xl" aria-live="off">{getCountdown(status.nextAttempt.epoch, now - offset)}</p>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <div><p className="text-xs text-muted-foreground">Horário de Brasília</p><p className="mt-1 text-sm font-medium">{formatDateTime(status.nextAttempt.brazil, 'America/Sao_Paulo')}</p></div>
              <div><p className="text-xs text-muted-foreground">Horário da China</p><p className="mt-1 text-sm font-medium">{formatDateTime(status.nextAttempt.china, 'Asia/Shanghai')}</p></div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card shadow-none">
          <CardHeader className="p-5 sm:p-6"><CardTitle className="text-sm font-semibold">Servidor</CardTitle><CardDescription className="mt-1">Telemetria do Android que hospeda o painel.</CardDescription></CardHeader>
          <CardContent className="space-y-3 px-5 pb-5 sm:px-6 sm:pb-6">
            <div className="flex items-center justify-between gap-3 text-sm"><span className="flex items-center gap-2 text-muted-foreground"><Server className="size-4" />Disponibilidade</span><span>{status.serverOnline ? 'Online' : 'Offline'}</span></div>
            <Separator />
            <div className="flex items-center justify-between gap-3 text-sm"><span className="flex items-center gap-2 text-muted-foreground"><Wifi className="size-4" />Conectividade Xiaomi</span><span>{status.connectivity ? 'Disponível' : 'Indisponível'}</span></div>
            <Separator />
            <div className="flex items-center justify-between gap-3 text-sm"><span className="flex items-center gap-2 text-muted-foreground"><TimerReset className="size-4" />Tempo ligado</span><span className="font-mono text-xs">{formatDuration(status.androidUptimeSeconds)}</span></div>
            <p className="pt-1 text-xs text-muted-foreground">Última atualização: {formatDateTime(status.updatedAt)}</p>
          </CardContent>
        </Card>
      </div>

      <Card className="overflow-hidden border-border bg-card shadow-none">
        <CardContent className="flex flex-col gap-5 p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6">
          <div className="flex min-w-0 items-start gap-4">
            <div className={`grid size-10 shrink-0 place-items-center rounded-lg border ${grant ? 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900/70 dark:bg-emerald-950/40 dark:text-emerald-400' : 'border-border bg-muted text-muted-foreground'}`}>
              {grant ? <Check className="size-5" /> : <ShieldCheck className="size-5" />}
            </div>
            <div className="min-w-0 space-y-1.5">
              <div className="flex flex-wrap items-center gap-2"><h2 className="text-base font-semibold tracking-tight">Autorização da conta</h2><StateBadge state={status.state} /></div>
              <p className="max-w-2xl text-sm text-muted-foreground">{grant ? 'A Xiaomi confirmou a autorização da conta.' : 'Autorização da conta Xiaomi.'}</p>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-2 text-xs text-muted-foreground"><span className={`size-2 rounded-full ${connected ? 'bg-emerald-500' : 'bg-zinc-500 dark:bg-zinc-600'}`} />{connected ? 'Servidor online' : 'Sem comunicação'}</div>
        </CardContent>
      </Card>

      <div className="grid gap-3 md:grid-cols-3">
        {stats.map(({ label, value, description, icon: Icon }) => (
          <Card key={label} className="border-border bg-card shadow-none">
            <CardContent className="flex items-start justify-between gap-3 p-4 sm:p-5">
              <div className="min-w-0"><p className="text-xs font-medium text-muted-foreground">{label}</p><p className="mt-2 truncate text-xl font-semibold tracking-tight">{value}</p><p className="mt-1 truncate text-xs text-muted-foreground">{description}</p></div>
              <span className="grid size-8 shrink-0 place-items-center rounded-md border border-border bg-muted/50 text-muted-foreground"><Icon className="size-4" /></span>
            </CardContent>
          </Card>
        ))}
      </div>

      <section aria-labelledby="last-attempt-heading">
        <div className="mb-3 flex items-center justify-between"><div><h2 id="last-attempt-heading" className="text-sm font-semibold">Última tentativa</h2><p className="mt-1 text-xs text-muted-foreground">Dados registrados pela automação.</p></div></div>
        {status.lastAttempt ? (
          <Card className="border-border bg-card shadow-none"><CardContent className="grid gap-4 p-5 sm:grid-cols-3 sm:p-6">
            <div><p className="text-xs text-muted-foreground">Data · Brasília</p><p className="mt-1 text-sm font-medium">{formatDateTime(status.lastAttempt.at, 'America/Sao_Paulo')}</p></div>
            <div><p className="text-xs text-muted-foreground">Resultado</p><p className="mt-1 text-sm font-medium">{status.lastAttempt.result}</p></div>
            <div><p className="text-xs text-muted-foreground">Solicitação enviada</p><p className="mt-1 text-sm font-medium">{status.lastAttempt.requestSent ? 'Sim' : 'Não'}</p></div>
          </CardContent></Card>
        ) : <EmptyState title="Nenhuma tentativa registrada" description="O histórico será preenchido quando o serviço registrar uma tentativa." />}
      </section>
    </div>
  );
}
