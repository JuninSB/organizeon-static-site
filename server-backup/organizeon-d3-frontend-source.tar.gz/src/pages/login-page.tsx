import { useState, type FormEvent } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { LoaderCircle, ShieldCheck } from 'lucide-react';
import { useAuth } from '@/providers/auth-provider';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { ApiError } from '@/services/api-client';
import { BrandIcon } from '@/components/shared/brand-icon';

function loginError(error: unknown) {
  if (error instanceof ApiError && error.status === 401) return 'Usuário ou senha incorretos.';
  if (error instanceof ApiError && error.status === 403) return 'Este perfil não tem permissão para acessar o painel D3.';
  if (error instanceof ApiError && error.status === 429) return 'Muitas tentativas de login. Aguarde antes de tentar novamente.';
  return 'Não foi possível conectar ao serviço de autenticação.';
}

export function LoginPage() {
  const { session, loading, login } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (loading) return <div className="grid min-h-svh place-items-center p-4"><Skeleton className="h-72 w-full max-w-sm" /></div>;
  if (session?.authenticated) return <Navigate to="/" replace />;

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    setError('');
    try {
      await login(username.trim(), password);
      setPassword('');
      navigate('/', { replace: true });
    } catch (reason) {
      setError(loginError(reason));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="grid min-h-svh place-items-center px-4 py-10">
      <Card className="w-full max-w-[380px] border-border bg-card shadow-none">
        <CardHeader className="space-y-5">
          <div className="flex items-center gap-3">
            <BrandIcon className="size-10" />
            <div><p className="text-sm font-semibold">OrganizeOn <span className="font-normal text-muted-foreground">D3</span></p><p className="text-xs text-muted-foreground">Monitoramento Xiaomi</p></div>
          </div>
          <div className="space-y-1.5"><CardTitle className="text-xl">Entrar no painel</CardTitle><CardDescription>Autentique-se para acessar o conteúdo do Endpoint 3.</CardDescription></div>
        </CardHeader>
        <CardContent>
          <form className="space-y-4" onSubmit={(event) => void handleSubmit(event)}>
            <label className="grid gap-1.5 text-sm font-medium" htmlFor="d3-username">Usuário
              <Input id="d3-username" autoComplete="username" value={username} onChange={(event) => setUsername(event.target.value)} required disabled={submitting} />
            </label>
            <label className="grid gap-1.5 text-sm font-medium" htmlFor="d3-password">Senha
              <Input id="d3-password" type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} required disabled={submitting} />
            </label>
            {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
            <Button type="submit" className="h-10 w-full" disabled={submitting || !username || !password}>
              {submitting && <LoaderCircle className="animate-spin" />}{submitting ? 'Validando…' : 'Entrar'}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="gap-2 border-t border-border pt-4 text-xs text-muted-foreground"><ShieldCheck className="size-4 shrink-0" />Acesse com sua conta OrganizeOn.</CardFooter>
      </Card>
    </main>
  );
}
