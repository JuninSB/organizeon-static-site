import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { SettingsPage } from './settings-page';
import { monitorService } from '@/services/monitor-service';

vi.mock('@/services/monitor-service', () => ({
  monitorService: { settings: vi.fn(), status: vi.fn(), updateDelay: vi.fn() },
}));

const settings = {
  toolVersion: 'miapply 1.0.1', auth: 'validada', timezone: 'Asia/Shanghai', delayMs: -175,
  delayMinMs: -500, delayMaxMs: 30000, canConfigureDelay: true,
  installDirectory: '~/xiaomi-unlock', process: 'active', storage: 'SQLite WAL ativo', authAccount: 'owner',
};

describe('SettingsPage delay control', () => {
  beforeEach(() => {
    vi.mocked(monitorService.settings).mockResolvedValue(settings);
    vi.mocked(monitorService.updateDelay).mockResolvedValue({ ok: true, delayMs: -125, schedulerRestarted: true });
  });

  it('saves an integer delay using the privileged settings API', async () => {
    const user = userEvent.setup();
    render(<SettingsPage />);
    const input = await screen.findByLabelText('Ajustar horário de envio');
    await user.clear(input);
    await user.type(input, '-125');
    await user.click(screen.getByRole('button', { name: 'Salvar atraso' }));
    await waitFor(() => expect(monitorService.updateDelay).toHaveBeenCalledWith(-125));
  });

  it('does not render the control for a regular admin profile', async () => {
    vi.mocked(monitorService.settings).mockResolvedValue({ ...settings, canConfigureDelay: false });
    render(<SettingsPage />);
    await screen.findByText('Atraso local atual');
    expect(screen.queryByLabelText('Ajustar horário de envio')).not.toBeInTheDocument();
  });
});
