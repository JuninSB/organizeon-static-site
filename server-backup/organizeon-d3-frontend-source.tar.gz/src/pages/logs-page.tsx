import { RotatingIcon } from '@/components/shared/rotating-icon';
import { useCallback, useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, RotateCw } from 'lucide-react';
import type { EventLog } from '@/types/dashboard';
import { monitorService } from '@/services/monitor-service';
import { useDashboardStore } from '@/store/dashboard-store';
import { formatDateTime } from '@/lib/format';
import { PageHeading } from '@/components/shared/page-heading';
import { EmptyState, ErrorState, LoadingBlock } from '@/components/shared/feedback-state';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const severities = ['info', 'success', 'warning', 'error'];
const severityClasses: Record<string, string> = {
  info: 'border-border text-muted-foreground', success: 'border-emerald-200 text-emerald-700 dark:border-emerald-900/70 dark:text-emerald-400',
  warning: 'border-amber-900/70 text-amber-400', error: 'border-destructive/50 text-destructive',
};
export function LogsPage() {
  const filters = useDashboardStore((s) => s.logFilters);
  const update = useDashboardStore((s) => s.setLogFilters);
  const [items, setItems] = useState<EventLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async (signal?: AbortSignal) => {
    setRefreshing(true); setError('');
    try { const data = await monitorService.logs(filters, signal); setItems(data.items); }
    catch (reason) { if (!signal?.aborted) setError(reason instanceof Error ? reason.message : 'Falha ao carregar eventos.'); }
    finally { if (!signal?.aborted) { setLoading(false); setRefreshing(false); } }
  }, [filters]);
  useEffect(() => {
    const controller = new AbortController(); void load(controller.signal);
    const timer = window.setInterval(() => { if (document.visibilityState === 'visible') void load(); }, 15000);
    return () => { controller.abort(); window.clearInterval(timer); };
  }, [load]);

  return (
    <div className="space-y-6">
      <PageHeading title="Eventos" description="Diagnósticos sanitizados da automação Xiaomi." actions={<Button variant="outline" size="sm" onClick={() => void load()} disabled={refreshing}><RotatingIcon icon={RotateCw} active={refreshing} />Atualizar</Button>} />
      <Card className="border-border bg-card shadow-none"><CardContent className="space-y-4 p-4 sm:p-5">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_1.2fr_auto] lg:items-end">
          <label className="grid gap-1.5 text-xs font-medium text-muted-foreground">De<input type="date" value={filters.from} onChange={(event) => update({ from: event.target.value, offset: 0 })} className="h-9 rounded-md border border-input bg-background px-3 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring" /></label>
          <label className="grid gap-1.5 text-xs font-medium text-muted-foreground">Até<input type="date" value={filters.to} onChange={(event) => update({ to: event.target.value, offset: 0 })} className="h-9 rounded-md border border-input bg-background px-3 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring" /></label>
          <label className="grid gap-1.5 text-xs font-medium text-muted-foreground">Severidade
            <Select value={filters.severity || 'all'} onValueChange={(value) => update({ severity: value === 'all' ? '' : String(value ?? ''), offset: 0 })}>
              <SelectTrigger className="w-full" aria-label="Filtrar severidade"><SelectValue placeholder="Todas" /></SelectTrigger>
              <SelectContent><SelectItem value="all">Todas</SelectItem>{severities.map((value) => <SelectItem key={value} value={value}>{value}</SelectItem>)}</SelectContent>
            </Select>
          </label>
          <Button variant="outline" onClick={() => update({ from: '', to: '', severity: '', offset: 0 })}>Limpar filtros</Button>
        </div>
        {loading ? <LoadingBlock rows={5} /> : error ? <ErrorState message={error} onRetry={() => void load()} /> : items.length === 0 ? <EmptyState title="Nenhum evento neste período" description="Quando a automação registrar eventos, eles aparecerão aqui." /> : (
          <>
            <ol className="divide-y divide-border rounded-md border border-border">
              {items.map((item) => <li key={item.id} className="grid gap-2 px-3 py-3 sm:grid-cols-[150px_90px_120px_minmax(0,1fr)] sm:items-start sm:gap-3 sm:px-4">
                <time className="text-xs tabular-nums text-muted-foreground">{formatDateTime(item.at)}</time>
                <Badge variant="outline" className={`w-fit capitalize ${severityClasses[item.severity] ?? severityClasses.info}`}>{item.severity}</Badge>
                <span className="font-mono text-[11px] text-muted-foreground">{item.kind}</span>
                <p className="break-words text-sm leading-5">{item.message}</p>
              </li>)}
            </ol>
            <div className="flex items-center justify-between gap-3"><p className="text-xs text-muted-foreground">{items.length} eventos · página {Math.floor(filters.offset / 50) + 1}</p><div className="flex gap-2"><Button variant="outline" size="sm" disabled={filters.offset === 0} onClick={() => update({ offset: Math.max(0, filters.offset - 50) })}><ChevronLeft />Anterior</Button><Button variant="outline" size="sm" disabled={items.length < 50} onClick={() => update({ offset: filters.offset + 50 })}>Próxima<ChevronRight /></Button></div></div>
          </>
        )}
      </CardContent></Card>
    </div>
  );
}
