vi.mock('@/services/profile-service', async (importOriginal) => ({ ...(await importOriginal<typeof import('@/services/profile-service')>()), profileService: { get: vi.fn().mockResolvedValue({displayName:'admin',nameColor:'#FAFAFA',bio:'',avatarShape:'circle',avatar:null}) } }));
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { App } from './app';
import { AuthProvider } from '@/providers/auth-provider';
import { authService } from '@/services/auth-service';
import { monitorService } from '@/services/monitor-service';

vi.mock('@/services/auth-service', () => ({ authService: { session: vi.fn(), login: vi.fn(), logout: vi.fn() } }));
vi.mock('@/services/monitor-service', () => ({ monitorService: { status: vi.fn(), settings: vi.fn(), history: vi.fn(), logs: vi.fn() } }));

const status = {
  serverOnline: true, xiaomiProcess: true, tmux: true, androidUptimeSeconds: 500,
  cpuPercent: 4, memory: { total: 1000, available: 500, used: 500 }, connectivity: true,
  updatedAt: '2026-11-14T00:00:00Z', state: 'Aguardando autorização', authValidated: true,
  approved: false, scheduler: 'active' as const,
  nextAttempt: { china: '2026-11-15T00:00:00+08:00', brazil: '2026-11-14T13:00:00-03:00', epoch: 1794672000 },
  lastAttempt: null,
};
function renderApp(path: string) {
  window.history.replaceState({}, '', path);
  return render(<AuthProvider><App /></AuthProvider>);
}

describe('D3 session routing and logout', () => {
  beforeEach(() => {
    window.localStorage.removeItem('d3-theme');
    document.documentElement.className = 'dark';
    document.getElementById('d3-favicon')?.remove();
    const favicon = document.createElement('link'); favicon.id = 'd3-favicon'; favicon.rel = 'icon'; document.head.append(favicon);
    vi.mocked(authService.session).mockResolvedValue({ authenticated: false });
    vi.mocked(authService.login).mockResolvedValue({ ok: true, authenticated: true, username: 'admin', role: 'admin' });
    vi.mocked(authService.logout).mockResolvedValue({ ok: true });
    vi.mocked(monitorService.status).mockResolvedValue(status);
    vi.mocked(monitorService.settings).mockResolvedValue({ toolVersion: 'miapply 1.0.1', auth: 'validada', timezone: 'Asia/Shanghai', delayMs: 500, delayMinMs: -500, delayMaxMs: 30000, canConfigureDelay: false, installDirectory: '~/xiaomi-unlock', process: 'active', storage: 'SQLite WAL ativo', authAccount: 'admin' });
    vi.mocked(monitorService.history).mockResolvedValue({ items: [], offset: 0, limit: 50 });
    vi.mocked(monitorService.logs).mockResolvedValue({ items: [], offset: 0, limit: 50 });
  });

  it('sends an unauthenticated visit from D3 to /d3/login', async () => {
    renderApp('/d3/');
    expect(await screen.findByRole('heading', { name: 'Entrar no painel' }, { timeout: 10000 })).toBeInTheDocument();
    expect(screen.getByText('Autentique-se para acessar o conteúdo do Endpoint 3.')).toBeInTheDocument();
    expect(screen.getByText('Acesse com sua conta OrganizeOn.')).toBeInTheDocument();
    expect(screen.queryByText(/o D3 não a armazena/i)).not.toBeInTheDocument();
    await waitFor(() => expect(window.location.pathname).toBe('/d3/login'), { timeout: 10000 });
  });

  it('sends an authenticated visit from /d3/login to the dashboard', async () => {
    vi.mocked(authService.session).mockResolvedValue({ authenticated: true, username: 'admin', role: 'admin' });
    renderApp('/d3/login');
    await waitFor(() => expect(window.location.pathname).toBe('/d3'), { timeout: 10000 });
    expect(await screen.findByRole('heading', { name: 'Autorização da conta' }, { timeout: 10000 })).toBeInTheDocument();
    const headings = screen.getAllByRole('heading').map((heading) => heading.textContent);
    expect(headings.indexOf('Próxima abertura da cota')).toBeGreaterThanOrEqual(0);
    expect(headings.indexOf('Próxima abertura da cota')).toBeLessThan(headings.indexOf('Autorização da conta'));
    const themeButton = screen.getByRole('button', { name: 'Ativar tema claro' });
    await userEvent.setup().click(themeButton);
    await waitFor(() => expect(document.documentElement).toHaveClass('light'));
    expect(window.localStorage.getItem('d3-theme')).toBe('light');
    expect(document.getElementById('d3-favicon')).toHaveAttribute('href', '/d3/assets/organizeon_icon_black_128.png');
  });

  it('authenticates with the central OrganizeOn profile and sets the D3 session', async () => {
    vi.mocked(authService.session)
      .mockResolvedValueOnce({ authenticated: false })
      .mockResolvedValueOnce({ authenticated: true, username: 'admin', role: 'admin' });
    const user = userEvent.setup();
    renderApp('/d3/login');
    await user.type(await screen.findByLabelText('Usuário', {}, { timeout: 10000 }), 'admin');
    await user.type(screen.getByLabelText('Senha'), 'valid-pass');
    await user.click(screen.getByRole('button', { name: 'Entrar' }));
    expect(authService.login).toHaveBeenCalledWith({ username: 'admin', password: 'valid-pass' });
    expect(await screen.findByRole('heading', { name: 'Autorização da conta' }, { timeout: 15000 })).toBeInTheDocument();
    expect(window.location.pathname).toBe('/d3');
  });

  it('runs the OrganizeOn logout endpoint and returns to /d3/login', async () => {
    vi.mocked(authService.session).mockResolvedValue({ authenticated: true, username: 'admin', role: 'admin' });
    const user = userEvent.setup();
    renderApp('/d3/');
    await screen.findByRole('heading', { name: 'Autorização da conta' }, { timeout: 10000 });
    await user.click(screen.getByRole('button', { name: 'Perfil de admin' }));
    const profileMenu = await screen.findByRole('menu');
    expect(within(profileMenu).getByText('admin')).toBeInTheDocument();
    expect(within(profileMenu).getByText('@admin · Admin')).toBeInTheDocument();
    await user.click(within(profileMenu).getByRole('menuitem', { name: 'Sair da sessão' }));
    expect(authService.logout).toHaveBeenCalledOnce();
    expect(await screen.findByRole('heading', { name: 'Entrar no painel' }, { timeout: 10000 })).toBeInTheDocument();
    expect(window.location.pathname).toBe('/d3/login');
  });
});
