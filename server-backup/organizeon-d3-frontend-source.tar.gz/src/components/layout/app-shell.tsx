import { AccountMenu } from "@/components/layout/account-menu";
import { RotatingIcon } from '@/components/shared/rotating-icon';
import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Activity, CalendarClock, Clock3, LayoutDashboard, Moon, RefreshCw, Settings2, Sun } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/providers/auth-provider';
import { useDashboardRefresh } from '@/hooks/use-dashboard-refresh';
import { useDashboardStore } from '@/store/dashboard-store';
import { Button } from '@/components/ui/button';
import { BrandIcon } from '@/components/shared/brand-icon';
import { applyTheme, getThemePreference, type Theme } from '@/services/theme-service';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarGroupLabel, SidebarHeader, SidebarInset, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarSeparator, SidebarTrigger, useSidebar } from '@/components/ui/sidebar';

const items = [
  { to: '/', label: 'Visão geral', icon: LayoutDashboard },
  { to: '/history', label: 'Histórico', icon: Clock3 },
  { to: '/logs', label: 'Eventos', icon: Activity },
  { to: '/settings', label: 'Configurações', icon: Settings2 },
];


function NavigationItems() {
  const location = useLocation();
  const { setOpenMobile } = useSidebar();
  return <SidebarMenu>{items.map(({ to, label, icon: Icon }) => (
    <SidebarMenuItem key={to}>
      <SidebarMenuButton
        render={<NavLink to={to} end={to === '/'} aria-label={label} />}
        isActive={location.pathname === to || (to !== '/' && location.pathname.startsWith(`${to}/`))}
        tooltip={label}
        onClick={() => setOpenMobile(false)}
      >
        <Icon aria-hidden="true" /><span>{label}</span>
      </SidebarMenuButton>
    </SidebarMenuItem>
  ))}</SidebarMenu>;
}

export function AppShell() {
  const { session, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { refresh, refreshing } = useDashboardRefresh();
  const connected = useDashboardStore((s) => s.connected);
  const status = useDashboardStore((s) => s.status);
  const [theme, setTheme] = useState<Theme>(getThemePreference);
  const [refreshPulse, setRefreshPulse] = useState(false);
  const refreshPulseTimer = useRef<number | null>(null);
  const label = items.find((item) => item.to === location.pathname)?.label ?? 'Monitoramento';
  const accountName = session?.username ?? 'Conta OrganizeOn';


  useEffect(() => () => {
    if (refreshPulseTimer.current !== null) window.clearTimeout(refreshPulseTimer.current);
  }, []);

  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  function handleRefresh() {
    setRefreshPulse(true);
    if (refreshPulseTimer.current !== null) window.clearTimeout(refreshPulseTimer.current);
    refreshPulseTimer.current = window.setTimeout(() => {
      setRefreshPulse(false);
      refreshPulseTimer.current = null;
    }, 700);
    void refresh();
  }

  async function handleLogout() {
    try {
      await logout();
      toast.success('Sessão encerrada');
      navigate('/login', { replace: true });
    } catch {
      toast.error('Não foi possível encerrar a sessão. Tente novamente.');
    }
  }

  return (
    <SidebarProvider defaultOpen>
      <Sidebar collapsible="icon" variant="sidebar">
        <SidebarHeader className="px-3 pb-3 pt-4">
          <Link to="/" aria-label="OrganizeOn D3 — início" className="flex min-h-10 items-center gap-2.5 rounded-md px-2 text-sm font-semibold tracking-tight text-sidebar-foreground outline-none focus-visible:ring-2 focus-visible:ring-sidebar-ring">
            <BrandIcon className="size-7 shrink-0" />
            <span className="truncate">OrganizeOn <span className="ml-1 font-normal text-muted-foreground">D3</span></span>
          </Link>
        </SidebarHeader>
        <SidebarSeparator />
        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupLabel>Monitoramento</SidebarGroupLabel>
            <NavigationItems />
          </SidebarGroup>
        </SidebarContent>
        <SidebarFooter className="px-2 pb-3">
          <AccountMenu username={accountName} role={session?.role || "user"} onLogout={() => void handleLogout()}/>
        </SidebarFooter>
      </Sidebar>

      <SidebarInset className="min-h-svh min-w-0">
        <header className="sticky top-0 z-20 flex h-14 shrink-0 items-center gap-3 border-b border-border bg-background/95 px-4 backdrop-blur supports-[backdrop-filter]:bg-background/85 sm:px-6">
          <SidebarTrigger aria-label="Abrir ou recolher navegação" />
          <Separator orientation="vertical" className="h-5" />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium">{label}</p>
          </div>
          <Tooltip>
            <TooltipTrigger render={<span className="hidden items-center gap-1.5 text-xs text-muted-foreground sm:flex" tabIndex={0} /> }>
              <span className={`size-1.5 rounded-full ${connected ? 'bg-emerald-500' : 'bg-zinc-500 dark:bg-zinc-600'}`} />
              <span>{connected ? 'Conectado' : 'Sem conexão'}</span>
            </TooltipTrigger>
            <TooltipContent side="bottom">{status?.updatedAt ? `Atualizado em ${new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short' }).format(new Date(status.updatedAt))}` : 'Aguardando dados do servidor'}</TooltipContent>
          </Tooltip>
          <Button variant="ghost" size="icon" onClick={() => setTheme((current) => current === 'dark' ? 'light' : 'dark')} aria-label={theme === 'dark' ? 'Ativar tema claro' : 'Ativar tema escuro'} title={theme === 'dark' ? 'Tema claro' : 'Tema escuro'}>
            {theme === 'dark' ? <Sun /> : <Moon />}
          </Button>
          <Button variant="ghost" size="icon" onClick={handleRefresh} disabled={refreshing} aria-label="Atualizar painel" title="Atualizar">
            <RotatingIcon icon={RefreshCw} active={refreshing || refreshPulse} />
          </Button>
        </header>
        <main id="main-content" className="mx-auto w-full max-w-[1440px] flex-1 px-4 py-6 sm:px-6 sm:py-8 lg:px-10">
          <Outlet />
        </main>
        <footer className="mx-auto flex w-full max-w-[1440px] items-center justify-between gap-3 border-t border-border px-4 py-3 text-xs text-muted-foreground sm:px-6 lg:px-10">
          <span>OrganizeOn · Xiaomi Community</span>
          <Badge variant="outline" className="gap-1.5 font-normal"><CalendarClock className="size-3.5" />Asia/Shanghai</Badge>
        </footer>
      </SidebarInset>
    </SidebarProvider>
  );
}
