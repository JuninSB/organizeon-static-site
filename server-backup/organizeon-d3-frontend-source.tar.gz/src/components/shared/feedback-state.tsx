import { AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

export function LoadingBlock({ rows = 3 }: { rows?: number }) {
  return <div className="space-y-3" aria-label="Carregando" role="status">{Array.from({ length: rows }, (_, i) => <Skeleton key={i} className="h-12 w-full rounded-md" />)}</div>;
}
export function EmptyState({ title, description }: { title: string; description: string }) {
  return <div className="flex min-h-44 flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-border px-5 text-center"><p className="text-sm font-medium">{title}</p><p className="max-w-md text-sm text-muted-foreground">{description}</p></div>;
}
export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return <div role="alert" className="flex flex-col items-center gap-3 rounded-lg border border-destructive/30 bg-destructive/5 p-6 text-center"><AlertCircle className="size-5 text-destructive" /><p className="text-sm text-muted-foreground">{message}</p>{onRetry && <Button variant="outline" size="sm" onClick={onRetry}><RefreshCw />Tentar novamente</Button>}</div>;
}
