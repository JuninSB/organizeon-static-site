type BrandIconProps = { className: string };

export function BrandIcon({ className }: BrandIconProps) {
  return (
    <span className={`brand-mark ${className}`} aria-hidden="true">
      <img className="brand-icon brand-icon-dark" loading="eager" fetchPriority="high" decoding="async" onLoad={event=>{void event.currentTarget.decode().catch(()=>{});}} src="/d3/assets/organizeon-icon.png" alt="" />
      <img className="brand-icon brand-icon-light" loading="eager" fetchPriority="high" decoding="async" onLoad={event=>{void event.currentTarget.decode().catch(()=>{});}} src="/d3/assets/organizeon_preto_separado_1024.png" alt="" />
    </span>
  );
}
