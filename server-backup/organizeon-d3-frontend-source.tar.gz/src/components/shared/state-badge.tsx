import { Badge } from '@/components/ui/badge';
import { CheckCircle2, CircleDashed, CircleX, Clock3, TriangleAlert } from 'lucide-react';

const states: Record<string, { tone: string; icon: typeof CheckCircle2 }> = {
  'Autorização concedida': { tone: 'success', icon: CheckCircle2 },
  'Aguardando autorização': { tone: 'info', icon: Clock3 },
  'Cota diária esgotada': { tone: 'warning', icon: TriangleAlert },
  'Autenticação expirada': { tone: 'warning', icon: TriangleAlert },
  'Erro de comunicação': { tone: 'destructive', icon: CircleX },
};
export function StateBadge({ state }: { state?: string | null }) {
  const current = states[state ?? ''] ?? { tone: 'muted', icon: CircleDashed };
  const Icon = current.icon;
  return <Badge variant="outline" data-tone={current.tone} className="gap-1.5 font-medium"><Icon className="size-3.5" />{state || 'Estado desconhecido'}</Badge>;
}
