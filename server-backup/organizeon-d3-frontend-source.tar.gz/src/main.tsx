import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from '@/app/app';
import { AuthProvider } from '@/providers/auth-provider';
import { applyTheme, getThemePreference } from '@/services/theme-service';
import '@/index.css';

applyTheme(getThemePreference());

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode><AuthProvider><App /></AuthProvider></React.StrictMode>,
);
